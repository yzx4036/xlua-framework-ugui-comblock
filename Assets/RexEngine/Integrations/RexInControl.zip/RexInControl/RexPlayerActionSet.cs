﻿using UnityEngine;
using InControl;

namespace RexEngine
{
	public class RexPlayerActionSet:PlayerActionSet
	{
		public PlayerAction Jump;
		public PlayerAction Attack;
		public PlayerAction SubAttack;
		public PlayerAction Dash;
		public PlayerAction Run;
		public PlayerAction Pause;
		public PlayerAction Left;
		public PlayerAction Right;
		public PlayerAction Up;
		public PlayerAction Down;
		public PlayerTwoAxisAction Move;

		public RexPlayerActionSet()
		{
			Jump = CreatePlayerAction("Jump");
			Attack = CreatePlayerAction("Attack");
			SubAttack = CreatePlayerAction("SubAttack");
			Dash = CreatePlayerAction("Dash");
			Run = CreatePlayerAction("Run");
			Pause = CreatePlayerAction("Pause");
			Left = CreatePlayerAction("Move Left");
			Right = CreatePlayerAction("Move Right");
			Up = CreatePlayerAction("Move Up");
			Down = CreatePlayerAction("Move Down");
			Move = CreateTwoAxisPlayerAction(Left, Right, Down, Up);
		}

		public static RexPlayerActionSet CreateWithDefaultBindings()
		{
			var playerActions = new RexPlayerActionSet();

			playerActions.Jump.AddDefaultBinding(Key.H);
			playerActions.Jump.AddDefaultBinding(InputControlType.Action1);

			playerActions.Attack.AddDefaultBinding(Key.G);
			playerActions.Attack.AddDefaultBinding(InputControlType.Action3);

			playerActions.SubAttack.AddDefaultBinding(Key.T);
			playerActions.SubAttack.AddDefaultBinding(InputControlType.Action4);

			playerActions.Dash.AddDefaultBinding(Key.Y);
			playerActions.Dash.AddDefaultBinding(InputControlType.Action2);

			playerActions.Run.AddDefaultBinding(Key.R);
			playerActions.Run.AddDefaultBinding(InputControlType.RightTrigger);

			playerActions.Pause.AddDefaultBinding(Key.Escape);
			playerActions.Pause.AddDefaultBinding(Key.Return);
			playerActions.Pause.AddDefaultBinding(InputControlType.Command);

			playerActions.Up.AddDefaultBinding(Key.W);
			playerActions.Down.AddDefaultBinding(Key.S);
			playerActions.Left.AddDefaultBinding(Key.A);
			playerActions.Right.AddDefaultBinding(Key.D);

			playerActions.Left.AddDefaultBinding(InputControlType.LeftStickLeft);
			playerActions.Right.AddDefaultBinding(InputControlType.LeftStickRight);
			playerActions.Up.AddDefaultBinding(InputControlType.LeftStickUp);
			playerActions.Down.AddDefaultBinding(InputControlType.LeftStickDown);

			playerActions.Left.AddDefaultBinding(InputControlType.DPadLeft);
			playerActions.Right.AddDefaultBinding(InputControlType.DPadRight);
			playerActions.Up.AddDefaultBinding(InputControlType.DPadUp);
			playerActions.Down.AddDefaultBinding(InputControlType.DPadDown);

			return playerActions;
		}

		public static RexPlayerActionSet CreateWithPlayer2Bindings()
		{
			var playerActions = new RexPlayerActionSet();

			playerActions.Jump.AddDefaultBinding(Key.Space);

			playerActions.Attack.AddDefaultBinding(Key.Period);

			playerActions.SubAttack.AddDefaultBinding(Key.Comma);

			playerActions.Dash.AddDefaultBinding(Key.M);

			playerActions.Run.AddDefaultBinding(Key.Semicolon);

			playerActions.Up.AddDefaultBinding(Key.UpArrow);
			playerActions.Down.AddDefaultBinding(Key.DownArrow);
			playerActions.Left.AddDefaultBinding(Key.LeftArrow);
			playerActions.Right.AddDefaultBinding(Key.RightArrow);

			return playerActions;
		}
	}
}