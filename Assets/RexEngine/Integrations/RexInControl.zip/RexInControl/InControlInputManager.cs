﻿using System.Collections.Generic;

namespace RexEngine
{
	public class InControlInputManager:InputManager
	{
		List<RexPlayerActionSet> playerActionSets = new List<RexPlayerActionSet>();


		protected override void Awake()
		{
			base.Awake();

			if(InputManager.Instance != null)
			{
				Enabled = false;
				return;
			}

			SetInstance(this);

			InControl.InputManager.OnSetup += () =>
			{
				playerActionSets.Add(RexPlayerActionSet.CreateWithDefaultBindings());

				if(GameManager.Instance.settings.numberOfPlayers > 1)
				{
					playerActionSets.Add(RexPlayerActionSet.CreateWithPlayer2Bindings());
				}
			};
		}


		public override bool GetButton( int playerId, InputAction action )
		{
			if (playerId < playerActionSets.Count)
			{
				var playerActionSet = playerActionSets[playerId];
				switch (action)
				{
					case InputAction.Attack:
						return playerActionSet.Attack.IsPressed;

					case InputAction.Dash:
						return playerActionSet.Dash.IsPressed;

					case InputAction.Jump:
						return playerActionSet.Jump.IsPressed;

					case InputAction.Pause:
						return playerActionSet.Pause.IsPressed;

					case InputAction.Run:
						return playerActionSet.Run.IsPressed;

					case InputAction.SubAttack:
						return playerActionSet.SubAttack.IsPressed;
				}
			}
			return false;
		}


		public override bool GetButtonDown( int playerId, InputAction action )
		{
			if(playerId < playerActionSets.Count)
			{
				var playerActionSet = playerActionSets[playerId];
				switch (action)
				{
					case InputAction.Attack:
						return playerActionSet.Attack.WasPressed;

					case InputAction.Dash:
						return playerActionSet.Dash.WasPressed;

					case InputAction.Jump:
						return playerActionSet.Jump.WasPressed;

					case InputAction.Pause:
						return playerActionSet.Pause.WasPressed;

					case InputAction.Run:
						return playerActionSet.Run.WasPressed;

					case InputAction.SubAttack:
						return playerActionSet.SubAttack.WasPressed;
				}
			}
			return false;
		}


		public override bool GetButtonUp(int playerId, InputAction action)
		{
			if(playerId < playerActionSets.Count)
			{
				var playerActionSet = playerActionSets[playerId];
				switch(action)
				{
					case InputAction.Attack:
						return playerActionSet.Attack.WasReleased;

					case InputAction.Dash:
						return playerActionSet.Dash.WasReleased;

					case InputAction.Jump:
						return playerActionSet.Jump.WasReleased;

					case InputAction.Pause:
						return playerActionSet.Pause.WasReleased;

					case InputAction.Run:
						return playerActionSet.Run.WasReleased;

					case InputAction.SubAttack:
						return playerActionSet.SubAttack.WasReleased;
				}
			}
			return false;
		}


		public override float GetAxis(int playerId, InputAction action)
		{
			if(playerId < playerActionSets.Count)
			{
				var playerActionSet = playerActionSets[playerId];
				switch(action)
				{
					case InputAction.MoveHorizontal:
						return playerActionSet.Move.X;

					case InputAction.MoveVertical:
						return playerActionSet.Move.Y;
				}
			}
			return 0.0f;
		}
	}
}
