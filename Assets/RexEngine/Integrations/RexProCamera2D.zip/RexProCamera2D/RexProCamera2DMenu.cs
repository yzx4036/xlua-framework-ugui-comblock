﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using Com.LuisPedroFonseca.ProCamera2D;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace RexEngine
{
	public class RexProCamera2DMenu:MonoBehaviour 
	{
		#if UNITY_EDITOR
		[MenuItem("Tools/Rex Engine/Setup ProCamera2D", false, 120)]
		public static void SetupProCamera2D()
		{
			GameObject rexCameraGameObject = Instantiate(Resources.Load("System/Cameras"), Vector3.zero, Quaternion.identity) as GameObject;
			RexCamera rexCamera = rexCameraGameObject.GetComponentInChildren<RexCamera>();

			if(rexCamera == null)
			{
				Debug.Log("CameraPro2D is already set up!");

				return;
			}

			ProCamera2D proCamera2D = rexCameraGameObject.GetComponent<ProCamera2D>();
			if(proCamera2D == null)
			{
				proCamera2D = rexCamera.gameObject.AddComponent<ProCamera2D>(); 
				proCamera2D.GameCamera = rexCamera.cameras.main;
			}

			if(proCamera2D != null)
			{
				ProCamera2DNumericBoundaries boundaries = proCamera2D.gameObject.GetComponent<ProCamera2DNumericBoundaries>();
				if(boundaries == null)
				{
					boundaries = proCamera2D.gameObject.AddComponent<ProCamera2DNumericBoundaries>();
				}

				boundaries.ProCamera2D = proCamera2D;
				boundaries.UseLeftBoundary = true;
				boundaries.UseRightBoundary = true;
				boundaries.UseBottomBoundary = true;
				boundaries.UseTopBoundary = true;

				ProCamera2DParallax parallax = proCamera2D.GetComponent<ProCamera2DParallax>();
				if(parallax == null)
				{
					parallax = proCamera2D.gameObject.AddComponent<ProCamera2DParallax>();
				}

				parallax.ParallaxLayers = new List<ProCamera2DParallaxLayer>();

				ProCamera2DParallaxLayer canvasLayer = new ProCamera2DParallaxLayer();
				canvasLayer.CameraTransform = rexCamera.cameras.canvas.transform;
				canvasLayer.ParallaxCamera = rexCamera.cameras.canvas;
				canvasLayer.LayerMask = 1 << rexCamera.cameras.canvas.gameObject.layer;
				canvasLayer.Speed = 0.0f;
				parallax.ParallaxLayers.Add(canvasLayer);

				ProCamera2DParallaxLayer backgroundLayer = new ProCamera2DParallaxLayer();
				backgroundLayer.CameraTransform = rexCamera.cameras.background.transform;
				backgroundLayer.ParallaxCamera = rexCamera.cameras.background;
				backgroundLayer.LayerMask = 1 << rexCamera.cameras.background.gameObject.layer;
				backgroundLayer.Speed = 0.35f;
				parallax.ParallaxLayers.Add(backgroundLayer);

				ProCamera2DParallaxLayer midgroundLayer = new ProCamera2DParallaxLayer();
				midgroundLayer.CameraTransform = rexCamera.cameras.midground.transform;
				midgroundLayer.ParallaxCamera = rexCamera.cameras.midground;
				midgroundLayer.LayerMask = 1 << rexCamera.cameras.midground.gameObject.layer;
				midgroundLayer.Speed = 0.5f;
				parallax.ParallaxLayers.Add(midgroundLayer);

				ProCamera2DParallaxLayer foregroundLayer = new ProCamera2DParallaxLayer();
				foregroundLayer.CameraTransform = rexCamera.cameras.foreground.transform;
				foregroundLayer.ParallaxCamera = rexCamera.cameras.foreground;
				foregroundLayer.LayerMask = 1 << rexCamera.cameras.foreground.gameObject.layer;
				foregroundLayer.Speed = 1.2f;
				parallax.ParallaxLayers.Add(foregroundLayer);

				ProCamera2DShake shake = proCamera2D.GetComponent<ProCamera2DShake>();
				if(shake == null)
				{
					shake = proCamera2D.gameObject.AddComponent<ProCamera2DShake>();
					shake.ProCamera2D = proCamera2D;
					shake.ShakePresets = new List<ShakePreset>();
					var preset = CreateAsset<ShakePreset>("RexShake");
					preset.name = "Rex Shake";
					preset.Strength = new Vector3(0.1f, 0.1f, 0.0f);
					shake.ShakePresets.Add(preset);
					EditorUtility.SetDirty(shake);
				}
			}

			if(rexCamera != null)
			{
				rexCamera.gameObject.AddComponent<RexCameraPro2D>();
				DestroyImmediate(rexCamera);
			}

			string localPath = "Assets/RexEngine/Resources/System/Cameras.prefab";
			Object prefab = PrefabUtility.CreateEmptyPrefab(localPath);
			PrefabUtility.ReplacePrefab(rexCameraGameObject, prefab, ReplacePrefabOptions.ConnectToPrefab);
			EditorUtility.SetDirty(rexCameraGameObject);
			DestroyImmediate(rexCameraGameObject);

			Debug.Log("Successfully integrated ProCamera2D into your Rex Engine project! It's a match made in Heaven!");
		}

		private static T CreateAsset<T>(string name = null) where T : ScriptableObject
		{
			var asset = ScriptableObject.CreateInstance<T>();

			string path = AssetDatabase.GetAssetPath(Selection.activeObject);
			if (path == "")
			{
				path = "Assets";
			}
			else if (Path.GetExtension(path) != "")
			{
				path = path.Replace(Path.GetFileName(AssetDatabase.GetAssetPath(Selection.activeObject)), "");
			}

			var assetPathAndName = "";
			if(string.IsNullOrEmpty(name))
			{
				assetPathAndName = AssetDatabase.GenerateUniqueAssetPath(path + "/New " + typeof(T) + ".asset");
			}
			else
			{
				assetPathAndName = AssetDatabase.GenerateUniqueAssetPath(path + "/New " + name + ".asset");
			}

			AssetDatabase.CreateAsset(asset, assetPathAndName);

			AssetDatabase.SaveAssets();
			AssetDatabase.Refresh();

			return asset;
		}
		#endif
	}
}
