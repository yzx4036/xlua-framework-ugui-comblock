﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Com.LuisPedroFonseca.ProCamera2D;

namespace RexEngine
{
	public class RexCameraPro2D:RexCameraBase 
	{
		protected ProCamera2D proCamera2D;
		protected ProCamera2DNumericBoundaries proBoundaries;
		protected ProCamera2DShake proShake;

		public override void NotifyOfShake()
		{
			if(proCamera2D == null)
			{
				proCamera2D = GetComponent<ProCamera2D>();
			}

			if(proShake == null)
			{
				proShake = GetComponent<ProCamera2DShake>();
			}

			if(proCamera2D != null && proShake != null)
			{
				proShake.Shake(0);
			}
		}

		public override void CenterOnPlayer()
		{
			RexActor player = GameManager.Instance.player;

			if(proCamera2D == null)
			{
				proCamera2D = GetComponent<ProCamera2D>();
			}

			if(player != null && proCamera2D != null)
			{
				StartCoroutine("CenterOnPlayerCoroutine");
			}
		}

		protected IEnumerator CenterOnPlayerCoroutine()
		{
			yield return new WaitForEndOfFrame();

			proCamera2D.CenterOnTargets();
		}

		public override void SetFocusObject(Transform _focusObject)
		{
			ProCamera2D proCamera2D = GetComponent<ProCamera2D>();
			if(proCamera2D != null)
			{
				if(proCamera2D.CameraTargets.Count < 1)
				{
					proCamera2D.AddCameraTarget(_focusObject);
				}
			}
		}

		public override void SetCameraBoundary(SceneBoundary.Edge _edge, float _value)
		{
			if(proBoundaries == null)
			{
				proBoundaries = GetComponent<ProCamera2DNumericBoundaries>();
			}

			if(proBoundaries != null)
			{
				switch(_edge)
				{
					case SceneBoundary.Edge.Left:
						boundariesMin.x = _value;
						proBoundaries.UseLeftBoundary = true;
						proBoundaries.LeftBoundary = boundariesMin.x;
						break;
					case SceneBoundary.Edge.Right:
						boundariesMax.x = _value;
						proBoundaries.UseRightBoundary = true;
						proBoundaries.RightBoundary = boundariesMax.x;
						break;
					case SceneBoundary.Edge.Bottom:
						boundariesMin.y = _value;
						proBoundaries.UseBottomBoundary = true;
						proBoundaries.BottomBoundary = boundariesMin.y;
						break;
					case SceneBoundary.Edge.Top:
						boundariesMax.y = _value;
						proBoundaries.UseTopBoundary = true;
						proBoundaries.TopBoundary = boundariesMax.y;
						break;
				}
			}
		}
	}
}
