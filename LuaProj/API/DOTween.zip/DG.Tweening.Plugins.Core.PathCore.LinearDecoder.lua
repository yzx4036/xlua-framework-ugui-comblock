---@class DG.Tweening.Plugins.Core.PathCore.LinearDecoder : DG.Tweening.Plugins.Core.PathCore.ABSPathDecoder
local m = {}

DG.Tweening.Plugins.Core.PathCore.LinearDecoder = m
return m
