---@class _PrivateImplementationDetails_.__StaticArrayInitTypeSize_120 : System.ValueType
local m = {}

_PrivateImplementationDetails_.__StaticArrayInitTypeSize_120 = m
return m
