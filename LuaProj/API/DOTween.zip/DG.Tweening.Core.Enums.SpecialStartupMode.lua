---@class DG.Tweening.Core.Enums.SpecialStartupMode : System.Enum
---@field public None DG.Tweening.Core.Enums.SpecialStartupMode @static
---@field public SetLookAt DG.Tweening.Core.Enums.SpecialStartupMode @static
---@field public SetShake DG.Tweening.Core.Enums.SpecialStartupMode @static
---@field public SetPunch DG.Tweening.Core.Enums.SpecialStartupMode @static
---@field public SetCameraShakePosition DG.Tweening.Core.Enums.SpecialStartupMode @static
---@field public value__ number
local m = {}

DG.Tweening.Core.Enums.SpecialStartupMode = m
return m
