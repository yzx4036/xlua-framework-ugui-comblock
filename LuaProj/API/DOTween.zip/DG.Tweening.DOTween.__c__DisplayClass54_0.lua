---@class DG.Tweening.DOTween.__c__DisplayClass54_0 : System.Object
---@field public v number
---@field public setter fun(pNewValue:number)
local m = {}

DG.Tweening.DOTween.__c__DisplayClass54_0 = m
return m
