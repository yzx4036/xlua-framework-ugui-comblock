---@class DG.Tweening.Plugins.Core.PluginsManager : System.Object
local m = {}

---@static
---@return DG.Tweening.Plugins.Core.ABSTweenPlugin_3_T1_T2_TPlugOptions_
function m.GetCustomPlugin() end

DG.Tweening.Plugins.Core.PluginsManager = m
return m
