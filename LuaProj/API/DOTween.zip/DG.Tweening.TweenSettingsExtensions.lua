---@class DG.Tweening.TweenSettingsExtensions : System.Object
local m = {}

---@overload fun(t:DG.Tweening.Tween, autoKillOnCompletion:boolean):DG.Tweening.Tween @static
---@static
---@param t DG.Tweening.Tween
---@return DG.Tweening.Tween
function m.SetAutoKill(t) end

---@static
---@param t DG.Tweening.Tween
---@param id any
---@return DG.Tweening.Tween
function m.SetId(t, id) end

---@static
---@param t DG.Tweening.Tween
---@param target any
---@return DG.Tweening.Tween
function m.SetTarget(t, target) end

---@overload fun(t:DG.Tweening.Tween, loops:number, loopType:DG.Tweening.LoopType):DG.Tweening.Tween @static
---@static
---@param t DG.Tweening.Tween
---@param loops number
---@return DG.Tweening.Tween
function m.SetLoops(t, loops) end

---@overload fun(t:DG.Tweening.Tween, ease:DG.Tweening.Ease, overshoot:number):DG.Tweening.Tween @static
---@overload fun(t:DG.Tweening.Tween, ease:DG.Tweening.Ease, amplitude:number, period:number):DG.Tweening.Tween @static
---@overload fun(t:DG.Tweening.Tween, animCurve:UnityEngine.AnimationCurve):DG.Tweening.Tween @static
---@overload fun(t:DG.Tweening.Tween, customEase:(fun(time:number, duration:number, overshootOrAmplitude:number, period:number):number)):DG.Tweening.Tween @static
---@static
---@param t DG.Tweening.Tween
---@param ease DG.Tweening.Ease
---@return DG.Tweening.Tween
function m.SetEase(t, ease) end

---@overload fun(t:DG.Tweening.Tween, recyclable:boolean):DG.Tweening.Tween @static
---@static
---@param t DG.Tweening.Tween
---@return DG.Tweening.Tween
function m.SetRecyclable(t) end

---@overload fun(t:DG.Tweening.Tween, updateType:DG.Tweening.UpdateType):DG.Tweening.Tween @static
---@overload fun(t:DG.Tweening.Tween, updateType:DG.Tweening.UpdateType, isIndependentUpdate:boolean):DG.Tweening.Tween @static
---@static
---@param t DG.Tweening.Tween
---@param isIndependentUpdate boolean
---@return DG.Tweening.Tween
function m.SetUpdate(t, isIndependentUpdate) end

---@static
---@param t DG.Tweening.Tween
---@param action fun()
---@return DG.Tweening.Tween
function m.OnStart(t, action) end

---@static
---@param t DG.Tweening.Tween
---@param action fun()
---@return DG.Tweening.Tween
function m.OnPlay(t, action) end

---@static
---@param t DG.Tweening.Tween
---@param action fun()
---@return DG.Tweening.Tween
function m.OnPause(t, action) end

---@static
---@param t DG.Tweening.Tween
---@param action fun()
---@return DG.Tweening.Tween
function m.OnRewind(t, action) end

---@static
---@param t DG.Tweening.Tween
---@param action fun()
---@return DG.Tweening.Tween
function m.OnUpdate(t, action) end

---@static
---@param t DG.Tweening.Tween
---@param action fun()
---@return DG.Tweening.Tween
function m.OnStepComplete(t, action) end

---@static
---@param t DG.Tweening.Tween
---@param action fun()
---@return DG.Tweening.Tween
function m.OnComplete(t, action) end

---@static
---@param t DG.Tweening.Tween
---@param action fun()
---@return DG.Tweening.Tween
function m.OnKill(t, action) end

---@static
---@param t DG.Tweening.Tween
---@param action fun(value:number)
---@return DG.Tweening.Tween
function m.OnWaypointChange(t, action) end

---@overload fun(t:DG.Tweening.Tween, tweenParams:DG.Tweening.TweenParams):DG.Tweening.Tween @static
---@static
---@param t DG.Tweening.Tween
---@param asTween DG.Tweening.Tween
---@return DG.Tweening.Tween
function m.SetAs(t, asTween) end

---@static
---@param s DG.Tweening.Sequence
---@param t DG.Tweening.Tween
---@return DG.Tweening.Sequence
function m.Append(s, t) end

---@static
---@param s DG.Tweening.Sequence
---@param t DG.Tweening.Tween
---@return DG.Tweening.Sequence
function m.Prepend(s, t) end

---@static
---@param s DG.Tweening.Sequence
---@param t DG.Tweening.Tween
---@return DG.Tweening.Sequence
function m.Join(s, t) end

---@static
---@param s DG.Tweening.Sequence
---@param atPosition number
---@param t DG.Tweening.Tween
---@return DG.Tweening.Sequence
function m.Insert(s, atPosition, t) end

---@static
---@param s DG.Tweening.Sequence
---@param interval number
---@return DG.Tweening.Sequence
function m.AppendInterval(s, interval) end

---@static
---@param s DG.Tweening.Sequence
---@param interval number
---@return DG.Tweening.Sequence
function m.PrependInterval(s, interval) end

---@static
---@param s DG.Tweening.Sequence
---@param callback fun()
---@return DG.Tweening.Sequence
function m.AppendCallback(s, callback) end

---@static
---@param s DG.Tweening.Sequence
---@param callback fun()
---@return DG.Tweening.Sequence
function m.PrependCallback(s, callback) end

---@static
---@param s DG.Tweening.Sequence
---@param atPosition number
---@param callback fun()
---@return DG.Tweening.Sequence
function m.InsertCallback(s, atPosition, callback) end

---@overload fun(t:DG.Tweening.Tweener, isRelative:boolean):DG.Tweening.Tweener @static
---@static
---@param t DG.Tweening.Tweener
---@return DG.Tweening.Tweener
function m.From(t) end

---@static
---@param t DG.Tweening.Tween
---@param delay number
---@return DG.Tweening.Tween
function m.SetDelay(t, delay) end

---@overload fun(t:DG.Tweening.Tween, isRelative:boolean):DG.Tweening.Tween @static
---@static
---@param t DG.Tweening.Tween
---@return DG.Tweening.Tween
function m.SetRelative(t) end

---@overload fun(t:DG.Tweening.Tween, isSpeedBased:boolean):DG.Tweening.Tween @static
---@static
---@param t DG.Tweening.Tween
---@return DG.Tweening.Tween
function m.SetSpeedBased(t) end

---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector2_UnityEngine_Vector2_DG_Tweening_Plugins_Options_VectorOptions_, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector2_UnityEngine_Vector2_DG_Tweening_Plugins_Options_VectorOptions_, axisConstraint:DG.Tweening.AxisConstraint, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector2_UnityEngine_Vector2_DG_Tweening_Plugins_Options_VectorOptions_, axisConstraint:DG.Tweening.AxisConstraint):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_, axisConstraint:DG.Tweening.AxisConstraint, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_, axisConstraint:DG.Tweening.AxisConstraint):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector4_UnityEngine_Vector4_DG_Tweening_Plugins_Options_VectorOptions_, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector4_UnityEngine_Vector4_DG_Tweening_Plugins_Options_VectorOptions_, axisConstraint:DG.Tweening.AxisConstraint, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector4_UnityEngine_Vector4_DG_Tweening_Plugins_Options_VectorOptions_, axisConstraint:DG.Tweening.AxisConstraint):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Quaternion_UnityEngine_Vector3_DG_Tweening_Plugins_Options_QuaternionOptions_, useShortest360Route:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Quaternion_UnityEngine_Vector3_DG_Tweening_Plugins_Options_QuaternionOptions_):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Color_UnityEngine_Color_DG_Tweening_Plugins_Options_ColorOptions_, alphaOnly:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Rect_UnityEngine_Rect_DG_Tweening_Plugins_Options_RectOptions_, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_System_String_System_String_DG_Tweening_Plugins_Options_StringOptions_, richTextEnabled:boolean, scrambleMode:DG.Tweening.ScrambleMode, scrambleChars:string):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_System_String_System_String_DG_Tweening_Plugins_Options_StringOptions_, richTextEnabled:boolean, scrambleMode:DG.Tweening.ScrambleMode):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_System_String_System_String_DG_Tweening_Plugins_Options_StringOptions_, richTextEnabled:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_, axisConstraint:DG.Tweening.AxisConstraint, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_, axisConstraint:DG.Tweening.AxisConstraint):DG.Tweening.Tweener @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, lockPosition:DG.Tweening.AxisConstraint, lockRotation:DG.Tweening.AxisConstraint):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, lockPosition:DG.Tweening.AxisConstraint):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, closePath:boolean, lockPosition:DG.Tweening.AxisConstraint, lockRotation:DG.Tweening.AxisConstraint):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, closePath:boolean, lockPosition:DG.Tweening.AxisConstraint):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, closePath:boolean):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@static
---@param t DG.Tweening.Core.TweenerCore_3_System_Single_System_Single_DG_Tweening_Plugins_Options_FloatOptions_
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.SetOptions(t, snapping) end

---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, lookAtPosition:UnityEngine.Vector3, forwardDirection:System.Nullable_1_UnityEngine_Vector3_):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, lookAtPosition:UnityEngine.Vector3):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, lookAtTransform:UnityEngine.Transform, forwardDirection:System.Nullable_1_UnityEngine_Vector3_, up:System.Nullable_1_UnityEngine_Vector3_):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, lookAtTransform:UnityEngine.Transform, forwardDirection:System.Nullable_1_UnityEngine_Vector3_):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, lookAtTransform:UnityEngine.Transform):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, lookAhead:number, forwardDirection:System.Nullable_1_UnityEngine_Vector3_, up:System.Nullable_1_UnityEngine_Vector3_):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, lookAhead:number, forwardDirection:System.Nullable_1_UnityEngine_Vector3_):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(t:DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_, lookAhead:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@static
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
---@param lookAtPosition UnityEngine.Vector3
---@param forwardDirection System.Nullable_1_UnityEngine_Vector3_
---@param up System.Nullable_1_UnityEngine_Vector3_
---@return DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
function m.SetLookAt(t, lookAtPosition, forwardDirection, up) end

DG.Tweening.TweenSettingsExtensions = m
return m
