---@class DG.Tweening.IDOTweenInit : table
local m = {}

---@abstract
---@param tweenersCapacity number
---@param sequencesCapacity number
---@return DG.Tweening.IDOTweenInit
function m:SetCapacity(tweenersCapacity, sequencesCapacity) end

DG.Tweening.IDOTweenInit = m
return m
