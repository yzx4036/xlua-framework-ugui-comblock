---@class DG.Tweening.Plugins.Options.IPlugOptions : table
local m = {}

---@abstract
function m:Reset() end

DG.Tweening.Plugins.Options.IPlugOptions = m
return m
