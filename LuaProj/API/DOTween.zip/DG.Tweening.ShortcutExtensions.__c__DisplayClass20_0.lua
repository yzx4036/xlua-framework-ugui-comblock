---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass20_0 : System.Object
---@field public target UnityEngine.Material
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass20_0 = m
return m
