---@class DG.Tweening.Plugins.Options.PathOptions : System.ValueType
---@field public mode DG.Tweening.PathMode
---@field public orientType DG.Tweening.Plugins.Options.OrientType
---@field public lockPositionAxis DG.Tweening.AxisConstraint
---@field public lockRotationAxis DG.Tweening.AxisConstraint
---@field public isClosedPath boolean
---@field public lookAtPosition UnityEngine.Vector3
---@field public lookAtTransform UnityEngine.Transform
---@field public lookAhead number
---@field public hasCustomForwardDirection boolean
---@field public forward UnityEngine.Quaternion
---@field public useLocalPosition boolean
---@field public parent UnityEngine.Transform
---@field public isRigidbody boolean
local m = {}

---@virtual
function m:Reset() end

DG.Tweening.Plugins.Options.PathOptions = m
return m
