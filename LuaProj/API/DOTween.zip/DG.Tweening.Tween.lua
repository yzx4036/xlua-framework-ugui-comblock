---@class DG.Tweening.Tween : DG.Tweening.Core.ABSSequentiable
---@field public timeScale number
---@field public isBackwards boolean
---@field public id any
---@field public target any
---@field public onPlay fun()
---@field public onPause fun()
---@field public onRewind fun()
---@field public onUpdate fun()
---@field public onStepComplete fun()
---@field public onComplete fun()
---@field public onKill fun()
---@field public onWaypointChange fun(value:number)
---@field public easeOvershootOrAmplitude number
---@field public easePeriod number
---@field public fullPosition number
local m = {}

DG.Tweening.Tween = m
return m
