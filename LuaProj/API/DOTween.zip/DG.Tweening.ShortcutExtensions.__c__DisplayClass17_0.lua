---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass17_0 : System.Object
---@field public startValue DG.Tweening.Color2
---@field public target UnityEngine.LineRenderer
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass17_0 = m
return m
