---@class DG.Tweening.Plugins.Options.QuaternionOptions : System.ValueType
local m = {}

---@virtual
function m:Reset() end

DG.Tweening.Plugins.Options.QuaternionOptions = m
return m
