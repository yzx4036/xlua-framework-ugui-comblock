---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass3_0 : System.Object
---@field public target UnityEngine.Camera
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass3_0 = m
return m
