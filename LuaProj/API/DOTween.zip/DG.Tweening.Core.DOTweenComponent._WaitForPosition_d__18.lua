---@class DG.Tweening.Core.DOTweenComponent._WaitForPosition_d__18 : System.Object
---@field public t DG.Tweening.Tween
---@field public position number
local m = {}

DG.Tweening.Core.DOTweenComponent._WaitForPosition_d__18 = m
return m
