---@class DG.Tweening.Core.Enums.OperationType : System.Enum
---@field public Complete DG.Tweening.Core.Enums.OperationType @static
---@field public Despawn DG.Tweening.Core.Enums.OperationType @static
---@field public Flip DG.Tweening.Core.Enums.OperationType @static
---@field public Goto DG.Tweening.Core.Enums.OperationType @static
---@field public Pause DG.Tweening.Core.Enums.OperationType @static
---@field public Play DG.Tweening.Core.Enums.OperationType @static
---@field public PlayForward DG.Tweening.Core.Enums.OperationType @static
---@field public PlayBackwards DG.Tweening.Core.Enums.OperationType @static
---@field public Rewind DG.Tweening.Core.Enums.OperationType @static
---@field public SmoothRewind DG.Tweening.Core.Enums.OperationType @static
---@field public Restart DG.Tweening.Core.Enums.OperationType @static
---@field public TogglePause DG.Tweening.Core.Enums.OperationType @static
---@field public IsTweening DG.Tweening.Core.Enums.OperationType @static
---@field public value__ number
local m = {}

DG.Tweening.Core.Enums.OperationType = m
return m
