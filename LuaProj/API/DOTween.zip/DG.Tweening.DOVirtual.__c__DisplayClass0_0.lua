---@class DG.Tweening.DOVirtual.__c__DisplayClass0_0 : System.Object
---@field public val number
---@field public onVirtualUpdate fun(value:number)
local m = {}

DG.Tweening.DOVirtual.__c__DisplayClass0_0 = m
return m
