---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass69_0 : System.Object
---@field public target UnityEngine.Transform
---@field public offsetYSet boolean
---@field public offsetY number
---@field public s DG.Tweening.Sequence
---@field public endValue UnityEngine.Vector3
---@field public startPosY number
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass69_0 = m
return m
