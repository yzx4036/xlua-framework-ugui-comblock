---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass32_0 : System.Object
---@field public target UnityEngine.Rigidbody
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass32_0 = m
return m
