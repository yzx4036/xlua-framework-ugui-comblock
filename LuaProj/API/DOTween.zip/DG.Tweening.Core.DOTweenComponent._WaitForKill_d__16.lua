---@class DG.Tweening.Core.DOTweenComponent._WaitForKill_d__16 : System.Object
---@field public t DG.Tweening.Tween
local m = {}

DG.Tweening.Core.DOTweenComponent._WaitForKill_d__16 = m
return m
