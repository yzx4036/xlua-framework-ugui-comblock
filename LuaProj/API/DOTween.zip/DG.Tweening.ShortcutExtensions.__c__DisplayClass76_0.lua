---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass76_0 : System.Object
---@field public to UnityEngine.Color
---@field public target UnityEngine.Material
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass76_0 = m
return m
