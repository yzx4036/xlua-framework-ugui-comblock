---@class DG.Tweening.Plugins.RectPlugin : DG.Tweening.Plugins.Core.ABSTweenPlugin_3_UnityEngine_Rect_UnityEngine_Rect_DG_Tweening_Plugins_Options_RectOptions_
local m = {}

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Rect_UnityEngine_Rect_DG_Tweening_Plugins_Options_RectOptions_
function m:Reset(t) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Rect_UnityEngine_Rect_DG_Tweening_Plugins_Options_RectOptions_
---@param isRelative boolean
function m:SetFrom(t, isRelative) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Rect_UnityEngine_Rect_DG_Tweening_Plugins_Options_RectOptions_
---@param value UnityEngine.Rect
---@return UnityEngine.Rect
function m:ConvertToStartValue(t, value) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Rect_UnityEngine_Rect_DG_Tweening_Plugins_Options_RectOptions_
function m:SetRelativeEndValue(t) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Rect_UnityEngine_Rect_DG_Tweening_Plugins_Options_RectOptions_
function m:SetChangeValue(t) end

---@virtual
---@param options DG.Tweening.Plugins.Options.RectOptions
---@param unitsXSecond number
---@param changeValue UnityEngine.Rect
---@return number
function m:GetSpeedBasedDuration(options, unitsXSecond, changeValue) end

---@virtual
---@param options DG.Tweening.Plugins.Options.RectOptions
---@param t DG.Tweening.Tween
---@param isRelative boolean
---@param getter fun():UnityEngine.Rect
---@param setter fun(pNewValue:UnityEngine.Rect)
---@param elapsed number
---@param startValue UnityEngine.Rect
---@param changeValue UnityEngine.Rect
---@param duration number
---@param usingInversePosition boolean
---@param updateNotice DG.Tweening.Core.Enums.UpdateNotice
function m:EvaluateAndApply(options, t, isRelative, getter, setter, elapsed, startValue, changeValue, duration, usingInversePosition, updateNotice) end

DG.Tweening.Plugins.RectPlugin = m
return m
