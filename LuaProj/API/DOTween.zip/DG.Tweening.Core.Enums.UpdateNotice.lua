---@class DG.Tweening.Core.Enums.UpdateNotice : System.Enum
---@field public None DG.Tweening.Core.Enums.UpdateNotice @static
---@field public RewindStep DG.Tweening.Core.Enums.UpdateNotice @static
---@field public value__ number
local m = {}

DG.Tweening.Core.Enums.UpdateNotice = m
return m
