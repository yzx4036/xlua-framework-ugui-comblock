---@class DG.Tweening.RotateMode : System.Enum
---@field public Fast DG.Tweening.RotateMode @static
---@field public FastBeyond360 DG.Tweening.RotateMode @static
---@field public WorldAxisAdd DG.Tweening.RotateMode @static
---@field public LocalAxisAdd DG.Tweening.RotateMode @static
---@field public value__ number
local m = {}

DG.Tweening.RotateMode = m
return m
