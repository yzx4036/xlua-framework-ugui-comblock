---@class DG.Tweening.Plugins.UlongPlugin : DG.Tweening.Plugins.Core.ABSTweenPlugin_3_System_UInt64_System_UInt64_DG_Tweening_Plugins_Options_NoOptions_
local m = {}

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_System_UInt64_System_UInt64_DG_Tweening_Plugins_Options_NoOptions_
function m:Reset(t) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_System_UInt64_System_UInt64_DG_Tweening_Plugins_Options_NoOptions_
---@param isRelative boolean
function m:SetFrom(t, isRelative) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_System_UInt64_System_UInt64_DG_Tweening_Plugins_Options_NoOptions_
---@param value number
---@return number
function m:ConvertToStartValue(t, value) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_System_UInt64_System_UInt64_DG_Tweening_Plugins_Options_NoOptions_
function m:SetRelativeEndValue(t) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_System_UInt64_System_UInt64_DG_Tweening_Plugins_Options_NoOptions_
function m:SetChangeValue(t) end

---@virtual
---@param options DG.Tweening.Plugins.Options.NoOptions
---@param unitsXSecond number
---@param changeValue number
---@return number
function m:GetSpeedBasedDuration(options, unitsXSecond, changeValue) end

---@virtual
---@param options DG.Tweening.Plugins.Options.NoOptions
---@param t DG.Tweening.Tween
---@param isRelative boolean
---@param getter fun():number
---@param setter fun(pNewValue:number)
---@param elapsed number
---@param startValue number
---@param changeValue number
---@param duration number
---@param usingInversePosition boolean
---@param updateNotice DG.Tweening.Core.Enums.UpdateNotice
function m:EvaluateAndApply(options, t, isRelative, getter, setter, elapsed, startValue, changeValue, duration, usingInversePosition, updateNotice) end

DG.Tweening.Plugins.UlongPlugin = m
return m
