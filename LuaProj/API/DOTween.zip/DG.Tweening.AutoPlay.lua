---@class DG.Tweening.AutoPlay : System.Enum
---@field public None DG.Tweening.AutoPlay @static
---@field public AutoPlaySequences DG.Tweening.AutoPlay @static
---@field public AutoPlayTweeners DG.Tweening.AutoPlay @static
---@field public All DG.Tweening.AutoPlay @static
---@field public value__ number
local m = {}

DG.Tweening.AutoPlay = m
return m
