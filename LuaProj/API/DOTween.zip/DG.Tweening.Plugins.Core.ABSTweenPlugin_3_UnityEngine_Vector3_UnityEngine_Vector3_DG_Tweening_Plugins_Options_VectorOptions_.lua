---@class DG.Tweening.Plugins.Core.ABSTweenPlugin_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_ : System.Object
local m = {}

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_
function m:Reset(t) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_
---@param isRelative boolean
function m:SetFrom(t, isRelative) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_
---@param value UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:ConvertToStartValue(t, value) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_
function m:SetRelativeEndValue(t) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_
function m:SetChangeValue(t) end

---@abstract
---@param options DG.Tweening.Plugins.Options.VectorOptions
---@param unitsXSecond number
---@param changeValue UnityEngine.Vector3
---@return number
function m:GetSpeedBasedDuration(options, unitsXSecond, changeValue) end

---@abstract
---@param options DG.Tweening.Plugins.Options.VectorOptions
---@param t DG.Tweening.Tween
---@param isRelative boolean
---@param getter fun():UnityEngine.Vector3
---@param setter fun(pNewValue:UnityEngine.Vector3)
---@param elapsed number
---@param startValue UnityEngine.Vector3
---@param changeValue UnityEngine.Vector3
---@param duration number
---@param usingInversePosition boolean
---@param updateNotice DG.Tweening.Core.Enums.UpdateNotice
function m:EvaluateAndApply(options, t, isRelative, getter, setter, elapsed, startValue, changeValue, duration, usingInversePosition, updateNotice) end

DG.Tweening.Plugins.Core.ABSTweenPlugin_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_ = m
return m
