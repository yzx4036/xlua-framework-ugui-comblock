---@class DG.Tweening.Core.DOTweenSettings : UnityEngine.ScriptableObject
---@field public AssetName string @static
---@field public useSafeMode boolean
---@field public timeScale number
---@field public useSmoothDeltaTime boolean
---@field public maxSmoothUnscaledTime number
---@field public showUnityEditorReport boolean
---@field public logBehaviour DG.Tweening.LogBehaviour
---@field public drawGizmos boolean
---@field public defaultRecyclable boolean
---@field public defaultAutoPlay DG.Tweening.AutoPlay
---@field public defaultUpdateType DG.Tweening.UpdateType
---@field public defaultTimeScaleIndependent boolean
---@field public defaultEaseType DG.Tweening.Ease
---@field public defaultEaseOvershootOrAmplitude number
---@field public defaultEasePeriod number
---@field public defaultAutoKill boolean
---@field public defaultLoopType DG.Tweening.LoopType
---@field public storeSettingsLocation DG.Tweening.Core.DOTweenSettings.SettingsLocation
local m = {}

DG.Tweening.Core.DOTweenSettings = m
return m
