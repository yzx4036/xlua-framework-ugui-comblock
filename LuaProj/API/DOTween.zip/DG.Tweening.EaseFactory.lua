---@class DG.Tweening.EaseFactory : System.Object
local m = {}

---@overload fun(motionFps:number):(fun(time:number, duration:number, overshootOrAmplitude:number, period:number):number) @static
---@overload fun(motionFps:number, animCurve:UnityEngine.AnimationCurve):(fun(time:number, duration:number, overshootOrAmplitude:number, period:number):number) @static
---@overload fun(motionFps:number, customEase:(fun(time:number, duration:number, overshootOrAmplitude:number, period:number):number)):(fun(time:number, duration:number, overshootOrAmplitude:number, period:number):number) @static
---@static
---@param motionFps number
---@param ease System.Nullable_1_DG_Tweening_Ease_
---@return fun(time:number, duration:number, overshootOrAmplitude:number, period:number):number
function m.StopMotion(motionFps, ease) end

DG.Tweening.EaseFactory = m
return m
