---@class DG.Tweening.TweenCallback_1_T_ : System.MulticastDelegate
local m = {}

---@virtual
---@param value any
function m:Invoke(value) end

---@virtual
---@param value any
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(value, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

DG.Tweening.TweenCallback_1_T_ = m
return m
