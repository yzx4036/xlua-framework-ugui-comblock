---@class _PrivateImplementationDetails_.__StaticArrayInitTypeSize_20 : System.ValueType
local m = {}

_PrivateImplementationDetails_.__StaticArrayInitTypeSize_20 = m
return m
