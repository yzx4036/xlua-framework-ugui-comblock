---@class DG.Tweening.Core.TweenerCore_3_T1_T2_TPlugOptions_ : DG.Tweening.Tweener
---@field public startValue any
---@field public endValue any
---@field public changeValue any
---@field public plugOptions System.ValueType
---@field public getter fun():any
---@field public setter fun(pNewValue:any)
local m = {}

---@overload fun(newStartValue:any):DG.Tweening.Tweener @virtual
---@virtual
---@param newStartValue any
---@param newDuration number
---@return DG.Tweening.Tweener
function m:ChangeStartValue(newStartValue, newDuration) end

---@overload fun(newEndValue:any, newDuration:number, snapStartValue:boolean):DG.Tweening.Tweener @virtual
---@overload fun(newEndValue:any, newDuration:number):DG.Tweening.Tweener @virtual
---@overload fun(newEndValue:any):DG.Tweening.Tweener @virtual
---@virtual
---@param newEndValue any
---@param snapStartValue boolean
---@return DG.Tweening.Tweener
function m:ChangeEndValue(newEndValue, snapStartValue) end

---@overload fun(newStartValue:any, newEndValue:any):DG.Tweening.Tweener @virtual
---@virtual
---@param newStartValue any
---@param newEndValue any
---@param newDuration number
---@return DG.Tweening.Tweener
function m:ChangeValues(newStartValue, newEndValue, newDuration) end

DG.Tweening.Core.TweenerCore_3_T1_T2_TPlugOptions_ = m
return m
