---@class DG.Tweening.LogBehaviour : System.Enum
---@field public Default DG.Tweening.LogBehaviour @static
---@field public Verbose DG.Tweening.LogBehaviour @static
---@field public ErrorsOnly DG.Tweening.LogBehaviour @static
---@field public value__ number
local m = {}

DG.Tweening.LogBehaviour = m
return m
