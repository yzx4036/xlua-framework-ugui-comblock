---@class DG.Tweening.Plugins.PathPlugin : DG.Tweening.Plugins.Core.ABSTweenPlugin_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
---@field public MinLookAhead number @static
local m = {}

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
function m:Reset(t) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
---@param isRelative boolean
function m:SetFrom(t, isRelative) end

---@static
---@return DG.Tweening.Plugins.Core.ABSTweenPlugin_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
function m.Get() end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
---@param value UnityEngine.Vector3
---@return DG.Tweening.Plugins.Core.PathCore.Path
function m:ConvertToStartValue(t, value) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
function m:SetRelativeEndValue(t) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
function m:SetChangeValue(t) end

---@virtual
---@param options DG.Tweening.Plugins.Options.PathOptions
---@param unitsXSecond number
---@param changeValue DG.Tweening.Plugins.Core.PathCore.Path
---@return number
function m:GetSpeedBasedDuration(options, unitsXSecond, changeValue) end

---@virtual
---@param options DG.Tweening.Plugins.Options.PathOptions
---@param t DG.Tweening.Tween
---@param isRelative boolean
---@param getter fun():UnityEngine.Vector3
---@param setter fun(pNewValue:UnityEngine.Vector3)
---@param elapsed number
---@param startValue DG.Tweening.Plugins.Core.PathCore.Path
---@param changeValue DG.Tweening.Plugins.Core.PathCore.Path
---@param duration number
---@param usingInversePosition boolean
---@param updateNotice DG.Tweening.Core.Enums.UpdateNotice
function m:EvaluateAndApply(options, t, isRelative, getter, setter, elapsed, startValue, changeValue, duration, usingInversePosition, updateNotice) end

---@param options DG.Tweening.Plugins.Options.PathOptions
---@param t DG.Tweening.Tween
---@param path DG.Tweening.Plugins.Core.PathCore.Path
---@param pathPerc number
---@param tPos UnityEngine.Vector3
---@param updateNotice DG.Tweening.Core.Enums.UpdateNotice
function m:SetOrientation(options, t, path, pathPerc, tPos, updateNotice) end

DG.Tweening.Plugins.PathPlugin = m
return m
