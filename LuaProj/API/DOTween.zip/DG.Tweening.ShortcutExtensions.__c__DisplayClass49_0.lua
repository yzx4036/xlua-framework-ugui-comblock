---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass49_0 : System.Object
---@field public target UnityEngine.Transform
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass49_0 = m
return m
