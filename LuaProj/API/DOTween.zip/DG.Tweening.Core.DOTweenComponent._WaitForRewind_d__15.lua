---@class DG.Tweening.Core.DOTweenComponent._WaitForRewind_d__15 : System.Object
---@field public t DG.Tweening.Tween
local m = {}

DG.Tweening.Core.DOTweenComponent._WaitForRewind_d__15 = m
return m
