---@class DG.Tweening.Core.SequenceCallback : DG.Tweening.Core.ABSSequentiable
local m = {}

DG.Tweening.Core.SequenceCallback = m
return m
