---@class DG.Tweening.Plugins.Core.IPlugSetter_4_T1_T2_TPlugin_TPlugOptions_ : table
local m = {}

---@abstract
---@return fun():any
function m:Getter() end

---@abstract
---@return fun(pNewValue:any)
function m:Setter() end

---@abstract
---@return any
function m:EndValue() end

---@abstract
---@return any
function m:GetOptions() end

DG.Tweening.Plugins.Core.IPlugSetter_4_T1_T2_TPlugin_TPlugOptions_ = m
return m
