---@class DG.Tweening.Plugins.Options.Vector3ArrayOptions : System.ValueType
---@field public axisConstraint DG.Tweening.AxisConstraint
---@field public snapping boolean
local m = {}

---@virtual
function m:Reset() end

DG.Tweening.Plugins.Options.Vector3ArrayOptions = m
return m
