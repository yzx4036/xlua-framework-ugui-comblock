---@class DG.Tweening.Plugins.Core.ABSTweenPlugin_3_UnityEngine_Quaternion_UnityEngine_Quaternion_DG_Tweening_Plugins_Options_NoOptions_ : System.Object
local m = {}

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Quaternion_UnityEngine_Quaternion_DG_Tweening_Plugins_Options_NoOptions_
function m:Reset(t) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Quaternion_UnityEngine_Quaternion_DG_Tweening_Plugins_Options_NoOptions_
---@param isRelative boolean
function m:SetFrom(t, isRelative) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Quaternion_UnityEngine_Quaternion_DG_Tweening_Plugins_Options_NoOptions_
---@param value UnityEngine.Quaternion
---@return UnityEngine.Quaternion
function m:ConvertToStartValue(t, value) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Quaternion_UnityEngine_Quaternion_DG_Tweening_Plugins_Options_NoOptions_
function m:SetRelativeEndValue(t) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Quaternion_UnityEngine_Quaternion_DG_Tweening_Plugins_Options_NoOptions_
function m:SetChangeValue(t) end

---@abstract
---@param options DG.Tweening.Plugins.Options.NoOptions
---@param unitsXSecond number
---@param changeValue UnityEngine.Quaternion
---@return number
function m:GetSpeedBasedDuration(options, unitsXSecond, changeValue) end

---@abstract
---@param options DG.Tweening.Plugins.Options.NoOptions
---@param t DG.Tweening.Tween
---@param isRelative boolean
---@param getter fun():UnityEngine.Quaternion
---@param setter fun(pNewValue:UnityEngine.Quaternion)
---@param elapsed number
---@param startValue UnityEngine.Quaternion
---@param changeValue UnityEngine.Quaternion
---@param duration number
---@param usingInversePosition boolean
---@param updateNotice DG.Tweening.Core.Enums.UpdateNotice
function m:EvaluateAndApply(options, t, isRelative, getter, setter, elapsed, startValue, changeValue, duration, usingInversePosition, updateNotice) end

DG.Tweening.Plugins.Core.ABSTweenPlugin_3_UnityEngine_Quaternion_UnityEngine_Quaternion_DG_Tweening_Plugins_Options_NoOptions_ = m
return m
