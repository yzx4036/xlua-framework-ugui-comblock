---@class DG.Tweening.Core.Enums.FilterType : System.Enum
---@field public All DG.Tweening.Core.Enums.FilterType @static
---@field public TargetOrId DG.Tweening.Core.Enums.FilterType @static
---@field public TargetAndId DG.Tweening.Core.Enums.FilterType @static
---@field public AllExceptTargetsOrIds DG.Tweening.Core.Enums.FilterType @static
---@field public DOGetter DG.Tweening.Core.Enums.FilterType @static
---@field public value__ number
local m = {}

DG.Tweening.Core.Enums.FilterType = m
return m
