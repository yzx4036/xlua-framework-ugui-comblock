---@class DG.Tweening.ShortcutExtensions : System.Object
local m = {}

---@overload fun(target:UnityEngine.Material, endValue:number, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Material, endValue:number, property:string, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.AudioSource
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOFade(target, endValue, duration) end

---@static
---@param target UnityEngine.AudioSource
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOPitch(target, endValue, duration) end

---@static
---@param target UnityEngine.Camera
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOAspect(target, endValue, duration) end

---@overload fun(target:UnityEngine.Light, endValue:UnityEngine.Color, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.LineRenderer, startValue:DG.Tweening.Color2, endValue:DG.Tweening.Color2, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Material, endValue:UnityEngine.Color, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Material, endValue:UnityEngine.Color, property:string, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Camera
---@param endValue UnityEngine.Color
---@param duration number
---@return DG.Tweening.Tweener
function m.DOColor(target, endValue, duration) end

---@static
---@param target UnityEngine.Camera
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOFarClipPlane(target, endValue, duration) end

---@static
---@param target UnityEngine.Camera
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOFieldOfView(target, endValue, duration) end

---@static
---@param target UnityEngine.Camera
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DONearClipPlane(target, endValue, duration) end

---@static
---@param target UnityEngine.Camera
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOOrthoSize(target, endValue, duration) end

---@static
---@param target UnityEngine.Camera
---@param endValue UnityEngine.Rect
---@param duration number
---@return DG.Tweening.Tweener
function m.DOPixelRect(target, endValue, duration) end

---@static
---@param target UnityEngine.Camera
---@param endValue UnityEngine.Rect
---@param duration number
---@return DG.Tweening.Tweener
function m.DORect(target, endValue, duration) end

---@overload fun(target:UnityEngine.Camera, duration:number, strength:number, vibrato:number, randomness:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:number, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number, fadeOut:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:UnityEngine.Vector3, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:UnityEngine.Vector3):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number, vibrato:number, randomness:number, snapping:boolean, fadeOut:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number, vibrato:number, randomness:number, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number, vibrato:number, randomness:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number, snapping:boolean, fadeOut:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Camera
---@param duration number
---@param strength number
---@param vibrato number
---@param randomness number
---@param fadeOut boolean
---@return DG.Tweening.Tweener
function m.DOShakePosition(target, duration, strength, vibrato, randomness, fadeOut) end

---@overload fun(target:UnityEngine.Camera, duration:number, strength:number, vibrato:number, randomness:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:number, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number, fadeOut:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:UnityEngine.Vector3, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Camera, duration:number, strength:UnityEngine.Vector3):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number, vibrato:number, randomness:number, fadeOut:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number, vibrato:number, randomness:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number, fadeOut:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Camera
---@param duration number
---@param strength number
---@param vibrato number
---@param randomness number
---@param fadeOut boolean
---@return DG.Tweening.Tweener
function m.DOShakeRotation(target, duration, strength, vibrato, randomness, fadeOut) end

---@static
---@param target UnityEngine.Light
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOIntensity(target, endValue, duration) end

---@static
---@param target UnityEngine.Light
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOShadowStrength(target, endValue, duration) end

---@static
---@param target UnityEngine.Material
---@param endValue number
---@param property string
---@param duration number
---@return DG.Tweening.Tweener
function m.DOFloat(target, endValue, property, duration) end

---@overload fun(target:UnityEngine.Material, endValue:UnityEngine.Vector2, property:string, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Material
---@param endValue UnityEngine.Vector2
---@param duration number
---@return DG.Tweening.Tweener
function m.DOOffset(target, endValue, duration) end

---@overload fun(target:UnityEngine.Material, endValue:UnityEngine.Vector2, property:string, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Material
---@param endValue UnityEngine.Vector2
---@param duration number
---@return DG.Tweening.Tweener
function m.DOTiling(target, endValue, duration) end

---@static
---@param target UnityEngine.Material
---@param endValue UnityEngine.Vector4
---@param property string
---@param duration number
---@return DG.Tweening.Tweener
function m.DOVector(target, endValue, property, duration) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, endValue:UnityEngine.Vector3, duration:number, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, endValue:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue UnityEngine.Vector3
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMove(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:number, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, endValue:number, duration:number, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, endValue:number, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMoveX(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:number, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, endValue:number, duration:number, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, endValue:number, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMoveY(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:number, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, endValue:number, duration:number, snapping:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, endValue:number, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMoveZ(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, endValue:UnityEngine.Vector3, duration:number, mode:DG.Tweening.RotateMode):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, endValue:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue UnityEngine.Vector3
---@param duration number
---@param mode DG.Tweening.RotateMode
---@return DG.Tweening.Tweener
function m.DORotate(target, endValue, duration, mode) end

---@overload fun(target:UnityEngine.Rigidbody, towards:UnityEngine.Vector3, duration:number, axisConstraint:DG.Tweening.AxisConstraint):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Rigidbody, towards:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, towards:UnityEngine.Vector3, duration:number, axisConstraint:DG.Tweening.AxisConstraint, up:System.Nullable_1_UnityEngine_Vector3_):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, towards:UnityEngine.Vector3, duration:number, axisConstraint:DG.Tweening.AxisConstraint):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, towards:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Rigidbody
---@param towards UnityEngine.Vector3
---@param duration number
---@param axisConstraint DG.Tweening.AxisConstraint
---@param up System.Nullable_1_UnityEngine_Vector3_
---@return DG.Tweening.Tweener
function m.DOLookAt(target, towards, duration, axisConstraint, up) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:UnityEngine.Vector3, jumpPower:number, numJumps:number, duration:number):DG.Tweening.Sequence @static
---@overload fun(target:UnityEngine.Transform, endValue:UnityEngine.Vector3, jumpPower:number, numJumps:number, duration:number, snapping:boolean):DG.Tweening.Sequence @static
---@overload fun(target:UnityEngine.Transform, endValue:UnityEngine.Vector3, jumpPower:number, numJumps:number, duration:number):DG.Tweening.Sequence @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue UnityEngine.Vector3
---@param jumpPower number
---@param numJumps number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Sequence
function m.DOJump(target, endValue, jumpPower, numJumps, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode, resolution:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Transform, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode, resolution:number, gizmoColor:System.Nullable_1_UnityEngine_Color_):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Transform, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode, resolution:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Transform, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Transform, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Transform, path:UnityEngine.Vector3[], duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@static
---@param target UnityEngine.Rigidbody
---@param path UnityEngine.Vector3[]
---@param duration number
---@param pathType DG.Tweening.PathType
---@param pathMode DG.Tweening.PathMode
---@param resolution number
---@param gizmoColor System.Nullable_1_UnityEngine_Color_
---@return DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
function m.DOPath(target, path, duration, pathType, pathMode, resolution, gizmoColor) end

---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode, resolution:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Transform, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode, resolution:number, gizmoColor:System.Nullable_1_UnityEngine_Color_):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Transform, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode, resolution:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Transform, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Transform, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@overload fun(target:UnityEngine.Transform, path:UnityEngine.Vector3[], duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_ @static
---@static
---@param target UnityEngine.Rigidbody
---@param path UnityEngine.Vector3[]
---@param duration number
---@param pathType DG.Tweening.PathType
---@param pathMode DG.Tweening.PathMode
---@param resolution number
---@param gizmoColor System.Nullable_1_UnityEngine_Color_
---@return DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
function m.DOLocalPath(target, path, duration, pathType, pathMode, resolution, gizmoColor) end

---@static
---@param target UnityEngine.TrailRenderer
---@param toStartWidth number
---@param toEndWidth number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOResize(target, toStartWidth, toEndWidth, duration) end

---@static
---@param target UnityEngine.TrailRenderer
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOTime(target, endValue, duration) end

---@overload fun(target:UnityEngine.Transform, endValue:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param endValue UnityEngine.Vector3
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOLocalMove(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Transform, endValue:number, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOLocalMoveX(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Transform, endValue:number, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOLocalMoveY(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Transform, endValue:number, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOLocalMoveZ(target, endValue, duration, snapping) end

---@static
---@param target UnityEngine.Transform
---@param endValue UnityEngine.Quaternion
---@param duration number
---@return DG.Tweening.Tweener
function m.DORotateQuaternion(target, endValue, duration) end

---@overload fun(target:UnityEngine.Transform, endValue:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param endValue UnityEngine.Vector3
---@param duration number
---@param mode DG.Tweening.RotateMode
---@return DG.Tweening.Tweener
function m.DOLocalRotate(target, endValue, duration, mode) end

---@static
---@param target UnityEngine.Transform
---@param endValue UnityEngine.Quaternion
---@param duration number
---@return DG.Tweening.Tweener
function m.DOLocalRotateQuaternion(target, endValue, duration) end

---@overload fun(target:UnityEngine.Transform, endValue:number, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param endValue UnityEngine.Vector3
---@param duration number
---@return DG.Tweening.Tweener
function m.DOScale(target, endValue, duration) end

---@static
---@param target UnityEngine.Transform
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOScaleX(target, endValue, duration) end

---@static
---@param target UnityEngine.Transform
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOScaleY(target, endValue, duration) end

---@static
---@param target UnityEngine.Transform
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOScaleZ(target, endValue, duration) end

---@overload fun(target:UnityEngine.Transform, punch:UnityEngine.Vector3, duration:number, vibrato:number, elasticity:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, punch:UnityEngine.Vector3, duration:number, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, punch:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param punch UnityEngine.Vector3
---@param duration number
---@param vibrato number
---@param elasticity number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOPunchPosition(target, punch, duration, vibrato, elasticity, snapping) end

---@overload fun(target:UnityEngine.Transform, punch:UnityEngine.Vector3, duration:number, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, punch:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param punch UnityEngine.Vector3
---@param duration number
---@param vibrato number
---@param elasticity number
---@return DG.Tweening.Tweener
function m.DOPunchScale(target, punch, duration, vibrato, elasticity) end

---@overload fun(target:UnityEngine.Transform, punch:UnityEngine.Vector3, duration:number, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, punch:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param punch UnityEngine.Vector3
---@param duration number
---@param vibrato number
---@param elasticity number
---@return DG.Tweening.Tweener
function m.DOPunchRotation(target, punch, duration, vibrato, elasticity) end

---@overload fun(target:UnityEngine.Transform, duration:number, strength:number, vibrato:number, randomness:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number, fadeOut:boolean):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3, vibrato:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, strength:UnityEngine.Vector3):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param duration number
---@param strength number
---@param vibrato number
---@param randomness number
---@param fadeOut boolean
---@return DG.Tweening.Tweener
function m.DOShakeScale(target, duration, strength, vibrato, randomness, fadeOut) end

---@overload fun(target:UnityEngine.Transform, endValue:UnityEngine.Vector3, jumpPower:number, numJumps:number, duration:number):DG.Tweening.Sequence @static
---@static
---@param target UnityEngine.Transform
---@param endValue UnityEngine.Vector3
---@param jumpPower number
---@param numJumps number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Sequence
function m.DOLocalJump(target, endValue, jumpPower, numJumps, duration, snapping) end

---@static
---@param target DG.Tweening.Tween
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOTimeScale(target, endValue, duration) end

---@overload fun(target:UnityEngine.Material, endValue:UnityEngine.Color, duration:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Material, endValue:UnityEngine.Color, property:string, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Light
---@param endValue UnityEngine.Color
---@param duration number
---@return DG.Tweening.Tweener
function m.DOBlendableColor(target, endValue, duration) end

---@overload fun(target:UnityEngine.Transform, byValue:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param byValue UnityEngine.Vector3
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOBlendableMoveBy(target, byValue, duration, snapping) end

---@overload fun(target:UnityEngine.Transform, byValue:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param byValue UnityEngine.Vector3
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOBlendableLocalMoveBy(target, byValue, duration, snapping) end

---@overload fun(target:UnityEngine.Transform, byValue:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param byValue UnityEngine.Vector3
---@param duration number
---@param mode DG.Tweening.RotateMode
---@return DG.Tweening.Tweener
function m.DOBlendableRotateBy(target, byValue, duration, mode) end

---@overload fun(target:UnityEngine.Transform, byValue:UnityEngine.Vector3, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param byValue UnityEngine.Vector3
---@param duration number
---@param mode DG.Tweening.RotateMode
---@return DG.Tweening.Tweener
function m.DOBlendableLocalRotateBy(target, byValue, duration, mode) end

---@static
---@param target UnityEngine.Transform
---@param byValue UnityEngine.Vector3
---@param duration number
---@return DG.Tweening.Tweener
function m.DOBlendableScaleBy(target, byValue, duration) end

---@overload fun(target:UnityEngine.Component):number @static
---@overload fun(target:UnityEngine.Material, withCallbacks:boolean):number @static
---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@param withCallbacks boolean
---@return number
function m.DOComplete(target, withCallbacks) end

---@overload fun(target:UnityEngine.Component):number @static
---@overload fun(target:UnityEngine.Material, complete:boolean):number @static
---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@param complete boolean
---@return number
function m.DOKill(target, complete) end

---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@return number
function m.DOFlip(target) end

---@overload fun(target:UnityEngine.Component, to:number):number @static
---@overload fun(target:UnityEngine.Material, to:number, andPlay:boolean):number @static
---@overload fun(target:UnityEngine.Material, to:number):number @static
---@static
---@param target UnityEngine.Component
---@param to number
---@param andPlay boolean
---@return number
function m.DOGoto(target, to, andPlay) end

---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@return number
function m.DOPause(target) end

---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@return number
function m.DOPlay(target) end

---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@return number
function m.DOPlayBackwards(target) end

---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@return number
function m.DOPlayForward(target) end

---@overload fun(target:UnityEngine.Component):number @static
---@overload fun(target:UnityEngine.Material, includeDelay:boolean):number @static
---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@param includeDelay boolean
---@return number
function m.DORestart(target, includeDelay) end

---@overload fun(target:UnityEngine.Component):number @static
---@overload fun(target:UnityEngine.Material, includeDelay:boolean):number @static
---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@param includeDelay boolean
---@return number
function m.DORewind(target, includeDelay) end

---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@return number
function m.DOSmoothRewind(target) end

---@overload fun(target:UnityEngine.Material):number @static
---@static
---@param target UnityEngine.Component
---@return number
function m.DOTogglePause(target) end

DG.Tweening.ShortcutExtensions = m
return m
