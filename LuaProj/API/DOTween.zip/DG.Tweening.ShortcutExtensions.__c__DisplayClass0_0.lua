---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass0_0 : System.Object
---@field public target UnityEngine.AudioSource
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass0_0 = m
return m
