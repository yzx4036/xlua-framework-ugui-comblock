---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass39_0 : System.Object
---@field public target UnityEngine.TrailRenderer
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass39_0 = m
return m
