---@class DG.Tweening.Core.Easing.Flash : System.Object
local m = {}

---@static
---@param time number
---@param duration number
---@param overshootOrAmplitude number
---@param period number
---@return number
function m.Ease(time, duration, overshootOrAmplitude, period) end

---@static
---@param time number
---@param duration number
---@param overshootOrAmplitude number
---@param period number
---@return number
function m.EaseIn(time, duration, overshootOrAmplitude, period) end

---@static
---@param time number
---@param duration number
---@param overshootOrAmplitude number
---@param period number
---@return number
function m.EaseOut(time, duration, overshootOrAmplitude, period) end

---@static
---@param time number
---@param duration number
---@param overshootOrAmplitude number
---@param period number
---@return number
function m.EaseInOut(time, duration, overshootOrAmplitude, period) end

DG.Tweening.Core.Easing.Flash = m
return m
