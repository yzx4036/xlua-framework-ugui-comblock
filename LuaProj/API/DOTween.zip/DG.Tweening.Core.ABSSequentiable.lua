---@class DG.Tweening.Core.ABSSequentiable : System.Object
local m = {}

DG.Tweening.Core.ABSSequentiable = m
return m
