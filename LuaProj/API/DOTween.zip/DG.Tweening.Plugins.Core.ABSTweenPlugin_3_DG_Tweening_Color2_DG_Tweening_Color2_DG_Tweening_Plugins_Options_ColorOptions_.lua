---@class DG.Tweening.Plugins.Core.ABSTweenPlugin_3_DG_Tweening_Color2_DG_Tweening_Color2_DG_Tweening_Plugins_Options_ColorOptions_ : System.Object
local m = {}

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_DG_Tweening_Color2_DG_Tweening_Color2_DG_Tweening_Plugins_Options_ColorOptions_
function m:Reset(t) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_DG_Tweening_Color2_DG_Tweening_Color2_DG_Tweening_Plugins_Options_ColorOptions_
---@param isRelative boolean
function m:SetFrom(t, isRelative) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_DG_Tweening_Color2_DG_Tweening_Color2_DG_Tweening_Plugins_Options_ColorOptions_
---@param value DG.Tweening.Color2
---@return DG.Tweening.Color2
function m:ConvertToStartValue(t, value) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_DG_Tweening_Color2_DG_Tweening_Color2_DG_Tweening_Plugins_Options_ColorOptions_
function m:SetRelativeEndValue(t) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_DG_Tweening_Color2_DG_Tweening_Color2_DG_Tweening_Plugins_Options_ColorOptions_
function m:SetChangeValue(t) end

---@abstract
---@param options DG.Tweening.Plugins.Options.ColorOptions
---@param unitsXSecond number
---@param changeValue DG.Tweening.Color2
---@return number
function m:GetSpeedBasedDuration(options, unitsXSecond, changeValue) end

---@abstract
---@param options DG.Tweening.Plugins.Options.ColorOptions
---@param t DG.Tweening.Tween
---@param isRelative boolean
---@param getter fun():DG.Tweening.Color2
---@param setter fun(pNewValue:DG.Tweening.Color2)
---@param elapsed number
---@param startValue DG.Tweening.Color2
---@param changeValue DG.Tweening.Color2
---@param duration number
---@param usingInversePosition boolean
---@param updateNotice DG.Tweening.Core.Enums.UpdateNotice
function m:EvaluateAndApply(options, t, isRelative, getter, setter, elapsed, startValue, changeValue, duration, usingInversePosition, updateNotice) end

DG.Tweening.Plugins.Core.ABSTweenPlugin_3_DG_Tweening_Color2_DG_Tweening_Color2_DG_Tweening_Plugins_Options_ColorOptions_ = m
return m
