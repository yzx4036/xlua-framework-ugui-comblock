---@class DG.Tweening.Tweener : DG.Tweening.Tween
local m = {}

---@overload fun(newStartValue:any):DG.Tweening.Tweener @abstract
---@abstract
---@param newStartValue any
---@param newDuration number
---@return DG.Tweening.Tweener
function m:ChangeStartValue(newStartValue, newDuration) end

---@overload fun(newEndValue:any, newDuration:number):DG.Tweening.Tweener @abstract
---@overload fun(newEndValue:any):DG.Tweening.Tweener @abstract
---@overload fun(newEndValue:any, snapStartValue:boolean):DG.Tweening.Tweener @abstract
---@abstract
---@param newEndValue any
---@param newDuration number
---@param snapStartValue boolean
---@return DG.Tweening.Tweener
function m:ChangeEndValue(newEndValue, newDuration, snapStartValue) end

---@overload fun(newStartValue:any, newEndValue:any):DG.Tweening.Tweener @abstract
---@abstract
---@param newStartValue any
---@param newEndValue any
---@param newDuration number
---@return DG.Tweening.Tweener
function m:ChangeValues(newStartValue, newEndValue, newDuration) end

DG.Tweening.Tweener = m
return m
