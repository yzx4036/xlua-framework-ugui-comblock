---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass40_0 : System.Object
---@field public target UnityEngine.TrailRenderer
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass40_0 = m
return m
