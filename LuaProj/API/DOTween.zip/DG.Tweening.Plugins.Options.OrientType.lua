---@class DG.Tweening.Plugins.Options.OrientType : System.Enum
---@field public None DG.Tweening.Plugins.Options.OrientType @static
---@field public ToPath DG.Tweening.Plugins.Options.OrientType @static
---@field public LookAtTransform DG.Tweening.Plugins.Options.OrientType @static
---@field public LookAtPosition DG.Tweening.Plugins.Options.OrientType @static
---@field public value__ number
local m = {}

DG.Tweening.Plugins.Options.OrientType = m
return m
