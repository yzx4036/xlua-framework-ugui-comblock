---@class DG.Tweening.Core.DOTweenComponent._WaitForStart_d__19 : System.Object
---@field public t DG.Tweening.Tween
local m = {}

DG.Tweening.Core.DOTweenComponent._WaitForStart_d__19 = m
return m
