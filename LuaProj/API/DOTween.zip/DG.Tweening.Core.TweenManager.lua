---@class DG.Tweening.Core.TweenManager : System.Object
local m = {}

DG.Tweening.Core.TweenManager = m
return m
