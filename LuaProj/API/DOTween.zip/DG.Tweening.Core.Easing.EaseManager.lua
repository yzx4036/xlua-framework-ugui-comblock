---@class DG.Tweening.Core.Easing.EaseManager : System.Object
local m = {}

---@overload fun(easeType:DG.Tweening.Ease, customEase:(fun(time:number, duration:number, overshootOrAmplitude:number, period:number):number), time:number, duration:number, overshootOrAmplitude:number, period:number):number @static
---@static
---@param t DG.Tweening.Tween
---@param time number
---@param duration number
---@param overshootOrAmplitude number
---@param period number
---@return number
function m.Evaluate(t, time, duration, overshootOrAmplitude, period) end

---@static
---@param ease DG.Tweening.Ease
---@return fun(time:number, duration:number, overshootOrAmplitude:number, period:number):number
function m.ToEaseFunction(ease) end

DG.Tweening.Core.Easing.EaseManager = m
return m
