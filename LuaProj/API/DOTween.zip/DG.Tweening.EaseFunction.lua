---@class DG.Tweening.EaseFunction : System.MulticastDelegate
local m = {}

---@virtual
---@param time number
---@param duration number
---@param overshootOrAmplitude number
---@param period number
---@return number
function m:Invoke(time, duration, overshootOrAmplitude, period) end

---@virtual
---@param time number
---@param duration number
---@param overshootOrAmplitude number
---@param period number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(time, duration, overshootOrAmplitude, period, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return number
function m:EndInvoke(result) end

DG.Tweening.EaseFunction = m
return m
