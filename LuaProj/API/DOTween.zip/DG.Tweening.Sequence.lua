---@class DG.Tweening.Sequence : DG.Tweening.Tween
local m = {}

DG.Tweening.Sequence = m
return m
