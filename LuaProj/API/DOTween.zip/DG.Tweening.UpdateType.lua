---@class DG.Tweening.UpdateType : System.Enum
---@field public Normal DG.Tweening.UpdateType @static
---@field public Late DG.Tweening.UpdateType @static
---@field public Fixed DG.Tweening.UpdateType @static
---@field public Manual DG.Tweening.UpdateType @static
---@field public value__ number
local m = {}

DG.Tweening.UpdateType = m
return m
