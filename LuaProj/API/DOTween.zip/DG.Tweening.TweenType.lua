---@class DG.Tweening.TweenType : System.Enum
---@field public Tweener DG.Tweening.TweenType @static
---@field public Sequence DG.Tweening.TweenType @static
---@field public Callback DG.Tweening.TweenType @static
---@field public value__ number
local m = {}

DG.Tweening.TweenType = m
return m
