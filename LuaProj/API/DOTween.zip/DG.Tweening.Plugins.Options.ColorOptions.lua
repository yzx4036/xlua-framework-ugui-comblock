---@class DG.Tweening.Plugins.Options.ColorOptions : System.ValueType
---@field public alphaOnly boolean
local m = {}

---@virtual
function m:Reset() end

DG.Tweening.Plugins.Options.ColorOptions = m
return m
