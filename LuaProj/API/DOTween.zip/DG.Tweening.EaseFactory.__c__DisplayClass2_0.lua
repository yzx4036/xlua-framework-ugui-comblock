---@class DG.Tweening.EaseFactory.__c__DisplayClass2_0 : System.Object
---@field public motionDelay number
---@field public customEase fun(time:number, duration:number, overshootOrAmplitude:number, period:number):number
local m = {}

DG.Tweening.EaseFactory.__c__DisplayClass2_0 = m
return m
