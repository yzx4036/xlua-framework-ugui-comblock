---@class DG.Tweening.Plugins.Core.ITweenPlugin : table
local m = {}

DG.Tweening.Plugins.Core.ITweenPlugin = m
return m
