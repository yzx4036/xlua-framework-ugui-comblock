---@class DG.Tweening.Plugins.Core.PathCore.ControlPoint : System.ValueType
---@field public a UnityEngine.Vector3
---@field public b UnityEngine.Vector3
local m = {}

---@static
---@param cp DG.Tweening.Plugins.Core.PathCore.ControlPoint
---@param v UnityEngine.Vector3
---@return DG.Tweening.Plugins.Core.PathCore.ControlPoint
function m.op_Addition(cp, v) end

DG.Tweening.Plugins.Core.PathCore.ControlPoint = m
return m
