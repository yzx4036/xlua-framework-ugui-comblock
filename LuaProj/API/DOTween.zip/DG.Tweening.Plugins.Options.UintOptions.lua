---@class DG.Tweening.Plugins.Options.UintOptions : System.ValueType
---@field public isNegativeChangeValue boolean
local m = {}

---@virtual
function m:Reset() end

DG.Tweening.Plugins.Options.UintOptions = m
return m
