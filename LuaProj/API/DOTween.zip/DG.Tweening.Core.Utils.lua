---@class DG.Tweening.Core.Utils : System.Object
local m = {}

DG.Tweening.Core.Utils = m
return m
