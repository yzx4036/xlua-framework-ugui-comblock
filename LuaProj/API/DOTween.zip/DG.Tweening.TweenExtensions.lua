---@class DG.Tweening.TweenExtensions : System.Object
local m = {}

---@overload fun(t:DG.Tweening.Tween, withCallbacks:boolean) @static
---@static
---@param t DG.Tweening.Tween
function m.Complete(t) end

---@static
---@param t DG.Tweening.Tween
function m.Flip(t) end

---@static
---@param t DG.Tweening.Tween
function m.ForceInit(t) end

---@overload fun(t:DG.Tweening.Tween, to:number) @static
---@static
---@param t DG.Tweening.Tween
---@param to number
---@param andPlay boolean
function m.Goto(t, to, andPlay) end

---@overload fun(t:DG.Tweening.Tween) @static
---@static
---@param t DG.Tweening.Tween
---@param complete boolean
function m.Kill(t, complete) end

---@static
---@param t DG.Tweening.Tween
---@return DG.Tweening.Tween
function m.Pause(t) end

---@static
---@param t DG.Tweening.Tween
---@return DG.Tweening.Tween
function m.Play(t) end

---@static
---@param t DG.Tweening.Tween
function m.PlayBackwards(t) end

---@static
---@param t DG.Tweening.Tween
function m.PlayForward(t) end

---@overload fun(t:DG.Tweening.Tween, includeDelay:boolean) @static
---@overload fun(t:DG.Tweening.Tween) @static
---@static
---@param t DG.Tweening.Tween
---@param includeDelay boolean
---@param changeDelayTo number
function m.Restart(t, includeDelay, changeDelayTo) end

---@overload fun(t:DG.Tweening.Tween) @static
---@static
---@param t DG.Tweening.Tween
---@param includeDelay boolean
function m.Rewind(t, includeDelay) end

---@static
---@param t DG.Tweening.Tween
function m.SmoothRewind(t) end

---@static
---@param t DG.Tweening.Tween
function m.TogglePause(t) end

---@overload fun(t:DG.Tweening.Tween, waypointIndex:number) @static
---@static
---@param t DG.Tweening.Tween
---@param waypointIndex number
---@param andPlay boolean
function m.GotoWaypoint(t, waypointIndex, andPlay) end

---@static
---@param t DG.Tweening.Tween
---@return UnityEngine.YieldInstruction
function m.WaitForCompletion(t) end

---@static
---@param t DG.Tweening.Tween
---@return UnityEngine.YieldInstruction
function m.WaitForRewind(t) end

---@static
---@param t DG.Tweening.Tween
---@return UnityEngine.YieldInstruction
function m.WaitForKill(t) end

---@static
---@param t DG.Tweening.Tween
---@param elapsedLoops number
---@return UnityEngine.YieldInstruction
function m.WaitForElapsedLoops(t, elapsedLoops) end

---@static
---@param t DG.Tweening.Tween
---@param position number
---@return UnityEngine.YieldInstruction
function m.WaitForPosition(t, position) end

---@static
---@param t DG.Tweening.Tween
---@return UnityEngine.Coroutine
function m.WaitForStart(t) end

---@static
---@param t DG.Tweening.Tween
---@return number
function m.CompletedLoops(t) end

---@static
---@param t DG.Tweening.Tween
---@return number
function m.Delay(t) end

---@overload fun(t:DG.Tweening.Tween):number @static
---@static
---@param t DG.Tweening.Tween
---@param includeLoops boolean
---@return number
function m.Duration(t, includeLoops) end

---@overload fun(t:DG.Tweening.Tween):number @static
---@static
---@param t DG.Tweening.Tween
---@param includeLoops boolean
---@return number
function m.Elapsed(t, includeLoops) end

---@overload fun(t:DG.Tweening.Tween):number @static
---@static
---@param t DG.Tweening.Tween
---@param includeLoops boolean
---@return number
function m.ElapsedPercentage(t, includeLoops) end

---@static
---@param t DG.Tweening.Tween
---@return number
function m.ElapsedDirectionalPercentage(t) end

---@static
---@param t DG.Tweening.Tween
---@return boolean
function m.IsActive(t) end

---@static
---@param t DG.Tweening.Tween
---@return boolean
function m.IsBackwards(t) end

---@static
---@param t DG.Tweening.Tween
---@return boolean
function m.IsComplete(t) end

---@static
---@param t DG.Tweening.Tween
---@return boolean
function m.IsInitialized(t) end

---@static
---@param t DG.Tweening.Tween
---@return boolean
function m.IsPlaying(t) end

---@static
---@param t DG.Tweening.Tween
---@return number
function m.Loops(t) end

---@static
---@param t DG.Tweening.Tween
---@param pathPercentage number
---@return UnityEngine.Vector3
function m.PathGetPoint(t, pathPercentage) end

---@overload fun(t:DG.Tweening.Tween):UnityEngine.Vector3[] @static
---@static
---@param t DG.Tweening.Tween
---@param subdivisionsXSegment number
---@return UnityEngine.Vector3[]
function m.PathGetDrawPoints(t, subdivisionsXSegment) end

---@static
---@param t DG.Tweening.Tween
---@return number
function m.PathLength(t) end

DG.Tweening.TweenExtensions = m
return m
