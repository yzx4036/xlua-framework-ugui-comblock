---@class DG.Tweening.Plugins.StringPluginExtensions : System.Object
---@field public ScrambledCharsAll number[] @static
---@field public ScrambledCharsUppercase number[] @static
---@field public ScrambledCharsLowercase number[] @static
---@field public ScrambledCharsNumerals number[] @static
local m = {}

DG.Tweening.Plugins.StringPluginExtensions = m
return m
