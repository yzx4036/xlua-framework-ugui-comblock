---@class DG.Tweening.Core.Enums.UpdateMode : System.Enum
---@field public Update DG.Tweening.Core.Enums.UpdateMode @static
---@field public Goto DG.Tweening.Core.Enums.UpdateMode @static
---@field public IgnoreOnUpdate DG.Tweening.Core.Enums.UpdateMode @static
---@field public value__ number
local m = {}

DG.Tweening.Core.Enums.UpdateMode = m
return m
