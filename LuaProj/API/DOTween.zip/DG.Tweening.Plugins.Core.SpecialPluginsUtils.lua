---@class DG.Tweening.Plugins.Core.SpecialPluginsUtils : System.Object
local m = {}

DG.Tweening.Plugins.Core.SpecialPluginsUtils = m
return m
