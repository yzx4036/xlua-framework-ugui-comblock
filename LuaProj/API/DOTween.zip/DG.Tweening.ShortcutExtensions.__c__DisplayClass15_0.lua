---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass15_0 : System.Object
---@field public target UnityEngine.Light
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass15_0 = m
return m
