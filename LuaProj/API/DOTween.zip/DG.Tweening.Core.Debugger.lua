---@class DG.Tweening.Core.Debugger : System.Object
---@field public logPriority number @static
local m = {}

---@static
---@param message any
function m.Log(message) end

---@static
---@param message any
function m.LogWarning(message) end

---@static
---@param message any
function m.LogError(message) end

---@static
---@param message any
function m.LogReport(message) end

---@static
---@param t DG.Tweening.Tween
function m.LogInvalidTween(t) end

---@static
---@param t DG.Tweening.Tween
function m.LogNestedTween(t) end

---@static
---@param t DG.Tweening.Tween
function m.LogNullTween(t) end

---@static
---@param t DG.Tweening.Tween
function m.LogNonPathTween(t) end

---@static
---@param propertyName string
function m.LogMissingMaterialProperty(propertyName) end

---@static
---@param propertyName string
function m.LogRemoveActiveTweenError(propertyName) end

---@static
---@param logBehaviour DG.Tweening.LogBehaviour
function m.SetLogPriority(logBehaviour) end

DG.Tweening.Core.Debugger = m
return m
