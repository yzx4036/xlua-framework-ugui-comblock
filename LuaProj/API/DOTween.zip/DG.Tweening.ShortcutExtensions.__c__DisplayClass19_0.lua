---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass19_0 : System.Object
---@field public target UnityEngine.Material
---@field public property string
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass19_0 = m
return m
