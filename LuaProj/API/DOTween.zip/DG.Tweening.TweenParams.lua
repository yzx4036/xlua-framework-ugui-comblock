---@class DG.Tweening.TweenParams : System.Object
---@field public Params DG.Tweening.TweenParams @static
local m = {}

---@return DG.Tweening.TweenParams
function m:Clear() end

---@overload fun():DG.Tweening.TweenParams
---@param autoKillOnCompletion boolean
---@return DG.Tweening.TweenParams
function m:SetAutoKill(autoKillOnCompletion) end

---@param id any
---@return DG.Tweening.TweenParams
function m:SetId(id) end

---@param target any
---@return DG.Tweening.TweenParams
function m:SetTarget(target) end

---@overload fun(loops:number):DG.Tweening.TweenParams
---@param loops number
---@param loopType System.Nullable_1_DG_Tweening_LoopType_
---@return DG.Tweening.TweenParams
function m:SetLoops(loops, loopType) end

---@overload fun(ease:DG.Tweening.Ease, overshootOrAmplitude:System.Nullable_1_System_Single_):DG.Tweening.TweenParams
---@overload fun(ease:DG.Tweening.Ease):DG.Tweening.TweenParams
---@overload fun(animCurve:UnityEngine.AnimationCurve):DG.Tweening.TweenParams
---@overload fun(customEase:(fun(time:number, duration:number, overshootOrAmplitude:number, period:number):number)):DG.Tweening.TweenParams
---@param ease DG.Tweening.Ease
---@param overshootOrAmplitude System.Nullable_1_System_Single_
---@param period System.Nullable_1_System_Single_
---@return DG.Tweening.TweenParams
function m:SetEase(ease, overshootOrAmplitude, period) end

---@overload fun():DG.Tweening.TweenParams
---@param recyclable boolean
---@return DG.Tweening.TweenParams
function m:SetRecyclable(recyclable) end

---@overload fun(updateType:DG.Tweening.UpdateType, isIndependentUpdate:boolean):DG.Tweening.TweenParams
---@overload fun(updateType:DG.Tweening.UpdateType):DG.Tweening.TweenParams
---@param isIndependentUpdate boolean
---@return DG.Tweening.TweenParams
function m:SetUpdate(isIndependentUpdate) end

---@param action fun()
---@return DG.Tweening.TweenParams
function m:OnStart(action) end

---@param action fun()
---@return DG.Tweening.TweenParams
function m:OnPlay(action) end

---@param action fun()
---@return DG.Tweening.TweenParams
function m:OnRewind(action) end

---@param action fun()
---@return DG.Tweening.TweenParams
function m:OnUpdate(action) end

---@param action fun()
---@return DG.Tweening.TweenParams
function m:OnStepComplete(action) end

---@param action fun()
---@return DG.Tweening.TweenParams
function m:OnComplete(action) end

---@param action fun()
---@return DG.Tweening.TweenParams
function m:OnKill(action) end

---@param action fun(value:number)
---@return DG.Tweening.TweenParams
function m:OnWaypointChange(action) end

---@param delay number
---@return DG.Tweening.TweenParams
function m:SetDelay(delay) end

---@overload fun():DG.Tweening.TweenParams
---@param isRelative boolean
---@return DG.Tweening.TweenParams
function m:SetRelative(isRelative) end

---@overload fun():DG.Tweening.TweenParams
---@param isSpeedBased boolean
---@return DG.Tweening.TweenParams
function m:SetSpeedBased(isSpeedBased) end

DG.Tweening.TweenParams = m
return m
