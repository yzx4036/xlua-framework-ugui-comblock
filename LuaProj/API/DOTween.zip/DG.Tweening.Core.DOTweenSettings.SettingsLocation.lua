---@class DG.Tweening.Core.DOTweenSettings.SettingsLocation : System.Enum
---@field public AssetsDirectory DG.Tweening.Core.DOTweenSettings.SettingsLocation @static
---@field public DOTweenDirectory DG.Tweening.Core.DOTweenSettings.SettingsLocation @static
---@field public DemigiantDirectory DG.Tweening.Core.DOTweenSettings.SettingsLocation @static
---@field public value__ number
local m = {}

DG.Tweening.Core.DOTweenSettings.SettingsLocation = m
return m
