---@class DG.Tweening.Plugins.Core.ITPlugin_4_T1_T2_TPlugOptions_TPlugin_ : table
local m = {}

DG.Tweening.Plugins.Core.ITPlugin_4_T1_T2_TPlugOptions_TPlugin_ = m
return m
