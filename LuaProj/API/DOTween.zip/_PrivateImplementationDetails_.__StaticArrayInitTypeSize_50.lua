---@class _PrivateImplementationDetails_.__StaticArrayInitTypeSize_50 : System.ValueType
local m = {}

_PrivateImplementationDetails_.__StaticArrayInitTypeSize_50 = m
return m
