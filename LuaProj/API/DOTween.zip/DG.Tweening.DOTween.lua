---@class DG.Tweening.DOTween : System.Object
---@field public Version string @static
---@field public useSafeMode boolean @static
---@field public showUnityEditorReport boolean @static
---@field public timeScale number @static
---@field public useSmoothDeltaTime boolean @static
---@field public maxSmoothUnscaledTime number @static
---@field public drawGizmos boolean @static
---@field public defaultUpdateType DG.Tweening.UpdateType @static
---@field public defaultTimeScaleIndependent boolean @static
---@field public defaultAutoPlay DG.Tweening.AutoPlay @static
---@field public defaultAutoKill boolean @static
---@field public defaultLoopType DG.Tweening.LoopType @static
---@field public defaultRecyclable boolean @static
---@field public defaultEaseType DG.Tweening.Ease @static
---@field public defaultEaseOvershootOrAmplitude number @static
---@field public defaultEasePeriod number @static
---@field public logBehaviour DG.Tweening.LogBehaviour @static
local m = {}

---@overload fun(recycleAllByDefault:System.Nullable_1_System_Boolean_, useSafeMode:System.Nullable_1_System_Boolean_):DG.Tweening.IDOTweenInit @static
---@overload fun(recycleAllByDefault:System.Nullable_1_System_Boolean_):DG.Tweening.IDOTweenInit @static
---@overload fun():DG.Tweening.IDOTweenInit @static
---@static
---@param recycleAllByDefault System.Nullable_1_System_Boolean_
---@param useSafeMode System.Nullable_1_System_Boolean_
---@param logBehaviour System.Nullable_1_DG_Tweening_LogBehaviour_
---@return DG.Tweening.IDOTweenInit
function m.Init(recycleAllByDefault, useSafeMode, logBehaviour) end

---@static
---@param tweenersCapacity number
---@param sequencesCapacity number
function m.SetTweensCapacity(tweenersCapacity, sequencesCapacity) end

---@overload fun() @static
---@static
---@param destroy boolean
function m.Clear(destroy) end

---@static
function m.ClearCachedTweens() end

---@static
---@return number
function m.Validate() end

---@static
---@param deltaTime number
---@param unscaledDeltaTime number
function m.ManualUpdate(deltaTime, unscaledDeltaTime) end

---@overload fun(getter:(fun():number), setter:(fun(pNewValue:number)), endValue:number, duration:number):DG.Tweening.Core.TweenerCore_3_System_Double_System_Double_DG_Tweening_Plugins_Options_NoOptions_ @static
---@overload fun(getter:(fun():number), setter:(fun(pNewValue:number)), endValue:number, duration:number):DG.Tweening.Tweener @static
---@overload fun(getter:(fun():number), setter:(fun(pNewValue:number)), endValue:number, duration:number):DG.Tweening.Tweener @static
---@overload fun(getter:(fun():number), setter:(fun(pNewValue:number)), endValue:number, duration:number):DG.Tweening.Tweener @static
---@overload fun(getter:(fun():number), setter:(fun(pNewValue:number)), endValue:number, duration:number):DG.Tweening.Tweener @static
---@overload fun(getter:(fun():string), setter:(fun(pNewValue:string)), endValue:string, duration:number):DG.Tweening.Core.TweenerCore_3_System_String_System_String_DG_Tweening_Plugins_Options_StringOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector2), setter:(fun(pNewValue:UnityEngine.Vector2)), endValue:UnityEngine.Vector2, duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector2_UnityEngine_Vector2_DG_Tweening_Plugins_Options_VectorOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), endValue:UnityEngine.Vector3, duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector4), setter:(fun(pNewValue:UnityEngine.Vector4)), endValue:UnityEngine.Vector4, duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector4_UnityEngine_Vector4_DG_Tweening_Plugins_Options_VectorOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Quaternion), setter:(fun(pNewValue:UnityEngine.Quaternion)), endValue:UnityEngine.Vector3, duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Quaternion_UnityEngine_Vector3_DG_Tweening_Plugins_Options_QuaternionOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Color), setter:(fun(pNewValue:UnityEngine.Color)), endValue:UnityEngine.Color, duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Color_UnityEngine_Color_DG_Tweening_Plugins_Options_ColorOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Rect), setter:(fun(pNewValue:UnityEngine.Rect)), endValue:UnityEngine.Rect, duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Rect_UnityEngine_Rect_DG_Tweening_Plugins_Options_RectOptions_ @static
---@overload fun(getter:(fun():UnityEngine.RectOffset), setter:(fun(pNewValue:UnityEngine.RectOffset)), endValue:UnityEngine.RectOffset, duration:number):DG.Tweening.Tweener @static
---@overload fun(plugin:DG.Tweening.Plugins.Core.ABSTweenPlugin_3_T1_T2_TPlugOptions_, getter:(fun():any), setter:(fun(pNewValue:any)), endValue:any, duration:number):DG.Tweening.Core.TweenerCore_3_T1_T2_TPlugOptions_ @static
---@overload fun(setter:(fun(pNewValue:number)), startValue:number, endValue:number, duration:number):DG.Tweening.Tweener @static
---@static
---@param getter fun():number
---@param setter fun(pNewValue:number)
---@param endValue number
---@param duration number
---@return DG.Tweening.Core.TweenerCore_3_System_Single_System_Single_DG_Tweening_Plugins_Options_FloatOptions_
function m.To(getter, setter, endValue, duration) end

---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), endValue:number, duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_ @static
---@static
---@param getter fun():UnityEngine.Vector3
---@param setter fun(pNewValue:UnityEngine.Vector3)
---@param endValue number
---@param duration number
---@param axisConstraint DG.Tweening.AxisConstraint
---@return DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3_DG_Tweening_Plugins_Options_VectorOptions_
function m.ToAxis(getter, setter, endValue, duration, axisConstraint) end

---@static
---@param getter fun():UnityEngine.Color
---@param setter fun(pNewValue:UnityEngine.Color)
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.ToAlpha(getter, setter, endValue, duration) end

---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), direction:UnityEngine.Vector3, duration:number, vibrato:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), direction:UnityEngine.Vector3, duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@static
---@param getter fun():UnityEngine.Vector3
---@param setter fun(pNewValue:UnityEngine.Vector3)
---@param direction UnityEngine.Vector3
---@param duration number
---@param vibrato number
---@param elasticity number
---@return DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_
function m.Punch(getter, setter, direction, duration, vibrato, elasticity) end

---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), duration:number, strength:number, vibrato:number, randomness:number, ignoreZAxis:boolean):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), duration:number, strength:number, vibrato:number, randomness:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), duration:number, strength:number, vibrato:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), duration:number, strength:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), duration:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number, fadeOut:boolean):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), duration:number, strength:UnityEngine.Vector3, vibrato:number, randomness:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), duration:number, strength:UnityEngine.Vector3, vibrato:number):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@overload fun(getter:(fun():UnityEngine.Vector3), setter:(fun(pNewValue:UnityEngine.Vector3)), duration:number, strength:UnityEngine.Vector3):DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_ @static
---@static
---@param getter fun():UnityEngine.Vector3
---@param setter fun(pNewValue:UnityEngine.Vector3)
---@param duration number
---@param strength number
---@param vibrato number
---@param randomness number
---@param ignoreZAxis boolean
---@param fadeOut boolean
---@return DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_
function m.Shake(getter, setter, duration, strength, vibrato, randomness, ignoreZAxis, fadeOut) end

---@static
---@param getter fun():UnityEngine.Vector3
---@param setter fun(pNewValue:UnityEngine.Vector3)
---@param endValues UnityEngine.Vector3[]
---@param durations number[]
---@return DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_UnityEngine_Vector3___DG_Tweening_Plugins_Options_Vector3ArrayOptions_
function m.ToArray(getter, setter, endValues, durations) end

---@static
---@return DG.Tweening.Sequence
function m.Sequence() end

---@overload fun():number @static
---@static
---@param withCallbacks boolean
---@return number
function m.CompleteAll(withCallbacks) end

---@overload fun(targetOrId:any):number @static
---@static
---@param targetOrId any
---@param withCallbacks boolean
---@return number
function m.Complete(targetOrId, withCallbacks) end

---@static
---@return number
function m.FlipAll() end

---@static
---@param targetOrId any
---@return number
function m.Flip(targetOrId) end

---@overload fun(to:number):number @static
---@static
---@param to number
---@param andPlay boolean
---@return number
function m.GotoAll(to, andPlay) end

---@overload fun(targetOrId:any, to:number):number @static
---@static
---@param targetOrId any
---@param to number
---@param andPlay boolean
---@return number
function m.Goto(targetOrId, to, andPlay) end

---@overload fun():number @static
---@overload fun(complete:boolean, idsOrTargetsToExclude:any[]|any):number @static
---@overload fun(complete:boolean):number @static
---@static
---@param complete boolean
---@return number
function m.KillAll(complete) end

---@overload fun(targetOrId:any):number @static
---@static
---@param targetOrId any
---@param complete boolean
---@return number
function m.Kill(targetOrId, complete) end

---@static
---@return number
function m.PauseAll() end

---@static
---@param targetOrId any
---@return number
function m.Pause(targetOrId) end

---@static
---@return number
function m.PlayAll() end

---@overload fun(target:any, id:any):number @static
---@static
---@param targetOrId any
---@return number
function m.Play(targetOrId) end

---@static
---@return number
function m.PlayBackwardsAll() end

---@overload fun(target:any, id:any):number @static
---@static
---@param targetOrId any
---@return number
function m.PlayBackwards(targetOrId) end

---@static
---@return number
function m.PlayForwardAll() end

---@overload fun(target:any, id:any):number @static
---@static
---@param targetOrId any
---@return number
function m.PlayForward(targetOrId) end

---@overload fun():number @static
---@static
---@param includeDelay boolean
---@return number
function m.RestartAll(includeDelay) end

---@overload fun(targetOrId:any, includeDelay:boolean):number @static
---@overload fun(targetOrId:any):number @static
---@overload fun(target:any, id:any, includeDelay:boolean, changeDelayTo:number):number @static
---@overload fun(target:any, id:any, includeDelay:boolean):number @static
---@overload fun(target:any, id:any):number @static
---@static
---@param targetOrId any
---@param includeDelay boolean
---@param changeDelayTo number
---@return number
function m.Restart(targetOrId, includeDelay, changeDelayTo) end

---@overload fun():number @static
---@static
---@param includeDelay boolean
---@return number
function m.RewindAll(includeDelay) end

---@overload fun(targetOrId:any):number @static
---@static
---@param targetOrId any
---@param includeDelay boolean
---@return number
function m.Rewind(targetOrId, includeDelay) end

---@static
---@return number
function m.SmoothRewindAll() end

---@static
---@param targetOrId any
---@return number
function m.SmoothRewind(targetOrId) end

---@static
---@return number
function m.TogglePauseAll() end

---@static
---@param targetOrId any
---@return number
function m.TogglePause(targetOrId) end

---@overload fun(targetOrId:any):boolean @static
---@static
---@param targetOrId any
---@param alsoCheckIfIsPlaying boolean
---@return boolean
function m.IsTweening(targetOrId, alsoCheckIfIsPlaying) end

---@static
---@return number
function m.TotalPlayingTweens() end

---@static
---@return DG.Tweening.Tween[]
function m.PlayingTweens() end

---@static
---@return DG.Tweening.Tween[]
function m.PausedTweens() end

---@overload fun(id:any):DG.Tweening.Tween[] @static
---@static
---@param id any
---@param playingOnly boolean
---@return DG.Tweening.Tween[]
function m.TweensById(id, playingOnly) end

---@overload fun(target:any):DG.Tweening.Tween[] @static
---@static
---@param target any
---@param playingOnly boolean
---@return DG.Tweening.Tween[]
function m.TweensByTarget(target, playingOnly) end

DG.Tweening.DOTween = m
return m
