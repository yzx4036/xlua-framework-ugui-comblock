---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass36_0 : System.Object
---@field public trans UnityEngine.Transform
---@field public target UnityEngine.Rigidbody
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass36_0 = m
return m
