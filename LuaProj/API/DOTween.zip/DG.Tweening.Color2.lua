---@class DG.Tweening.Color2 : System.ValueType
---@field public ca UnityEngine.Color
---@field public cb UnityEngine.Color
local m = {}

---@static
---@param c1 DG.Tweening.Color2
---@param c2 DG.Tweening.Color2
---@return DG.Tweening.Color2
function m.op_Addition(c1, c2) end

---@static
---@param c1 DG.Tweening.Color2
---@param c2 DG.Tweening.Color2
---@return DG.Tweening.Color2
function m.op_Subtraction(c1, c2) end

---@static
---@param c1 DG.Tweening.Color2
---@param f number
---@return DG.Tweening.Color2
function m.op_Multiply(c1, f) end

DG.Tweening.Color2 = m
return m
