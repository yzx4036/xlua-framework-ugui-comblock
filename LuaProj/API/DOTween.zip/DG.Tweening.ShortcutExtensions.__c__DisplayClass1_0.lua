---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass1_0 : System.Object
---@field public target UnityEngine.AudioSource
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass1_0 = m
return m
