---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass37_0 : System.Object
---@field public target UnityEngine.Rigidbody
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass37_0 = m
return m
