---@class DG.Tweening.Core.DOTweenComponent._WaitForCompletion_d__14 : System.Object
---@field public t DG.Tweening.Tween
local m = {}

DG.Tweening.Core.DOTweenComponent._WaitForCompletion_d__14 = m
return m
