---@class DG.Tweening.Plugins.Core.PathCore.CatmullRomDecoder : DG.Tweening.Plugins.Core.PathCore.ABSPathDecoder
local m = {}

DG.Tweening.Plugins.Core.PathCore.CatmullRomDecoder = m
return m
