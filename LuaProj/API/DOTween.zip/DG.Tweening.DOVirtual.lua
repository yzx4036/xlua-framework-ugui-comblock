---@class DG.Tweening.DOVirtual : System.Object
local m = {}

---@static
---@param from number
---@param to number
---@param duration number
---@param onVirtualUpdate fun(value:number)
---@return DG.Tweening.Tweener
function m.Float(from, to, duration, onVirtualUpdate) end

---@overload fun(from:number, to:number, lifetimePercentage:number, easeType:DG.Tweening.Ease, overshoot:number):number @static
---@overload fun(from:number, to:number, lifetimePercentage:number, easeType:DG.Tweening.Ease, amplitude:number, period:number):number @static
---@overload fun(from:number, to:number, lifetimePercentage:number, easeCurve:UnityEngine.AnimationCurve):number @static
---@static
---@param from number
---@param to number
---@param lifetimePercentage number
---@param easeType DG.Tweening.Ease
---@return number
function m.EasedValue(from, to, lifetimePercentage, easeType) end

---@overload fun(delay:number, callback:(fun())):DG.Tweening.Tween @static
---@static
---@param delay number
---@param callback fun()
---@param ignoreTimeScale boolean
---@return DG.Tweening.Tween
function m.DelayedCall(delay, callback, ignoreTimeScale) end

DG.Tweening.DOVirtual = m
return m
