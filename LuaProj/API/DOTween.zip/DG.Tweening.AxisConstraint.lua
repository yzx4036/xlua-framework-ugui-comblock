---@class DG.Tweening.AxisConstraint : System.Enum
---@field public None DG.Tweening.AxisConstraint @static
---@field public X DG.Tweening.AxisConstraint @static
---@field public Y DG.Tweening.AxisConstraint @static
---@field public Z DG.Tweening.AxisConstraint @static
---@field public W DG.Tweening.AxisConstraint @static
---@field public value__ number
local m = {}

DG.Tweening.AxisConstraint = m
return m
