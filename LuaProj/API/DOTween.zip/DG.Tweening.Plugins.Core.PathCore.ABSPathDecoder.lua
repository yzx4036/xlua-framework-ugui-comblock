---@class DG.Tweening.Plugins.Core.PathCore.ABSPathDecoder : System.Object
local m = {}

DG.Tweening.Plugins.Core.PathCore.ABSPathDecoder = m
return m
