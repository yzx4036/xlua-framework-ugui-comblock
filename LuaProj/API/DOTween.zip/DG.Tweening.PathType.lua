---@class DG.Tweening.PathType : System.Enum
---@field public Linear DG.Tweening.PathType @static
---@field public CatmullRom DG.Tweening.PathType @static
---@field public value__ number
local m = {}

DG.Tweening.PathType = m
return m
