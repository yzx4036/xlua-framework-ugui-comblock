---@class DG.Tweening.Plugins.Options.StringOptions : System.ValueType
---@field public richTextEnabled boolean
---@field public scrambleMode DG.Tweening.ScrambleMode
---@field public scrambledChars number[]
local m = {}

---@virtual
function m:Reset() end

DG.Tweening.Plugins.Options.StringOptions = m
return m
