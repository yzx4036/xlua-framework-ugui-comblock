---@class DG.Tweening.Plugins.StringPlugin : DG.Tweening.Plugins.Core.ABSTweenPlugin_3_System_String_System_String_DG_Tweening_Plugins_Options_StringOptions_
local m = {}

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_System_String_System_String_DG_Tweening_Plugins_Options_StringOptions_
---@param isRelative boolean
function m:SetFrom(t, isRelative) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_System_String_System_String_DG_Tweening_Plugins_Options_StringOptions_
function m:Reset(t) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_System_String_System_String_DG_Tweening_Plugins_Options_StringOptions_
---@param value string
---@return string
function m:ConvertToStartValue(t, value) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_System_String_System_String_DG_Tweening_Plugins_Options_StringOptions_
function m:SetRelativeEndValue(t) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_System_String_System_String_DG_Tweening_Plugins_Options_StringOptions_
function m:SetChangeValue(t) end

---@virtual
---@param options DG.Tweening.Plugins.Options.StringOptions
---@param unitsXSecond number
---@param changeValue string
---@return number
function m:GetSpeedBasedDuration(options, unitsXSecond, changeValue) end

---@virtual
---@param options DG.Tweening.Plugins.Options.StringOptions
---@param t DG.Tweening.Tween
---@param isRelative boolean
---@param getter fun():string
---@param setter fun(pNewValue:string)
---@param elapsed number
---@param startValue string
---@param changeValue string
---@param duration number
---@param usingInversePosition boolean
---@param updateNotice DG.Tweening.Core.Enums.UpdateNotice
function m:EvaluateAndApply(options, t, isRelative, getter, setter, elapsed, startValue, changeValue, duration, usingInversePosition, updateNotice) end

DG.Tweening.Plugins.StringPlugin = m
return m
