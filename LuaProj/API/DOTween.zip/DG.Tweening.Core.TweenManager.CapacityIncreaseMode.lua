---@class DG.Tweening.Core.TweenManager.CapacityIncreaseMode : System.Enum
---@field public TweenersAndSequences DG.Tweening.Core.TweenManager.CapacityIncreaseMode @static
---@field public TweenersOnly DG.Tweening.Core.TweenManager.CapacityIncreaseMode @static
---@field public SequencesOnly DG.Tweening.Core.TweenManager.CapacityIncreaseMode @static
---@field public value__ number
local m = {}

DG.Tweening.Core.TweenManager.CapacityIncreaseMode = m
return m
