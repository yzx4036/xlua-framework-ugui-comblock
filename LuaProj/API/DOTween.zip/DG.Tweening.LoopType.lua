---@class DG.Tweening.LoopType : System.Enum
---@field public Restart DG.Tweening.LoopType @static
---@field public Yoyo DG.Tweening.LoopType @static
---@field public Incremental DG.Tweening.LoopType @static
---@field public value__ number
local m = {}

DG.Tweening.LoopType = m
return m
