---@class DG.Tweening.ScrambleMode : System.Enum
---@field public None DG.Tweening.ScrambleMode @static
---@field public All DG.Tweening.ScrambleMode @static
---@field public Uppercase DG.Tweening.ScrambleMode @static
---@field public Lowercase DG.Tweening.ScrambleMode @static
---@field public Numerals DG.Tweening.ScrambleMode @static
---@field public Custom DG.Tweening.ScrambleMode @static
---@field public value__ number
local m = {}

DG.Tweening.ScrambleMode = m
return m
