---@class DG.Tweening.Core.Extensions : System.Object
local m = {}

DG.Tweening.Core.Extensions = m
return m
