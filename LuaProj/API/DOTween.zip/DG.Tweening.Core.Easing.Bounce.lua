---@class DG.Tweening.Core.Easing.Bounce : System.Object
local m = {}

---@static
---@param time number
---@param duration number
---@param unusedOvershootOrAmplitude number
---@param unusedPeriod number
---@return number
function m.EaseIn(time, duration, unusedOvershootOrAmplitude, unusedPeriod) end

---@static
---@param time number
---@param duration number
---@param unusedOvershootOrAmplitude number
---@param unusedPeriod number
---@return number
function m.EaseOut(time, duration, unusedOvershootOrAmplitude, unusedPeriod) end

---@static
---@param time number
---@param duration number
---@param unusedOvershootOrAmplitude number
---@param unusedPeriod number
---@return number
function m.EaseInOut(time, duration, unusedOvershootOrAmplitude, unusedPeriod) end

DG.Tweening.Core.Easing.Bounce = m
return m
