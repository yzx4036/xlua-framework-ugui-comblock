---@class DG.Tweening.Plugins.Options.VectorOptions : System.ValueType
---@field public axisConstraint DG.Tweening.AxisConstraint
---@field public snapping boolean
local m = {}

---@virtual
function m:Reset() end

DG.Tweening.Plugins.Options.VectorOptions = m
return m
