---@class DG.Tweening.Plugins.Options.RectOptions : System.ValueType
---@field public snapping boolean
local m = {}

---@virtual
function m:Reset() end

DG.Tweening.Plugins.Options.RectOptions = m
return m
