---@class DG.Tweening.Plugins.Core.PathCore.Path : System.Object
---@field public wpLengths number[]
local m = {}

DG.Tweening.Plugins.Core.PathCore.Path = m
return m
