---@class DG.Tweening.Plugins.ColorPlugin : DG.Tweening.Plugins.Core.ABSTweenPlugin_3_UnityEngine_Color_UnityEngine_Color_DG_Tweening_Plugins_Options_ColorOptions_
local m = {}

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Color_UnityEngine_Color_DG_Tweening_Plugins_Options_ColorOptions_
function m:Reset(t) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Color_UnityEngine_Color_DG_Tweening_Plugins_Options_ColorOptions_
---@param isRelative boolean
function m:SetFrom(t, isRelative) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Color_UnityEngine_Color_DG_Tweening_Plugins_Options_ColorOptions_
---@param value UnityEngine.Color
---@return UnityEngine.Color
function m:ConvertToStartValue(t, value) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Color_UnityEngine_Color_DG_Tweening_Plugins_Options_ColorOptions_
function m:SetRelativeEndValue(t) end

---@virtual
---@param t DG.Tweening.Core.TweenerCore_3_UnityEngine_Color_UnityEngine_Color_DG_Tweening_Plugins_Options_ColorOptions_
function m:SetChangeValue(t) end

---@virtual
---@param options DG.Tweening.Plugins.Options.ColorOptions
---@param unitsXSecond number
---@param changeValue UnityEngine.Color
---@return number
function m:GetSpeedBasedDuration(options, unitsXSecond, changeValue) end

---@virtual
---@param options DG.Tweening.Plugins.Options.ColorOptions
---@param t DG.Tweening.Tween
---@param isRelative boolean
---@param getter fun():UnityEngine.Color
---@param setter fun(pNewValue:UnityEngine.Color)
---@param elapsed number
---@param startValue UnityEngine.Color
---@param changeValue UnityEngine.Color
---@param duration number
---@param usingInversePosition boolean
---@param updateNotice DG.Tweening.Core.Enums.UpdateNotice
function m:EvaluateAndApply(options, t, isRelative, getter, setter, elapsed, startValue, changeValue, duration, usingInversePosition, updateNotice) end

DG.Tweening.Plugins.ColorPlugin = m
return m
