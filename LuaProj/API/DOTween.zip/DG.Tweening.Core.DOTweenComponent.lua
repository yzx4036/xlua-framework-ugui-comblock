---@class DG.Tweening.Core.DOTweenComponent : UnityEngine.MonoBehaviour
---@field public inspectorUpdater number
local m = {}

---@virtual
---@param tweenersCapacity number
---@param sequencesCapacity number
---@return DG.Tweening.IDOTweenInit
function m:SetCapacity(tweenersCapacity, sequencesCapacity) end

DG.Tweening.Core.DOTweenComponent = m
return m
