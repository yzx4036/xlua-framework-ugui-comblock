---@class DG.Tweening.PathMode : System.Enum
---@field public Ignore DG.Tweening.PathMode @static
---@field public Full3D DG.Tweening.PathMode @static
---@field public TopDown2D DG.Tweening.PathMode @static
---@field public Sidescroller2D DG.Tweening.PathMode @static
---@field public value__ number
local m = {}

DG.Tweening.PathMode = m
return m
