---@class DG.Tweening.Core.DOSetter_1_T_ : System.MulticastDelegate
local m = {}

---@virtual
---@param pNewValue any
function m:Invoke(pNewValue) end

---@virtual
---@param pNewValue any
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(pNewValue, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

DG.Tweening.Core.DOSetter_1_T_ = m
return m
