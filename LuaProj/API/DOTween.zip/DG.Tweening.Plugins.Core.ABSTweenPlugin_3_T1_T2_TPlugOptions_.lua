---@class DG.Tweening.Plugins.Core.ABSTweenPlugin_3_T1_T2_TPlugOptions_ : System.Object
local m = {}

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_T1_T2_TPlugOptions_
function m:Reset(t) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_T1_T2_TPlugOptions_
---@param isRelative boolean
function m:SetFrom(t, isRelative) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_T1_T2_TPlugOptions_
---@param value any
---@return any
function m:ConvertToStartValue(t, value) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_T1_T2_TPlugOptions_
function m:SetRelativeEndValue(t) end

---@abstract
---@param t DG.Tweening.Core.TweenerCore_3_T1_T2_TPlugOptions_
function m:SetChangeValue(t) end

---@abstract
---@param options System.ValueType
---@param unitsXSecond number
---@param changeValue any
---@return number
function m:GetSpeedBasedDuration(options, unitsXSecond, changeValue) end

---@abstract
---@param options System.ValueType
---@param t DG.Tweening.Tween
---@param isRelative boolean
---@param getter fun():any
---@param setter fun(pNewValue:any)
---@param elapsed number
---@param startValue any
---@param changeValue any
---@param duration number
---@param usingInversePosition boolean
---@param updateNotice DG.Tweening.Core.Enums.UpdateNotice
function m:EvaluateAndApply(options, t, isRelative, getter, setter, elapsed, startValue, changeValue, duration, usingInversePosition, updateNotice) end

DG.Tweening.Plugins.Core.ABSTweenPlugin_3_T1_T2_TPlugOptions_ = m
return m
