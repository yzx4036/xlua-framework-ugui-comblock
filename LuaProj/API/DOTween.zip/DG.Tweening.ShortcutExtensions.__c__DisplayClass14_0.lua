---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass14_0 : System.Object
---@field public target UnityEngine.Light
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass14_0 = m
return m
