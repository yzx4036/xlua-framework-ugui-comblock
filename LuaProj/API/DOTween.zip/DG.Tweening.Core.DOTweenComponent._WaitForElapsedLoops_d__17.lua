---@class DG.Tweening.Core.DOTweenComponent._WaitForElapsedLoops_d__17 : System.Object
---@field public t DG.Tweening.Tween
---@field public elapsedLoops number
local m = {}

DG.Tweening.Core.DOTweenComponent._WaitForElapsedLoops_d__17 = m
return m
