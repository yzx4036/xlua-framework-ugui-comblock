---@class DG.Tweening.Core.Easing.EaseCurve : System.Object
local m = {}

---@param time number
---@param duration number
---@param unusedOvershoot number
---@param unusedPeriod number
---@return number
function m:Evaluate(time, duration, unusedOvershoot, unusedPeriod) end

DG.Tweening.Core.Easing.EaseCurve = m
return m
