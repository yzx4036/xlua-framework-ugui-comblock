---@class DG.Tweening.ShortcutExtensions.__c__DisplayClass29_0 : System.Object
---@field public target UnityEngine.Rigidbody
local m = {}

DG.Tweening.ShortcutExtensions.__c__DisplayClass29_0 = m
return m
