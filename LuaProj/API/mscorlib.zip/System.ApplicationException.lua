---@class System.ApplicationException : System.Exception
local m = {}

System.ApplicationException = m
return m
