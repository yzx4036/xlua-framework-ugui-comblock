---@class Mono.Security.StrongNameManager.Element : System.Object
local m = {}

---@param assembly string
---@return string
function m:GetUsers(assembly) end

Mono.Security.StrongNameManager.Element = m
return m
