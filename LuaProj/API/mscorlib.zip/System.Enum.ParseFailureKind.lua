---@class System.Enum.ParseFailureKind : System.Enum
---@field public None System.Enum.ParseFailureKind @static
---@field public Argument System.Enum.ParseFailureKind @static
---@field public ArgumentNull System.Enum.ParseFailureKind @static
---@field public ArgumentWithParameter System.Enum.ParseFailureKind @static
---@field public UnhandledException System.Enum.ParseFailureKind @static
---@field public value__ number
local m = {}

System.Enum.ParseFailureKind = m
return m
