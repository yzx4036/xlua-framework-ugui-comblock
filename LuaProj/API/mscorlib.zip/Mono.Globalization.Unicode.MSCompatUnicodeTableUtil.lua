---@class Mono.Globalization.Unicode.MSCompatUnicodeTableUtil : System.Object
---@field public ResourceVersion number @static
---@field public Ignorable Mono.Globalization.Unicode.CodePointIndexer @static
---@field public Category Mono.Globalization.Unicode.CodePointIndexer @static
---@field public Level1 Mono.Globalization.Unicode.CodePointIndexer @static
---@field public Level2 Mono.Globalization.Unicode.CodePointIndexer @static
---@field public Level3 Mono.Globalization.Unicode.CodePointIndexer @static
---@field public CjkCHS Mono.Globalization.Unicode.CodePointIndexer @static
---@field public Cjk Mono.Globalization.Unicode.CodePointIndexer @static
local m = {}

Mono.Globalization.Unicode.MSCompatUnicodeTableUtil = m
return m
