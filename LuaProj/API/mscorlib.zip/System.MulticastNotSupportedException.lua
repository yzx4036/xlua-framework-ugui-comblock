---@class System.MulticastNotSupportedException : System.SystemException
local m = {}

System.MulticastNotSupportedException = m
return m
