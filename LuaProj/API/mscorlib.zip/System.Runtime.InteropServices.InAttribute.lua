---@class System.Runtime.InteropServices.InAttribute : System.Attribute
local m = {}

System.Runtime.InteropServices.InAttribute = m
return m
