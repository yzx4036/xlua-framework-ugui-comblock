---@class System.NonSerializedAttribute : System.Attribute
local m = {}

System.NonSerializedAttribute = m
return m
