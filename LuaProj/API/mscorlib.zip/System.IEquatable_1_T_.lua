---@class System.IEquatable_1_T_ : table
local m = {}

---@abstract
---@param other any
---@return boolean
function m:Equals(other) end

System.IEquatable_1_T_ = m
return m
