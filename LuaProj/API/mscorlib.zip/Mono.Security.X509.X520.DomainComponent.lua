---@class Mono.Security.X509.X520.DomainComponent : Mono.Security.X509.X520.AttributeTypeAndValue
local m = {}

Mono.Security.X509.X520.DomainComponent = m
return m
