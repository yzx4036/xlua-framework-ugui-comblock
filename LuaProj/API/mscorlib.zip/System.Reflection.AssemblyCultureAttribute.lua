---@class System.Reflection.AssemblyCultureAttribute : System.Attribute
---@field public Culture string
local m = {}

System.Reflection.AssemblyCultureAttribute = m
return m
