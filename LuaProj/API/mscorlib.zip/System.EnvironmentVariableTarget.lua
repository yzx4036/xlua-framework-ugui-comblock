---@class System.EnvironmentVariableTarget : System.Enum
---@field public Process System.EnvironmentVariableTarget @static
---@field public User System.EnvironmentVariableTarget @static
---@field public Machine System.EnvironmentVariableTarget @static
---@field public value__ number
local m = {}

System.EnvironmentVariableTarget = m
return m
