---@class Microsoft.Win32.RegistryValueOptions : System.Enum
---@field public None Microsoft.Win32.RegistryValueOptions @static
---@field public DoNotExpandEnvironmentNames Microsoft.Win32.RegistryValueOptions @static
---@field public value__ number
local m = {}

Microsoft.Win32.RegistryValueOptions = m
return m
