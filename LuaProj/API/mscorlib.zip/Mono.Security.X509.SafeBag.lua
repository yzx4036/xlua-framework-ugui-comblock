---@class Mono.Security.X509.SafeBag : System.Object
---@field public BagOID string
---@field public ASN1 Mono.Security.ASN1
local m = {}

Mono.Security.X509.SafeBag = m
return m
