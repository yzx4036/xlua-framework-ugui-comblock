---@class Locale : System.Object
local m = {}

---@overload fun(fmt:string, args:any[]|any):string @static
---@overload fun(fmt:string):string @static
---@static
---@param msg string
---@return string
function m.GetText(msg) end

Locale = m
return m
