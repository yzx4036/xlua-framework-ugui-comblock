---@class System.Console.WindowsConsole : System.Object
local m = {}

---@static
---@return number
function m.GetInputCodePage() end

---@static
---@return number
function m.GetOutputCodePage() end

System.Console.WindowsConsole = m
return m
