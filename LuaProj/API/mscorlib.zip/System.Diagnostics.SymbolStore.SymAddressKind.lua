---@class System.Diagnostics.SymbolStore.SymAddressKind : System.Enum
---@field public ILOffset System.Diagnostics.SymbolStore.SymAddressKind @static
---@field public NativeRVA System.Diagnostics.SymbolStore.SymAddressKind @static
---@field public NativeRegister System.Diagnostics.SymbolStore.SymAddressKind @static
---@field public NativeRegisterRelative System.Diagnostics.SymbolStore.SymAddressKind @static
---@field public NativeOffset System.Diagnostics.SymbolStore.SymAddressKind @static
---@field public NativeRegisterRegister System.Diagnostics.SymbolStore.SymAddressKind @static
---@field public NativeRegisterStack System.Diagnostics.SymbolStore.SymAddressKind @static
---@field public NativeStackRegister System.Diagnostics.SymbolStore.SymAddressKind @static
---@field public BitField System.Diagnostics.SymbolStore.SymAddressKind @static
---@field public NativeSectionOffset System.Diagnostics.SymbolStore.SymAddressKind @static
---@field public value__ number
local m = {}

System.Diagnostics.SymbolStore.SymAddressKind = m
return m
