---@class Mono.MonoAssemblyName._public_key_token_e__FixedBuffer : System.ValueType
---@field public FixedElementField number
local m = {}

Mono.MonoAssemblyName._public_key_token_e__FixedBuffer = m
return m
