---@class System.STAThreadAttribute : System.Attribute
local m = {}

System.STAThreadAttribute = m
return m
