---@class Mono.Math.Prime.ConfidenceFactor : System.Enum
---@field public ExtraLow Mono.Math.Prime.ConfidenceFactor @static
---@field public Low Mono.Math.Prime.ConfidenceFactor @static
---@field public Medium Mono.Math.Prime.ConfidenceFactor @static
---@field public High Mono.Math.Prime.ConfidenceFactor @static
---@field public ExtraHigh Mono.Math.Prime.ConfidenceFactor @static
---@field public Provable Mono.Math.Prime.ConfidenceFactor @static
---@field public value__ number
local m = {}

Mono.Math.Prime.ConfidenceFactor = m
return m
