---@class System.Tuple : System.Object
local m = {}

---@overload fun(item1:any, item2:any):any @static
---@overload fun(item1:any, item2:any, item3:any):any @static
---@overload fun(item1:any, item2:any, item3:any, item4:any):any @static
---@overload fun(item1:any, item2:any, item3:any, item4:any, item5:any):any @static
---@overload fun(item1:any, item2:any, item3:any, item4:any, item5:any, item6:any):any @static
---@overload fun(item1:any, item2:any, item3:any, item4:any, item5:any, item6:any, item7:any):any @static
---@overload fun(item1:any, item2:any, item3:any, item4:any, item5:any, item6:any, item7:any, item8:any):any @static
---@static
---@param item1 any
---@return any
function m.Create(item1) end

System.Tuple = m
return m
