---@class Mono.Runtime : System.Object
local m = {}

---@static
---@param flag boolean
---@return boolean
function m.SetGCAllowSynchronousMajor(flag) end

Mono.Runtime = m
return m
