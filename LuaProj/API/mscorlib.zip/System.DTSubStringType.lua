---@class System.DTSubStringType : System.Enum
---@field public Unknown System.DTSubStringType @static
---@field public Invalid System.DTSubStringType @static
---@field public Number System.DTSubStringType @static
---@field public End System.DTSubStringType @static
---@field public Other System.DTSubStringType @static
---@field public value__ number
local m = {}

System.DTSubStringType = m
return m
