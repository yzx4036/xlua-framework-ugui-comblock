---@class System.Reflection.DefaultMemberAttribute : System.Attribute
---@field public MemberName string
local m = {}

System.Reflection.DefaultMemberAttribute = m
return m
