---@class System.DateTimeFormat : System.Object
local m = {}

System.DateTimeFormat = m
return m
