---@class Interop.Libraries : System.Object
local m = {}

Interop.Libraries = m
return m
