---@class System.Char : System.ValueType
---@field public MaxValue number @static
---@field public MinValue number @static
local m = {}

---@overload fun(value:number):number @virtual
---@virtual
---@param value any
---@return number
function m:CompareTo(value) end

---@overload fun(obj:number):boolean @virtual
---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@static
---@param utf32 number
---@return string
function m.ConvertFromUtf32(utf32) end

---@overload fun(s:string, index:number):number @static
---@static
---@param highSurrogate number
---@param lowSurrogate number
---@return number
function m.ConvertToUtf32(highSurrogate, lowSurrogate) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param highSurrogate number
---@param lowSurrogate number
---@return boolean
function m.IsSurrogatePair(highSurrogate, lowSurrogate) end

---@virtual
---@return number
function m:GetHashCode() end

---@overload fun(s:string, index:number):number @static
---@static
---@param c number
---@return number
function m.GetNumericValue(c) end

---@overload fun(s:string, index:number):System.Globalization.UnicodeCategory @static
---@static
---@param c number
---@return System.Globalization.UnicodeCategory
function m.GetUnicodeCategory(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsControl(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsDigit(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsHighSurrogate(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsLetter(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsLetterOrDigit(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsLower(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsLowSurrogate(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsNumber(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsPunctuation(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsSeparator(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsSurrogate(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsSymbol(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsUpper(c) end

---@overload fun(s:string, index:number):boolean @static
---@static
---@param c number
---@return boolean
function m.IsWhiteSpace(c) end

---@static
---@param s string
---@return boolean, System.Char
function m.TryParse(s) end

---@static
---@param s string
---@return number
function m.Parse(s) end

---@overload fun(c:number, culture:System.Globalization.CultureInfo):number @static
---@static
---@param c number
---@return number
function m.ToLower(c) end

---@static
---@param c number
---@return number
function m.ToLowerInvariant(c) end

---@overload fun(c:number, culture:System.Globalization.CultureInfo):number @static
---@static
---@param c number
---@return number
function m.ToUpper(c) end

---@static
---@param c number
---@return number
function m.ToUpperInvariant(c) end

---@overload fun(c:number):string @static
---@overload fun(provider:System.IFormatProvider):string @virtual
---@virtual
---@return string
function m:ToString() end

---@virtual
---@return System.TypeCode
function m:GetTypeCode() end

System.Char = m
return m
