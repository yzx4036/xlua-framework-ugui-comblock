---@class System.LocalDataStoreElement : System.Object
---@field public Value any
---@field public Cookie number
local m = {}

System.LocalDataStoreElement = m
return m
