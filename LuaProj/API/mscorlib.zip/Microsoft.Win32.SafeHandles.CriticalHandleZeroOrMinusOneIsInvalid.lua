---@class Microsoft.Win32.SafeHandles.CriticalHandleZeroOrMinusOneIsInvalid : System.Runtime.InteropServices.CriticalHandle
---@field public IsInvalid boolean
local m = {}

Microsoft.Win32.SafeHandles.CriticalHandleZeroOrMinusOneIsInvalid = m
return m
