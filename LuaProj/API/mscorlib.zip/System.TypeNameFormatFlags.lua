---@class System.TypeNameFormatFlags : System.Enum
---@field public FormatBasic System.TypeNameFormatFlags @static
---@field public FormatNamespace System.TypeNameFormatFlags @static
---@field public FormatFullInst System.TypeNameFormatFlags @static
---@field public FormatAssembly System.TypeNameFormatFlags @static
---@field public FormatSignature System.TypeNameFormatFlags @static
---@field public FormatNoVersion System.TypeNameFormatFlags @static
---@field public FormatAngleBrackets System.TypeNameFormatFlags @static
---@field public FormatStubInfo System.TypeNameFormatFlags @static
---@field public FormatGenericParam System.TypeNameFormatFlags @static
---@field public FormatSerialization System.TypeNameFormatFlags @static
---@field public value__ number
local m = {}

System.TypeNameFormatFlags = m
return m
