---@class System.Diagnostics.DebuggerBrowsableState : System.Enum
---@field public Never System.Diagnostics.DebuggerBrowsableState @static
---@field public Collapsed System.Diagnostics.DebuggerBrowsableState @static
---@field public RootHidden System.Diagnostics.DebuggerBrowsableState @static
---@field public value__ number
local m = {}

System.Diagnostics.DebuggerBrowsableState = m
return m
