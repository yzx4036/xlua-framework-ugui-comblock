---@class System.Diagnostics.DebuggerTypeProxyAttribute : System.Attribute
---@field public ProxyTypeName string
---@field public Target System.Type
---@field public TargetTypeName string
local m = {}

System.Diagnostics.DebuggerTypeProxyAttribute = m
return m
