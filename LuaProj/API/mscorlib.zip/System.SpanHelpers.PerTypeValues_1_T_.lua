---@class System.SpanHelpers.PerTypeValues_1_T_ : System.Object
---@field public IsReferenceOrContainsReferences boolean @static
---@field public EmptyArray any[] @static
---@field public ArrayAdjustment System.IntPtr @static
local m = {}

System.SpanHelpers.PerTypeValues_1_T_ = m
return m
