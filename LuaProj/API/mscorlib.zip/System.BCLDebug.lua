---@class System.BCLDebug : System.Object
local m = {}

---@static
---@param condition boolean
---@param message string
function m.Assert(condition, message) end

---@overload fun(switchName:string, message:string) @static
---@overload fun(switchName:string, level:System.LogLevel, messages:any[]|any) @static
---@overload fun(switchName:string, level:System.LogLevel) @static
---@static
---@param message string
function m.Log(message) end

---@overload fun(switchName:string) @static
---@static
---@param switchName string
---@param messages any[]|any
function m.Trace(switchName, messages) end

System.BCLDebug = m
return m
