---@class System.ContextBoundObject : System.MarshalByRefObject
local m = {}

System.ContextBoundObject = m
return m
