---@class System.PlatformNotSupportedException : System.NotSupportedException
local m = {}

System.PlatformNotSupportedException = m
return m
