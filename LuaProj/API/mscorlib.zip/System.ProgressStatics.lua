---@class System.ProgressStatics : System.Object
local m = {}

System.ProgressStatics = m
return m
