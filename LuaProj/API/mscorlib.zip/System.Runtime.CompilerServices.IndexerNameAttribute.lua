---@class System.Runtime.CompilerServices.IndexerNameAttribute : System.Attribute
local m = {}

System.Runtime.CompilerServices.IndexerNameAttribute = m
return m
