---@class System.Configuration.Assemblies.AssemblyHashAlgorithm : System.Enum
---@field public None System.Configuration.Assemblies.AssemblyHashAlgorithm @static
---@field public MD5 System.Configuration.Assemblies.AssemblyHashAlgorithm @static
---@field public SHA1 System.Configuration.Assemblies.AssemblyHashAlgorithm @static
---@field public value__ number
local m = {}

System.Configuration.Assemblies.AssemblyHashAlgorithm = m
return m
