---@class System.Runtime.InteropServices.DefaultCharSetAttribute : System.Attribute
---@field public CharSet System.Runtime.InteropServices.CharSet
local m = {}

System.Runtime.InteropServices.DefaultCharSetAttribute = m
return m
