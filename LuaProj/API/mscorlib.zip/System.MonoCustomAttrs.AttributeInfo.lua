---@class System.MonoCustomAttrs.AttributeInfo : System.Object
---@field public Usage System.AttributeUsageAttribute
---@field public InheritanceLevel number
local m = {}

System.MonoCustomAttrs.AttributeInfo = m
return m
