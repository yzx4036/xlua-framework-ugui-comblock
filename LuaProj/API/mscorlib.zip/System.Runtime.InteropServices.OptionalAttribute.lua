---@class System.Runtime.InteropServices.OptionalAttribute : System.Attribute
local m = {}

System.Runtime.InteropServices.OptionalAttribute = m
return m
