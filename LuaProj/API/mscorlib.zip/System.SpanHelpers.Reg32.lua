---@class System.SpanHelpers.Reg32 : System.ValueType
local m = {}

System.SpanHelpers.Reg32 = m
return m
