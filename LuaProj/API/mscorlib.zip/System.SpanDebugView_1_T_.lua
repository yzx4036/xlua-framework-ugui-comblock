---@class System.SpanDebugView_1_T_ : System.Object
---@field public Items any[]
local m = {}

System.SpanDebugView_1_T_ = m
return m
