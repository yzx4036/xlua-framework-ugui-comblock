---@class System.UnitySerializationHolder : System.Object
local m = {}

---@static
---@param instance System.Type
---@param info System.Runtime.Serialization.SerializationInfo
---@param ctx System.Runtime.Serialization.StreamingContext
function m.GetTypeData(instance, info, ctx) end

---@static
---@param instance System.DBNull
---@param info System.Runtime.Serialization.SerializationInfo
---@param ctx System.Runtime.Serialization.StreamingContext
function m.GetDBNullData(instance, info, ctx) end

---@static
---@param instance System.Reflection.Assembly
---@param info System.Runtime.Serialization.SerializationInfo
---@param ctx System.Runtime.Serialization.StreamingContext
function m.GetAssemblyData(instance, info, ctx) end

---@static
---@param instance System.Reflection.Module
---@param info System.Runtime.Serialization.SerializationInfo
---@param ctx System.Runtime.Serialization.StreamingContext
function m.GetModuleData(instance, info, ctx) end

---@virtual
---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end

---@virtual
---@param context System.Runtime.Serialization.StreamingContext
---@return any
function m:GetRealObject(context) end

System.UnitySerializationHolder = m
return m
