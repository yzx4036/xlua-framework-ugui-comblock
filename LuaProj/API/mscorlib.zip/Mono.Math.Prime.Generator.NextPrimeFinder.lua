---@class Mono.Math.Prime.Generator.NextPrimeFinder : Mono.Math.Prime.Generator.SequentialSearchPrimeGeneratorBase
local m = {}

Mono.Math.Prime.Generator.NextPrimeFinder = m
return m
