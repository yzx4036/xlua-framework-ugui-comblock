---@class System.ValueTuple : System.ValueType
local m = {}

---@overload fun(other:System.ValueTuple):boolean @virtual
---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@param other System.ValueTuple
---@return number
function m:CompareTo(other) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@return string
function m:ToString() end

---@overload fun(item1:any):System.ValueType @static
---@overload fun(item1:any, item2:any):System.ValueType @static
---@overload fun(item1:any, item2:any, item3:any):System.ValueType @static
---@overload fun(item1:any, item2:any, item3:any, item4:any):System.ValueType @static
---@overload fun(item1:any, item2:any, item3:any, item4:any, item5:any):System.ValueType @static
---@overload fun(item1:any, item2:any, item3:any, item4:any, item5:any, item6:any):System.ValueType @static
---@overload fun(item1:any, item2:any, item3:any, item4:any, item5:any, item6:any, item7:any):System.ValueType @static
---@overload fun(item1:any, item2:any, item3:any, item4:any, item5:any, item6:any, item7:any, item8:any):System.ValueType @static
---@static
---@return System.ValueTuple
function m.Create() end

System.ValueTuple = m
return m
