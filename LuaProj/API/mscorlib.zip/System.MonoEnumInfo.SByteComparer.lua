---@class System.MonoEnumInfo.SByteComparer : System.Object
local m = {}

---@overload fun(ix:number, iy:number):number @virtual
---@virtual
---@param x any
---@param y any
---@return number
function m:Compare(x, y) end

System.MonoEnumInfo.SByteComparer = m
return m
