---@class System.DayOfWeek : System.Enum
---@field public Sunday System.DayOfWeek @static
---@field public Monday System.DayOfWeek @static
---@field public Tuesday System.DayOfWeek @static
---@field public Wednesday System.DayOfWeek @static
---@field public Thursday System.DayOfWeek @static
---@field public Friday System.DayOfWeek @static
---@field public Saturday System.DayOfWeek @static
---@field public value__ number
local m = {}

System.DayOfWeek = m
return m
