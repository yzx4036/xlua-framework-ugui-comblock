---@class Microsoft.Win32.NativeMethods : System.Object
local m = {}

---@static
---@return number
function m.GetCurrentProcessId() end

Microsoft.Win32.NativeMethods = m
return m
