---@class System.Lazy_1.__c_T_ : System.Object
---@field public <>9 System.Lazy_1.__c_T_ @static
local m = {}

System.Lazy_1.__c_T_ = m
return m
