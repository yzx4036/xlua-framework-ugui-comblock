---@class Mono.Globalization.Unicode.SimpleCollator.PreviousInfo : System.ValueType
---@field public Code number
---@field public SortKey System.Byte*
local m = {}

Mono.Globalization.Unicode.SimpleCollator.PreviousInfo = m
return m
