---@class Mono.RuntimeStructs.HandleStackMark : System.ValueType
local m = {}

Mono.RuntimeStructs.HandleStackMark = m
return m
