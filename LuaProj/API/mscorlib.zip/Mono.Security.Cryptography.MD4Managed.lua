---@class Mono.Security.Cryptography.MD4Managed : Mono.Security.Cryptography.MD4
local m = {}

---@virtual
function m:Initialize() end

Mono.Security.Cryptography.MD4Managed = m
return m
