---@class System.AttributeUsageAttribute : System.Attribute
---@field public AllowMultiple boolean
---@field public Inherited boolean
---@field public ValidOn System.AttributeTargets
local m = {}

System.AttributeUsageAttribute = m
return m
