---@class System.Diagnostics.ConditionalAttribute : System.Attribute
---@field public ConditionString string
local m = {}

System.Diagnostics.ConditionalAttribute = m
return m
