---@class System.IRuntimeMethodInfo : table
---@field public Value System.RuntimeMethodHandleInternal
local m = {}

System.IRuntimeMethodInfo = m
return m
