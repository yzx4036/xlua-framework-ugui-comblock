---@class System.ConsoleCursorInfo : System.ValueType
---@field public Size number
---@field public Visible boolean
local m = {}

System.ConsoleCursorInfo = m
return m
