---@class System.SmallRect : System.ValueType
---@field public Left number
---@field public Top number
---@field public Right number
---@field public Bottom number
local m = {}

System.SmallRect = m
return m
