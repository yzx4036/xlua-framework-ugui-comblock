---@class System.Guid.GuidParser : System.Object
local m = {}

---@return System.Guid
function m:Parse() end

System.Guid.GuidParser = m
return m
