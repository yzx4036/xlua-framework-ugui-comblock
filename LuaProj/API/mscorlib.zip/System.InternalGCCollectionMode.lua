---@class System.InternalGCCollectionMode : System.Enum
---@field public NonBlocking System.InternalGCCollectionMode @static
---@field public Blocking System.InternalGCCollectionMode @static
---@field public Optimized System.InternalGCCollectionMode @static
---@field public Compacting System.InternalGCCollectionMode @static
---@field public value__ number
local m = {}

System.InternalGCCollectionMode = m
return m
