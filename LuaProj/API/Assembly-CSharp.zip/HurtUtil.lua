---@class HurtUtil : System.Object
local m = {}

---@overload fun(bu:BattleUnit, type:FallType, value:number, index:number) @static
---@overload fun(bu:BattleUnit, type:FallType, value:number) @static
---@overload fun(bu:BattleUnit, type:FallType) @static
---@static
---@param bu BattleUnit
---@param type FallType
---@param value number
---@param index number
---@param pos number[]
function m.hurt(bu, type, value, index, pos) end

---@overload fun(pos:UnityEngine.Vector3, word:string, scale:number) @static
---@static
---@param bu BattleUnit
---@param word string
---@param index number
function m.PlayBufWord(bu, word, index) end

---@static
---@param bu BattleUnit
---@param value number
---@param flag number
function m.PlayDixing(bu, value, flag) end

---@static
---@param bu BattleUnit
---@param skillId number
function m.PlaySkillName(bu, skillId) end

HurtUtil = m
return m
