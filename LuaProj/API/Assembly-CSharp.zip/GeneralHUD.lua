---@class GeneralHUD : BasicHUD
local m = {}

---@virtual
---@param fightObjType EnumFightObjType
function m:Init(fightObjType) end

---@virtual
---@param country number
---@param name string
function m:SetCountryAndName(country, name) end

---@virtual
---@param _value number
---@param whitevalue number
function m:UpdateHp(_value, whitevalue) end

GeneralHUD = m
return m
