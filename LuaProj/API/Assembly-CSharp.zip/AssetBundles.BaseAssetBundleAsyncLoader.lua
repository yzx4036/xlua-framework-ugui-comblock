---@class AssetBundles.BaseAssetBundleAsyncLoader : AssetBundles.ResourceAsyncOperation
---@field public assetbundleName string
---@field public assetbundle UnityEngine.AssetBundle
local m = {}

---@virtual
function m:Dispose() end

AssetBundles.BaseAssetBundleAsyncLoader = m
return m
