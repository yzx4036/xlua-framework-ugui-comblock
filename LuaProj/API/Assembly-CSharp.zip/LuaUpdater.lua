---@class LuaUpdater : UnityEngine.MonoBehaviour
local m = {}

---@param luaEnv XLua.LuaEnv
function m:OnInit(luaEnv) end

---@param luaEnv XLua.LuaEnv
function m:Restart(luaEnv) end

function m:OnDispose() end

LuaUpdater = m
return m
