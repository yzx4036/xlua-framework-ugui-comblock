---@class PureSingleton_1_ShakeUtil_ : System.Object
---@field public Instance ShakeUtil @static
local m = {}

PureSingleton_1_ShakeUtil_ = m
return m
