---@class GDTimer.TimerIDGen : System.Object
local m = {}

---@return number
function m:Gen() end

GDTimer.TimerIDGen = m
return m
