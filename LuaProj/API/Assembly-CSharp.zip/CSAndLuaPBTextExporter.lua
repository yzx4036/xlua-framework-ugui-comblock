---@class CSAndLuaPBTextExporter : System.Object
---@field public CSharpCallLua System.Type[] @static
local m = {}

CSAndLuaPBTextExporter = m
return m
