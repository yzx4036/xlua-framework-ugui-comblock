---@class EyeSoft.TouchEventType : System.Object
---@field public None number @static
---@field public Tap number @static
---@field public TouchStart number @static
---@field public TouchEnd number @static
---@field public Swipe number @static
---@field public SwipeBegin number @static
---@field public SwipeEnd number @static
---@field public Drag number @static
---@field public DragBegin number @static
---@field public DragEnd number @static
---@field public PinchBegin number @static
---@field public PinchIn number @static
---@field public PinchOut number @static
---@field public PinchEnd number @static
---@field public TouchUI number @static
---@field public i2s string[] @static
local m = {}

EyeSoft.TouchEventType = m
return m
