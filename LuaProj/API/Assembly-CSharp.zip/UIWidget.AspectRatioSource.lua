---@class UIWidget.AspectRatioSource : System.Enum
---@field public Free UIWidget.AspectRatioSource @static
---@field public BasedOnWidth UIWidget.AspectRatioSource @static
---@field public BasedOnHeight UIWidget.AspectRatioSource @static
---@field public value__ number
local m = {}

UIWidget.AspectRatioSource = m
return m
