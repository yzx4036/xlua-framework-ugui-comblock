---@class MapEditor.EGridAgle : System.Enum
---@field public TopLeft_ExteriorAngle MapEditor.EGridAgle @static
---@field public TopLeft_WithinAngle MapEditor.EGridAgle @static
---@field public BottomLeft_ExteriorAngle MapEditor.EGridAgle @static
---@field public BottomLeft_WithinAngle MapEditor.EGridAgle @static
---@field public TopRight_ExteriorAngle MapEditor.EGridAgle @static
---@field public TopRight_WithinAngle MapEditor.EGridAgle @static
---@field public BottomRight_ExteriorAngle MapEditor.EGridAgle @static
---@field public BottomRight_WithinAngle MapEditor.EGridAgle @static
---@field public Top_Line MapEditor.EGridAgle @static
---@field public Bottom_Line MapEditor.EGridAgle @static
---@field public Left_Line MapEditor.EGridAgle @static
---@field public Right_Line MapEditor.EGridAgle @static
---@field public value__ number
local m = {}

MapEditor.EGridAgle = m
return m
