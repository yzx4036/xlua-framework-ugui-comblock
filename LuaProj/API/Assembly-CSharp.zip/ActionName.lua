---@class ActionName : System.Object
---@field public stand string @static
---@field public run string @static
---@field public hurt string @static
---@field public dead string @static
---@field public attack string @static
---@field public attack2 string @static
---@field public attack3 string @static
---@field public skill string @static
---@field public skill2 string @static
---@field public fly string @static
---@field public fei string @static
---@field public walk string @static
---@field public sentry string @static
local m = {}

---@static
---@param action string
---@return boolean
function m.isAttackAction(action) end

---@static
---@param action string
---@return boolean
function m.isFlyAction(action) end

---@static
---@param action EnumAction
---@return string
function m.GetActionName(action) end

---@static
---@param action string
---@return string
function m.getHorseActionName(action) end

ActionName = m
return m
