---@class SkEffRandomHit : SkEffBase
local m = {}

SkEffRandomHit = m
return m
