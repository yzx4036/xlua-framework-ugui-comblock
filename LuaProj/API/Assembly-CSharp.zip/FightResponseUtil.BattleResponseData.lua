---@class FightResponseUtil.BattleResponseData : System.ValueType
---@field public cmd number
---@field public lifeTime number
---@field public bdata ProtoBuf.IExtensible
local m = {}

FightResponseUtil.BattleResponseData = m
return m
