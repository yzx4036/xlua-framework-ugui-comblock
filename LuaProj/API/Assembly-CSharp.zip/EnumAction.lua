---@class EnumAction : System.Enum
---@field public STAND EnumAction @static
---@field public RUN EnumAction @static
---@field public HURT EnumAction @static
---@field public DEAD EnumAction @static
---@field public ATTACK EnumAction @static
---@field public ATTACK_2 EnumAction @static
---@field public ATTACK_3 EnumAction @static
---@field public SKILL EnumAction @static
---@field public SKILL_2 EnumAction @static
---@field public FLY EnumAction @static
---@field public FEI EnumAction @static
---@field public WALK EnumAction @static
---@field public SENTRY EnumAction @static
---@field public value__ number
local m = {}

EnumAction = m
return m
