---@class FightManager : PureSingleton_1_FightManager_
---@field public isRealEnd boolean
local m = {}

---@param initData com.proto.S2C_WAR_BATTLE_INIT
function m:begin(initData) end

---@param list com.proto.HeroWarData[]
---@param isNeedDealEntrance boolean
function m:dealAddBu(list, isNeedDealEntrance) end

---@param isAddCameraControl boolean
function m:SendFightBegin(isAddCameraControl) end

---@overload fun()
---@param isRealEnd boolean
function m:end(isRealEnd) end

---@param _dt number
function m:update(_dt) end

FightManager = m
return m
