---@class Spin : UnityEngine.MonoBehaviour
---@field public rotationsPerSecond UnityEngine.Vector3
---@field public ignoreTimeScale boolean
local m = {}

---@param delta number
function m:ApplyDelta(delta) end

Spin = m
return m
