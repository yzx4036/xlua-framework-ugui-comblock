---@class UIOrthoCamera : UnityEngine.MonoBehaviour
local m = {}

UIOrthoCamera = m
return m
