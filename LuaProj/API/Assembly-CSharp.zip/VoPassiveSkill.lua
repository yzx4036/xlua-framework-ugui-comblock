---@class VoPassiveSkill : System.Object
---@field public id number
---@field public magic_in_db string
---@field public spemagic string
---@field public skillArt VoSkillArt
local m = {}

VoPassiveSkill = m
return m
