---@class Effect : System.Object
---@field public EffInfo EffectBaseInfo
---@field public Path string
---@field public BindPoint EnumBindPoint
---@field public localScale number
---@field public LocalScale UnityEngine.Vector3
local m = {}

---@param model SceneModel
---@param baseInfo EffectBaseInfo
---@param _effManager EffectManager
---@param fromPoint UnityEngine.Vector3
---@param beginTime number
function m:Initialize(model, baseInfo, _effManager, fromPoint, beginTime) end

---@param time number
function m:Pause(time) end

---@param minusTime number
function m:Play(minusTime) end

---@virtual
---@param deltaTime number
function m:UpdateTime(deltaTime) end

function m:Release() end

---@virtual
---@return boolean
function m:IsStop() end

---@static
---@param model SceneModel
---@param baseInfo EffectBaseInfo
---@param _effManager EffectManager
---@param fromPoint UnityEngine.Vector3
---@return Effect
function m.CreateEffect(model, baseInfo, _effManager, fromPoint) end

Effect = m
return m
