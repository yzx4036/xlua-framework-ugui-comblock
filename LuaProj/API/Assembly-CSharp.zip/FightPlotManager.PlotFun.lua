---@class FightPlotManager.PlotFun : System.MulticastDelegate
local m = {}

---@virtual
---@param plotEffInfo TBPlotFightEffect
function m:Invoke(plotEffInfo) end

---@virtual
---@param plotEffInfo TBPlotFightEffect
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(plotEffInfo, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

FightPlotManager.PlotFun = m
return m
