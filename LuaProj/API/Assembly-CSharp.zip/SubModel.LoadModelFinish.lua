---@class SubModel.LoadModelFinish : System.MulticastDelegate
local m = {}

---@virtual
---@param sub SubModel
function m:Invoke(sub) end

---@virtual
---@param sub SubModel
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(sub, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

SubModel.LoadModelFinish = m
return m
