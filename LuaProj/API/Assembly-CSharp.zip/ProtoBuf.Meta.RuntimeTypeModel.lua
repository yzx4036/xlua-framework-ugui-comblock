---@class ProtoBuf.Meta.RuntimeTypeModel : ProtoBuf.Meta.TypeModel
---@field public Default ProtoBuf.Meta.RuntimeTypeModel @static
---@field public InferTagFromNameDefault boolean
---@field public AutoAddProtoContractTypesOnly boolean
---@field public UseImplicitZeroDefaults boolean
---@field public AllowParseableTypes boolean
---@field public Item ProtoBuf.Meta.MetaType
---@field public AutoAddMissingTypes boolean
---@field public MetadataTimeoutMilliseconds number
---@field public LockCount number
local m = {}

---@return System.Collections.IEnumerable
function m:GetTypes() end

---@virtual
---@param type System.Type
---@return string
function m:GetSchema(type) end

---@param type System.Type
---@param applyDefaultBehaviour boolean
---@return ProtoBuf.Meta.MetaType
function m:Add(type, applyDefaultBehaviour) end

function m:Freeze() end

---@param value fun(sender:any, args:ProtoBuf.Meta.LockContentedEventArgs)
function m:add_LockContended(value) end

---@param value fun(sender:any, args:ProtoBuf.Meta.LockContentedEventArgs)
function m:remove_LockContended(value) end

---@param methodInfo System.Reflection.MethodInfo
function m:SetDefaultFactory(methodInfo) end

ProtoBuf.Meta.RuntimeTypeModel = m
return m
