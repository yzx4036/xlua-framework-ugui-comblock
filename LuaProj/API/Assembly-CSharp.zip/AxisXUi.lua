---@class AxisXUi : UnityEngine.MonoBehaviour
local m = {}

---@param value boolean
function m:ActivateAxisX(value) end

---@param value boolean
function m:InvertedAxisX(value) end

---@param value number
function m:DeadAxisX(value) end

---@param value number
function m:SpeedAxisX(value) end

---@param value boolean
function m:IsInertiaX(value) end

---@param value number
function m:InertiaSpeedX(value) end

---@param value boolean
function m:ActivateAxisY(value) end

---@param value boolean
function m:InvertedAxisY(value) end

---@param value number
function m:DeadAxisY(value) end

---@param value number
function m:SpeedAxisY(value) end

---@param value boolean
function m:IsInertiaY(value) end

---@param value number
function m:InertiaSpeedY(value) end

AxisXUi = m
return m
