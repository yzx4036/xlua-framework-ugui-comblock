---@class UITweener : UnityEngine.MonoBehaviour
---@field public current UITweener @static
---@field public method UITweener.Method
---@field public style UITweener.Style
---@field public animationCurve UnityEngine.AnimationCurve
---@field public ignoreTimeScale boolean
---@field public delay number
---@field public duration number
---@field public steeperCurves boolean
---@field public tweenGroup number
---@field public onFinished EventDelegate[]
---@field public eventReceiver UnityEngine.GameObject
---@field public callWhenFinished string
---@field public disableReset boolean
---@field public amountPerDelta number
---@field public tweenFactor number
---@field public direction AnimationOrTween.Direction
local m = {}

---@overload fun(del:EventDelegate)
---@param del fun()
function m:SetOnFinished(del) end

---@overload fun(del:EventDelegate)
---@param del fun()
function m:AddOnFinished(del) end

---@param del EventDelegate
function m:RemoveOnFinished(del) end

---@param factor number
---@param isFinished boolean
function m:Sample(factor, isFinished) end

---@overload fun(forward:boolean)
function m:Play() end

function m:PlayForward() end

function m:PlayReverse() end

function m:ResetToBeginning() end

function m:Toggle() end

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@return UITweener
function m.Begin(go, duration) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

UITweener = m
return m
