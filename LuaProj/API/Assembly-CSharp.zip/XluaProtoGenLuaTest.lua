---@class XluaProtoGenLuaTest : UnityEngine.MonoBehaviour
---@field public XluaProtoGenLuaTestLuaScript UnityEngine.TextAsset
local m = {}

XluaProtoGenLuaTest = m
return m
