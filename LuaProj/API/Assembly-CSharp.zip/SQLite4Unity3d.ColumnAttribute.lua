---@class SQLite4Unity3d.ColumnAttribute : System.Attribute
---@field public Name string
local m = {}

SQLite4Unity3d.ColumnAttribute = m
return m
