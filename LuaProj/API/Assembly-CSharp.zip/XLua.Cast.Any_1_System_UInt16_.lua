---@class XLua.Cast.Any_1_System_UInt16_ : System.Object
---@field public Target any
local m = {}

XLua.Cast.Any_1_System_UInt16_ = m
return m
