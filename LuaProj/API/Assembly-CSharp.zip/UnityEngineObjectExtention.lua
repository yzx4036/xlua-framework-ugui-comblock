---@class UnityEngineObjectExtention : System.Object
local m = {}

---@static
---@param o UnityEngine.Object
---@return boolean
function m.IsNull(o) end

UnityEngineObjectExtention = m
return m
