---@class ProtoBuf.Serializers.ParseableSerializer : System.Object
---@field public ExpectedType System.Type
local m = {}

---@static
---@param type System.Type
---@param model ProtoBuf.Meta.TypeModel
---@return ProtoBuf.Serializers.ParseableSerializer
function m.TryCreate(type, model) end

---@virtual
---@param value any
---@param source ProtoBuf.ProtoReader
---@return any
function m:Read(value, source) end

---@virtual
---@param value any
---@param dest ProtoBuf.ProtoWriter
function m:Write(value, dest) end

ProtoBuf.Serializers.ParseableSerializer = m
return m
