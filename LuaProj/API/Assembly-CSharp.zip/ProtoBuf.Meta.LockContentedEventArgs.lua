---@class ProtoBuf.Meta.LockContentedEventArgs : System.EventArgs
---@field public OwnerStackTrace string
local m = {}

ProtoBuf.Meta.LockContentedEventArgs = m
return m
