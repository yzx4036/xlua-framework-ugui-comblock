---@class XLua.CSObjectWrap.UnityEngineSkinnedMeshRendererWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineSkinnedMeshRendererWrap = m
return m
