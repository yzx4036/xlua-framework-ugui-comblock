---@class Localization.LoadFunction : System.MulticastDelegate
local m = {}

---@virtual
---@param path string
---@return string
function m:Invoke(path) end

---@virtual
---@param path string
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(path, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return string
function m:EndInvoke(result) end

Localization.LoadFunction = m
return m
