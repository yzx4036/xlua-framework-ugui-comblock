---@class CoroutineRunner : UnityEngine.MonoBehaviour
local m = {}

---@param toYield any
---@param callback fun()
function m:YieldAndCallback(toYield, callback) end

CoroutineRunner = m
return m
