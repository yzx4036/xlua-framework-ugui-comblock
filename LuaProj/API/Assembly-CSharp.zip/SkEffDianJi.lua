---@class SkEffDianJi : SkEffBase
local m = {}

SkEffDianJi = m
return m
