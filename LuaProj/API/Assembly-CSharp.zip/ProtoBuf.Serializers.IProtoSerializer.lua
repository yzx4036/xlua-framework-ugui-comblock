---@class ProtoBuf.Serializers.IProtoSerializer : table
---@field public ExpectedType System.Type
---@field public RequiresOldValue boolean
---@field public ReturnsValue boolean
local m = {}

---@abstract
---@param value any
---@param dest ProtoBuf.ProtoWriter
function m:Write(value, dest) end

---@abstract
---@param value any
---@param source ProtoBuf.ProtoReader
---@return any
function m:Read(value, source) end

ProtoBuf.Serializers.IProtoSerializer = m
return m
