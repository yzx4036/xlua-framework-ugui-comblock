---@class CSAndLuaPBTest : UnityEngine.MonoBehaviour
---@field public Instance CSAndLuaPBTest @static
---@field public CSAndLuaPBTextLuaScript UnityEngine.TextAsset
local m = {}

---@static
---@param luaEncodeBytes string
function m.ForLuaCallCS(luaEncodeBytes) end

CSAndLuaPBTest = m
return m
