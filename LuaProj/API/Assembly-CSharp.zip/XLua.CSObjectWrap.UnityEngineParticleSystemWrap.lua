---@class XLua.CSObjectWrap.UnityEngineParticleSystemWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineParticleSystemWrap = m
return m
