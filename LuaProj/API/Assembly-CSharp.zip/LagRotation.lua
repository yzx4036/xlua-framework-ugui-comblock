---@class LagRotation : UnityEngine.MonoBehaviour
---@field public speed number
---@field public ignoreTimeScale boolean
local m = {}

function m:OnRepositionEnd() end

LagRotation = m
return m
