---@class VoHeroData : UnityEngine.MonoBehaviour
---@field public heroId number
---@field public heroSysId number
---@field public hp number
---@field public hpMax number
---@field public angry number
---@field public baseData string[]
---@field public buffData string[]
local m = {}

---@param heroId number
---@param heroSysId number
---@param baseD com.proto.SysKeyValue[]
---@param buffD com.proto.QueryHeroBuffData[]
---@param fightObjData VoFightObj
function m:InitData(heroId, heroSysId, baseD, buffD, fightObjData) end

VoHeroData = m
return m
