---@class ProtoBuf.ImplicitFields : System.Enum
---@field public None ProtoBuf.ImplicitFields @static
---@field public AllPublic ProtoBuf.ImplicitFields @static
---@field public AllFields ProtoBuf.ImplicitFields @static
---@field public value__ number
local m = {}

ProtoBuf.ImplicitFields = m
return m
