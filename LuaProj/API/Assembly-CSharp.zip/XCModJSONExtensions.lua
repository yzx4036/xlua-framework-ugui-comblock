---@class XCModJSONExtensions : System.Object
local m = {}

---@overload fun(obj:System.Collections.Generic.Dictionary_2_System_String_System_String_):string @static
---@static
---@param obj System.Collections.Hashtable
---@return string
function m.toJson(obj) end

---@static
---@param json string
---@return System.Collections.ArrayList
function m.arrayListFromJson(json) end

---@static
---@param json string
---@return System.Collections.Hashtable
function m.hashtableFromJson(json) end

XCModJSONExtensions = m
return m
