---@class UIEventListener.FloatDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param go UnityEngine.GameObject
---@param delta number
function m:Invoke(go, delta) end

---@virtual
---@param go UnityEngine.GameObject
---@param delta number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(go, delta, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UIEventListener.FloatDelegate = m
return m
