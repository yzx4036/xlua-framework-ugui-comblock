---@class SceneMapGrid : System.Object
local m = {}

---@param cityId number
---@param x number
---@param y number
---@param nearId number[]
function m:initAddNodeToWorldSceneGrids(cityId, x, y, nearId) end

---@param cityId number
---@return Node
function m:getNodeByCityId(cityId) end

---@return table<number, Node>
function m:getSceneGrids() end

SceneMapGrid = m
return m
