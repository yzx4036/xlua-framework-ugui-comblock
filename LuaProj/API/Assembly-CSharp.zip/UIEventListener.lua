---@class UIEventListener : UnityEngine.MonoBehaviour
---@field public parameter any
---@field public onSubmit fun(go:UnityEngine.GameObject)
---@field public onClick fun(go:UnityEngine.GameObject)
---@field public onDoubleClick fun(go:UnityEngine.GameObject)
---@field public onHover fun(go:UnityEngine.GameObject, state:boolean)
---@field public onPress fun(go:UnityEngine.GameObject, state:boolean)
---@field public onSelect fun(go:UnityEngine.GameObject, state:boolean)
---@field public onScroll fun(go:UnityEngine.GameObject, delta:number)
---@field public onDragStart fun(go:UnityEngine.GameObject)
---@field public onDrag fun(go:UnityEngine.GameObject, delta:UnityEngine.Vector2)
---@field public onDragOver fun(go:UnityEngine.GameObject)
---@field public onDragOut fun(go:UnityEngine.GameObject)
---@field public onDragEnd fun(go:UnityEngine.GameObject)
---@field public onDrop fun(go:UnityEngine.GameObject, obj:UnityEngine.GameObject)
---@field public onKey fun(go:UnityEngine.GameObject, key:UnityEngine.KeyCode)
---@field public onTooltip fun(go:UnityEngine.GameObject, state:boolean)
---@field public onLongPress fun(go:UnityEngine.GameObject)
local m = {}

---@static
---@param go UnityEngine.GameObject
---@return UIEventListener
function m.Get(go) end

UIEventListener = m
return m
