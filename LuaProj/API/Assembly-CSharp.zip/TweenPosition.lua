---@class TweenPosition : UITweener
---@field public from UnityEngine.Vector3
---@field public to UnityEngine.Vector3
---@field public worldSpace boolean
---@field public cachedTransform UnityEngine.Transform
---@field public position UnityEngine.Vector3
---@field public value UnityEngine.Vector3
local m = {}

---@overload fun(go:UnityEngine.GameObject, duration:number, pos:UnityEngine.Vector3, worldSpace:boolean):TweenPosition @static
---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param pos UnityEngine.Vector3
---@return TweenPosition
function m.Begin(go, duration, pos) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenPosition = m
return m
