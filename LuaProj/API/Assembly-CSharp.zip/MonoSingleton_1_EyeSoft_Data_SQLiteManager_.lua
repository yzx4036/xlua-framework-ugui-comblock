---@class MonoSingleton_1_EyeSoft_Data_SQLiteManager_ : UnityEngine.MonoBehaviour
---@field public Instance EyeSoft.Data.SQLiteManager @static
local m = {}

function m:Startup() end

function m:DestroySelf() end

---@virtual
function m:Dispose() end

MonoSingleton_1_EyeSoft_Data_SQLiteManager_ = m
return m
