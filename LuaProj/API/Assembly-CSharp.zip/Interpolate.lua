---@class Interpolate : System.Object
local m = {}

---@overload fun(ease:(fun(a:number, b:number, c:number, d:number):number), start:UnityEngine.Vector3, end:UnityEngine.Vector3, slices:number):System.Collections.IEnumerator @static
---@static
---@param ease fun(a:number, b:number, c:number, d:number):number
---@param start UnityEngine.Vector3
---@param end UnityEngine.Vector3
---@param duration number
---@return System.Collections.IEnumerator
function m.NewEase(ease, start, end, duration) end

---@static
---@param type Interpolate.EaseType
---@return fun(a:number, b:number, c:number, d:number):number
function m.Ease(type) end

---@overload fun(ease:(fun(a:number, b:number, c:number, d:number):number), nodes:UnityEngine.Transform[], slices:number):System.Collections.Generic.IEnumerable_1_UnityEngine_Vector3_ @static
---@overload fun(ease:(fun(a:number, b:number, c:number, d:number):number), points:UnityEngine.Vector3[], duration:number):System.Collections.Generic.IEnumerable_1_UnityEngine_Vector3_ @static
---@overload fun(ease:(fun(a:number, b:number, c:number, d:number):number), points:UnityEngine.Vector3[], slices:number):System.Collections.Generic.IEnumerable_1_UnityEngine_Vector3_ @static
---@static
---@param ease fun(a:number, b:number, c:number, d:number):number
---@param nodes UnityEngine.Transform[]
---@param duration number
---@return System.Collections.Generic.IEnumerable_1_UnityEngine_Vector3_
function m.NewBezier(ease, nodes, duration) end

---@overload fun(points:UnityEngine.Vector3[], slices:number, loop:boolean):System.Collections.Generic.IEnumerable_1_UnityEngine_Vector3_ @static
---@static
---@param nodes UnityEngine.Transform[]
---@param slices number
---@param loop boolean
---@return System.Collections.Generic.IEnumerable_1_UnityEngine_Vector3_
function m.NewCatmullRom(nodes, slices, loop) end

Interpolate = m
return m
