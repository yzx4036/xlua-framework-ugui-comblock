---@class MapInfo : System.Object
---@field public maps table<number, Node>
---@field public start Node
---@field public end Node
local m = {}

MapInfo = m
return m
