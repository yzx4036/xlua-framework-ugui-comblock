---@class XLua.CSObjectWrap.UnityEngineWaitForFixedUpdateWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineWaitForFixedUpdateWrap = m
return m
