---@class SQLite4Unity3d.TableQuery_1_T_ : SQLite4Unity3d.BaseTableQuery
---@field public Connection SQLite4Unity3d.SQLiteConnection
---@field public Table SQLite4Unity3d.TableMapping
local m = {}

---@return SQLite4Unity3d.BaseTableQuery
function m:Clone() end

---@param predExpr System.Linq.Expressions.LambdaExpression
---@return SQLite4Unity3d.TableQuery_1_T_
function m:Where(predExpr) end

---@param n number
---@return SQLite4Unity3d.TableQuery_1_T_
function m:Take(n) end

---@param n number
---@return SQLite4Unity3d.TableQuery_1_T_
function m:Skip(n) end

---@param index number
---@return any
function m:ElementAt(index) end

---@return SQLite4Unity3d.TableQuery_1_T_
function m:Deferred() end

---@param orderExpr System.Linq.Expressions.LambdaExpression
---@return SQLite4Unity3d.TableQuery_1_T_
function m:OrderBy(orderExpr) end

---@param orderExpr System.Linq.Expressions.LambdaExpression
---@return SQLite4Unity3d.TableQuery_1_T_
function m:OrderByDescending(orderExpr) end

---@param orderExpr System.Linq.Expressions.LambdaExpression
---@return SQLite4Unity3d.TableQuery_1_T_
function m:ThenBy(orderExpr) end

---@param orderExpr System.Linq.Expressions.LambdaExpression
---@return SQLite4Unity3d.TableQuery_1_T_
function m:ThenByDescending(orderExpr) end

---@param inner SQLite4Unity3d.BaseTableQuery
---@param outerKeySelector System.Linq.Expressions.LambdaExpression
---@param innerKeySelector System.Linq.Expressions.LambdaExpression
---@param resultSelector System.Linq.Expressions.LambdaExpression
---@return SQLite4Unity3d.BaseTableQuery
function m:Join(inner, outerKeySelector, innerKeySelector, resultSelector) end

---@param selector System.Linq.Expressions.LambdaExpression
---@return SQLite4Unity3d.BaseTableQuery
function m:Select(selector) end

---@overload fun(predExpr:System.Linq.Expressions.LambdaExpression):number
---@return number
function m:Count() end

---@virtual
---@return any
function m:GetEnumerator() end

---@return any
function m:First() end

---@return any
function m:FirstOrDefault() end

SQLite4Unity3d.TableQuery_1_T_ = m
return m
