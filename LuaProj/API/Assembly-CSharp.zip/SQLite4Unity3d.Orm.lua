---@class SQLite4Unity3d.Orm : System.Object
---@field public DefaultMaxStringLength number @static
---@field public ImplicitPkName string @static
---@field public ImplicitIndexSuffix string @static
local m = {}

---@static
---@param p SQLite4Unity3d.TableMapping.Column
---@param storeDateTimeAsTicks boolean
---@return string
function m.SqlDecl(p, storeDateTimeAsTicks) end

---@static
---@param p SQLite4Unity3d.TableMapping.Column
---@param storeDateTimeAsTicks boolean
---@return string
function m.SqlType(p, storeDateTimeAsTicks) end

---@static
---@param p System.Reflection.MemberInfo
---@return boolean
function m.IsPK(p) end

---@static
---@param p System.Reflection.MemberInfo
---@return string
function m.Collation(p) end

---@static
---@param p System.Reflection.MemberInfo
---@return boolean
function m.IsAutoInc(p) end

---@static
---@param p System.Reflection.MemberInfo
---@return System.Collections.Generic.IEnumerable_1_SQLite4Unity3d_IndexedAttribute_
function m.GetIndices(p) end

---@static
---@param p System.Reflection.PropertyInfo
---@return System.Nullable_1_System_Int32_
function m.MaxStringLength(p) end

---@static
---@param p System.Reflection.MemberInfo
---@return boolean
function m.IsMarkedNotNull(p) end

SQLite4Unity3d.Orm = m
return m
