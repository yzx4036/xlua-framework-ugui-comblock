---@class ProtoBuf.WireType : System.Enum
---@field public None ProtoBuf.WireType @static
---@field public Variant ProtoBuf.WireType @static
---@field public Fixed64 ProtoBuf.WireType @static
---@field public String ProtoBuf.WireType @static
---@field public StartGroup ProtoBuf.WireType @static
---@field public EndGroup ProtoBuf.WireType @static
---@field public Fixed32 ProtoBuf.WireType @static
---@field public SignedVariant ProtoBuf.WireType @static
---@field public value__ number
local m = {}

ProtoBuf.WireType = m
return m
