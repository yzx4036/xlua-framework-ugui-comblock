---@class HpCountUtil.VoHpCount : System.Object
---@field public generalHp number
---@field public soilderHp number
local m = {}

HpCountUtil.VoHpCount = m
return m
