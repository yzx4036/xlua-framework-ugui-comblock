---@class MapEditor.RuQinAssist : MapEditor.ElementBaseAssist
local m = {}

MapEditor.RuQinAssist = m
return m
