---@class MonoSingleton_1_EyeSoft_SpriteAtlasManager_ : UnityEngine.MonoBehaviour
---@field public Instance EyeSoft.SpriteAtlasManager @static
local m = {}

function m:Startup() end

function m:DestroySelf() end

---@virtual
function m:Dispose() end

MonoSingleton_1_EyeSoft_SpriteAtlasManager_ = m
return m
