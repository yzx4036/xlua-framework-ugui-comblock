---@class XLua.CSObjectWrap.CustomDataStructStreamBufferWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.CustomDataStructStreamBufferWrap = m
return m
