---@class ProtoBuf.BclHelpers : System.Object
local m = {}

---@static
---@param type System.Type
---@return any
function m.GetUninitializedObject(type) end

---@static
---@param timeSpan System.TimeSpan
---@param dest ProtoBuf.ProtoWriter
function m.WriteTimeSpan(timeSpan, dest) end

---@static
---@param source ProtoBuf.ProtoReader
---@return System.TimeSpan
function m.ReadTimeSpan(source) end

---@static
---@param source ProtoBuf.ProtoReader
---@return System.DateTime
function m.ReadDateTime(source) end

---@static
---@param value System.DateTime
---@param dest ProtoBuf.ProtoWriter
function m.WriteDateTime(value, dest) end

---@static
---@param reader ProtoBuf.ProtoReader
---@return System.Decimal
function m.ReadDecimal(reader) end

---@static
---@param value System.Decimal
---@param writer ProtoBuf.ProtoWriter
function m.WriteDecimal(value, writer) end

---@static
---@param value System.Guid
---@param dest ProtoBuf.ProtoWriter
function m.WriteGuid(value, dest) end

---@static
---@param source ProtoBuf.ProtoReader
---@return System.Guid
function m.ReadGuid(source) end

---@static
---@param value any
---@param source ProtoBuf.ProtoReader
---@param key number
---@param type System.Type
---@param options ProtoBuf.BclHelpers.NetObjectOptions
---@return any
function m.ReadNetObject(value, source, key, type, options) end

---@static
---@param value any
---@param dest ProtoBuf.ProtoWriter
---@param key number
---@param options ProtoBuf.BclHelpers.NetObjectOptions
function m.WriteNetObject(value, dest, key, options) end

ProtoBuf.BclHelpers = m
return m
