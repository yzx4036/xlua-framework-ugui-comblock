---@class Images : System.Object
---@field public clearImage UnityEngine.Texture2D
---@field public collapseImage UnityEngine.Texture2D
---@field public clearOnNewSceneImage UnityEngine.Texture2D
---@field public showTimeImage UnityEngine.Texture2D
---@field public showSceneImage UnityEngine.Texture2D
---@field public userImage UnityEngine.Texture2D
---@field public showMemoryImage UnityEngine.Texture2D
---@field public softwareImage UnityEngine.Texture2D
---@field public dateImage UnityEngine.Texture2D
---@field public showFpsImage UnityEngine.Texture2D
---@field public showGraphImage UnityEngine.Texture2D
---@field public graphImage UnityEngine.Texture2D
---@field public infoImage UnityEngine.Texture2D
---@field public searchImage UnityEngine.Texture2D
---@field public closeImage UnityEngine.Texture2D
---@field public buildFromImage UnityEngine.Texture2D
---@field public systemInfoImage UnityEngine.Texture2D
---@field public graphicsInfoImage UnityEngine.Texture2D
---@field public backImage UnityEngine.Texture2D
---@field public cameraImage UnityEngine.Texture2D
---@field public logImage UnityEngine.Texture2D
---@field public warningImage UnityEngine.Texture2D
---@field public errorImage UnityEngine.Texture2D
---@field public barImage UnityEngine.Texture2D
---@field public button_activeImage UnityEngine.Texture2D
---@field public even_logImage UnityEngine.Texture2D
---@field public odd_logImage UnityEngine.Texture2D
---@field public selectedImage UnityEngine.Texture2D
---@field public reporterScrollerSkin UnityEngine.GUISkin
local m = {}

Images = m
return m
