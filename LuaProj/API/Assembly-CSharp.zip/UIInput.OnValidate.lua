---@class UIInput.OnValidate : System.MulticastDelegate
local m = {}

---@virtual
---@param text string
---@param charIndex number
---@param addedChar number
---@return number
function m:Invoke(text, charIndex, addedChar) end

---@virtual
---@param text string
---@param charIndex number
---@param addedChar number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(text, charIndex, addedChar, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return number
function m:EndInvoke(result) end

UIInput.OnValidate = m
return m
