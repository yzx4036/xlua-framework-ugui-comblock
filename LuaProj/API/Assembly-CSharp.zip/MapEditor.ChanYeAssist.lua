---@class MapEditor.ChanYeAssist : MapEditor.ElementBaseAssist
local m = {}

MapEditor.ChanYeAssist = m
return m
