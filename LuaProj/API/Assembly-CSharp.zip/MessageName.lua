---@class MessageName : System.ValueType
---@field public MN_TEST_MSG number @static
local m = {}

MessageName = m
return m
