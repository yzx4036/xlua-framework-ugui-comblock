---@class PureSingleton_1_BloodManager_ : System.Object
---@field public Instance BloodManager @static
local m = {}

PureSingleton_1_BloodManager_ = m
return m
