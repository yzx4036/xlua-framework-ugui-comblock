---@class UIScrollView.OnMoveRelativeLimit : System.MulticastDelegate
local m = {}

---@virtual
---@param offset UnityEngine.Vector2
---@param relative UnityEngine.Vector3
---@param result UnityEngine.Vector3[]
function m:Invoke(offset, relative, result) end

---@virtual
---@param offset UnityEngine.Vector2
---@param relative UnityEngine.Vector3
---@param result UnityEngine.Vector3[]
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(offset, relative, result, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UIScrollView.OnMoveRelativeLimit = m
return m
