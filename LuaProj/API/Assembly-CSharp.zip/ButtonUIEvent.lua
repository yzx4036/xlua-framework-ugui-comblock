---@class ButtonUIEvent : UnityEngine.MonoBehaviour
---@field public downText UnityEngine.UI.Text
---@field public pressText UnityEngine.UI.Text
---@field public pressValueText UnityEngine.UI.Text
---@field public upText UnityEngine.UI.Text
local m = {}

function m:Down() end

function m:Up() end

function m:Press() end

---@param value number
function m:PressValue(value) end

ButtonUIEvent = m
return m
