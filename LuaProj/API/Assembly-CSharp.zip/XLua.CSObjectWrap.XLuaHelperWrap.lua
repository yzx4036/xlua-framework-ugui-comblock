---@class XLua.CSObjectWrap.XLuaHelperWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.XLuaHelperWrap = m
return m
