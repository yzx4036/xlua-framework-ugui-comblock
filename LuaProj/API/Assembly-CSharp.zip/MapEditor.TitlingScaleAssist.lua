---@class MapEditor.TitlingScaleAssist : UnityEngine.MonoBehaviour
---@field public titling UnityEngine.Vector2
local m = {}

MapEditor.TitlingScaleAssist = m
return m
