---@class UIGeometry : System.Object
---@field public verts BetterList_1_UnityEngine_Vector3_
---@field public uvs BetterList_1_UnityEngine_Vector2_
---@field public cols BetterList_1_UnityEngine_Color32_
---@field public hasVertices boolean
---@field public hasTransformed boolean
local m = {}

function m:Clear() end

---@overload fun(widgetToPanel:UnityEngine.Matrix4x4)
---@param widgetToPanel UnityEngine.Matrix4x4
---@param generateNormals boolean
function m:ApplyTransform(widgetToPanel, generateNormals) end

---@overload fun(v:BetterList_1_UnityEngine_Vector3_, u:BetterList_1_UnityEngine_Vector2_, c:BetterList_1_UnityEngine_Color32_, n:BetterList_1_UnityEngine_Vector3_, t:BetterList_1_UnityEngine_Vector4_, u1:BetterList_1_UnityEngine_Vector2_)
---@param v BetterList_1_UnityEngine_Vector3_
---@param u BetterList_1_UnityEngine_Vector2_
---@param c BetterList_1_UnityEngine_Color32_
---@param n BetterList_1_UnityEngine_Vector3_
---@param t BetterList_1_UnityEngine_Vector4_
---@param u1 BetterList_1_UnityEngine_Vector2_
---@param vIsGray boolean
function m:WriteToBuffers(v, u, c, n, t, u1, vIsGray) end

UIGeometry = m
return m
