---@class PathMoveCurve : MagicInBattle
---@field public TargetPos UnityEngine.Vector3
local m = {}

function m:Init() end

---@param tarPos UnityEngine.Vector3
function m:InitFloor(tarPos) end

---@virtual
---@param _dt number
function m:Update(_dt) end

PathMoveCurve = m
return m
