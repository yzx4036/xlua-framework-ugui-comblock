---@class MultiCameraUI : UnityEngine.MonoBehaviour
---@field public cam2 UnityEngine.Camera
---@field public cam3 UnityEngine.Camera
local m = {}

---@param value boolean
function m:AddCamera2(value) end

---@param value boolean
function m:AddCamera3(value) end

---@param cam UnityEngine.Camera
---@param value boolean
function m:AddCamera(cam, value) end

MultiCameraUI = m
return m
