---@class MultiLayerUI : UnityEngine.MonoBehaviour
local m = {}

---@param value boolean
function m:SetAutoSelect(value) end

---@param value boolean
function m:SetAutoUpdate(value) end

---@param value boolean
function m:Layer1(value) end

---@param value boolean
function m:Layer2(value) end

---@param value boolean
function m:Layer3(value) end

MultiLayerUI = m
return m
