---@class MapEditor.PathLineAssist : UnityEngine.MonoBehaviour
---@field public linePrefab UnityEngine.GameObject
---@field public fileName string
local m = {}

function m:Save() end

MapEditor.PathLineAssist = m
return m
