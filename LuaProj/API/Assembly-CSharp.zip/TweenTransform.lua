---@class TweenTransform : UITweener
---@field public from UnityEngine.Transform
---@field public to UnityEngine.Transform
---@field public parentWhenFinished boolean
local m = {}

---@overload fun(go:UnityEngine.GameObject, duration:number, from:UnityEngine.Transform, to:UnityEngine.Transform):TweenTransform @static
---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param to UnityEngine.Transform
---@return TweenTransform
function m.Begin(go, duration, to) end

TweenTransform = m
return m
