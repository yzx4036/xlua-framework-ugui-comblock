---@class UIDragResize : UnityEngine.MonoBehaviour
---@field public target UIWidget
---@field public pivot UIWidget.Pivot
---@field public minWidth number
---@field public minHeight number
---@field public maxWidth number
---@field public maxHeight number
---@field public updateAnchors boolean
local m = {}

UIDragResize = m
return m
