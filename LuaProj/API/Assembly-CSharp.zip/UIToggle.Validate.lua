---@class UIToggle.Validate : System.MulticastDelegate
local m = {}

---@virtual
---@param choice boolean
---@return boolean
function m:Invoke(choice) end

---@virtual
---@param choice boolean
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(choice, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return boolean
function m:EndInvoke(result) end

UIToggle.Validate = m
return m
