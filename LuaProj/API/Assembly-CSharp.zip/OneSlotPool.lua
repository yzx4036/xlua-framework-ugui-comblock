---@class OneSlotPool : ProtoPoolBase_1_battle_ntf_battle_frame_data_one_slot_
local m = {}

OneSlotPool = m
return m
