---@class EnumFightDirect : System.Enum
---@field public ATTACK EnumFightDirect @static
---@field public DE_ATTACK EnumFightDirect @static
---@field public value__ number
local m = {}

EnumFightDirect = m
return m
