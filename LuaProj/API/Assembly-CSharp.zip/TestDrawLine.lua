---@class TestDrawLine : UnityEngine.MonoBehaviour
---@field public quadPrefab UnityEngine.GameObject
---@field public pointPrefab UnityEngine.GameObject
---@field public linesGo UnityEngine.GameObject
---@field public pathNodeGo UnityEngine.GameObject
local m = {}

TestDrawLine = m
return m
