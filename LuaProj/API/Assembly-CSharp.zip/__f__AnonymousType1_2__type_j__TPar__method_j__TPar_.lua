---@class __f__AnonymousType1_2__type_j__TPar__method_j__TPar_ : System.Object
---@field public type any
---@field public method any
local m = {}

---@virtual
---@param value any
---@return boolean
function m:Equals(value) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@return string
function m:ToString() end

__f__AnonymousType1_2__type_j__TPar__method_j__TPar_ = m
return m
