---@class ParticleSystemClipper : UnityEngine.MonoBehaviour
local m = {}

ParticleSystemClipper = m
return m
