---@class UIPanel.OnClippingMoved : System.MulticastDelegate
local m = {}

---@virtual
---@param panel UIPanel
function m:Invoke(panel) end

---@virtual
---@param panel UIPanel
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(panel, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UIPanel.OnClippingMoved = m
return m
