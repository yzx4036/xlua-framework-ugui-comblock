---@class ETCSetDirectActionTransform : UnityEngine.MonoBehaviour
---@field public axisName1 string
---@field public axisName2 string
local m = {}

ETCSetDirectActionTransform = m
return m
