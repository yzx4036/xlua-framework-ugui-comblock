---@class SubModel : System.Object
---@field public isLoadFinish boolean
---@field public AnimationName string
---@field public AnimComponent UnityEngine.Animation
---@field public transform UnityEngine.Transform
---@field public submodeType EnumSubModelType
---@field public Alpha number
local m = {}

---@param filename string
---@param subModelType EnumSubModelType
---@param resType EnumSceneModelType
---@param lfinish fun(sub:SubModel)
---@param delayTime number
function m:Initialize(filename, subModelType, resType, lfinish, delayTime) end

---@param path string
---@param obj UnityEngine.Object
function m:ModelLoad(path, obj) end

---@param ts UnityEngine.Transform
function m:EnumBindType(ts) end

---@param layer number
function m:ResetLayer(layer) end

---@param parentTrans UnityEngine.Transform
---@param lscale UnityEngine.Vector3
function m:SetParent(parentTrans, lscale) end

---@param vec UnityEngine.Vector3
function m:SetLocalScale(vec) end

---@param active boolean
function m:SetActive(active) end

---@param from UnityEngine.Animation
function m:CopyAnimation(from) end

---@param visible boolean
function m:SetVisibile(visible) end

---@param position UnityEngine.Vector3
function m:SetPosition(position) end

---@param vec UnityEngine.Vector3
function m:SetLocalEuler(vec) end

---@param rotation UnityEngine.Quaternion
function m:SetRotation(rotation) end

---@param bp EnumBindPoint
---@param fromPoint UnityEngine.Vector3
---@return UnityEngine.Transform
function m:GetBindPointTransform(bp, fromPoint) end

---@param cullingType UnityEngine.AnimationCullingType
function m:SetAnimationCullingType(cullingType) end

---@return boolean
function m:HasAnimationComponent() end

---@param animationName string
---@param loop boolean
---@param speed number
---@param fadeTime number
---@param isResetTime boolean
---@param way number
---@param now number
---@return number
function m:PlayAnimation(animationName, loop, speed, fadeTime, isResetTime, way, now) end

---@param animationName string
---@param speed number
function m:SetAnimationSpeed(animationName, speed) end

---@param isSample boolean
function m:StopAnimation(isSample) end

---@param now number
function m:Update(now) end

function m:ResetMaterial() end

---@param _type BattleMatType
function m:ChangeMat(_type) end

function m:Release() end

SubModel = m
return m
