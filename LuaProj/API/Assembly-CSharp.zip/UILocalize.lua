---@class UILocalize : UnityEngine.MonoBehaviour
---@field public key string
---@field public value string
---@field public text string
local m = {}

UILocalize = m
return m
