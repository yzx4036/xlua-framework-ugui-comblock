---@class MeleeWeaponTrail.Point : System.Object
---@field public timeCreated number
---@field public basePosition UnityEngine.Vector3
---@field public tipPosition UnityEngine.Vector3
local m = {}

MeleeWeaponTrail.Point = m
return m
