---@class BattleMatType : System.Enum
---@field public Nomal BattleMatType @static
---@field public Stone BattleMatType @static
---@field public Frost BattleMatType @static
---@field public Fire BattleMatType @static
---@field public Invincible BattleMatType @static
---@field public Frost_XB BattleMatType @static
---@field public value__ number
local m = {}

BattleMatType = m
return m
