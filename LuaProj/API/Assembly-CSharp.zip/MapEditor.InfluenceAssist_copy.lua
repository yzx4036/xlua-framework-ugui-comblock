---@class MapEditor.InfluenceAssist_copy : UnityEngine.MonoBehaviour
---@field public width number
---@field public height number
---@field public cityType number
---@field public curCityPos string
---@field public mapCfg MapEditor.MapInfluenceCfg
---@field public isInit boolean
---@field public cityDic table<number, MapEditor.InfluenceInfo>
local m = {}

function m:Init() end

---@param x number
---@param z number
function m:ClickGrid(x, z) end

function m:Save() end

function m:ClearCurrentCity() end

function m:SetCurrentCityPos() end

---@param x number
---@param y number
---@return boolean
function m:IsValidCoord(x, y) end

MapEditor.InfluenceAssist_copy = m
return m
