---@class ProtoBuf.ProtoTypeCode : System.Enum
---@field public Empty ProtoBuf.ProtoTypeCode @static
---@field public Unknown ProtoBuf.ProtoTypeCode @static
---@field public Boolean ProtoBuf.ProtoTypeCode @static
---@field public Char ProtoBuf.ProtoTypeCode @static
---@field public SByte ProtoBuf.ProtoTypeCode @static
---@field public Byte ProtoBuf.ProtoTypeCode @static
---@field public Int16 ProtoBuf.ProtoTypeCode @static
---@field public UInt16 ProtoBuf.ProtoTypeCode @static
---@field public Int32 ProtoBuf.ProtoTypeCode @static
---@field public UInt32 ProtoBuf.ProtoTypeCode @static
---@field public Int64 ProtoBuf.ProtoTypeCode @static
---@field public UInt64 ProtoBuf.ProtoTypeCode @static
---@field public Single ProtoBuf.ProtoTypeCode @static
---@field public Double ProtoBuf.ProtoTypeCode @static
---@field public Decimal ProtoBuf.ProtoTypeCode @static
---@field public DateTime ProtoBuf.ProtoTypeCode @static
---@field public String ProtoBuf.ProtoTypeCode @static
---@field public TimeSpan ProtoBuf.ProtoTypeCode @static
---@field public ByteArray ProtoBuf.ProtoTypeCode @static
---@field public Guid ProtoBuf.ProtoTypeCode @static
---@field public Uri ProtoBuf.ProtoTypeCode @static
---@field public Type ProtoBuf.ProtoTypeCode @static
---@field public value__ number
local m = {}

ProtoBuf.ProtoTypeCode = m
return m
