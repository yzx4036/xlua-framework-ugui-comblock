---@class SceneSoundPlayer : UnityEngine.MonoBehaviour
---@field public SoundName string
---@field public MaxDistent number
---@field public Volume number
---@field public dis number
local m = {}

function m:StartPlay() end

function m:StopPlay() end

function m:Destroy() end

SceneSoundPlayer = m
return m
