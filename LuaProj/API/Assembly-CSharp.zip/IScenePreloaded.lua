---@class IScenePreloaded : table
local m = {}

---@abstract
function m:StartPreloaded() end

---@abstract
---@return boolean
function m:IsDone() end

IScenePreloaded = m
return m
