---@class UITextList : UnityEngine.MonoBehaviour
---@field public textLabel UILabel
---@field public scrollBar UIProgressBar
---@field public style UITextList.Style
---@field public paragraphHistory number
---@field public isValid boolean
---@field public scrollValue number
local m = {}

function m:Clear() end

---@param val number
function m:OnScroll(val) end

---@param delta UnityEngine.Vector2
function m:OnDrag(delta) end

---@param text string
function m:Add(text) end

UITextList = m
return m
