---@class XLua.CSObjectWrap.UnityEngineUIGraphicRaycasterWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineUIGraphicRaycasterWrap = m
return m
