---@class UIAnchor : UnityEngine.MonoBehaviour
---@field public uiCamera UnityEngine.Camera
---@field public container UnityEngine.GameObject
---@field public side UIAnchor.Side
---@field public runOnlyOnce boolean
---@field public relativeOffset UnityEngine.Vector2
---@field public pixelOffset UnityEngine.Vector2
local m = {}

UIAnchor = m
return m
