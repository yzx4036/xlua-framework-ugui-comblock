---@class BuffUtil : PureSingleton_1_BuffUtil_
local m = {}

function m:ClearBufBloodTime() end

---@param buffData number[]
function m:dealBufBlood(buffData) end

---@param buffData number[]
---@param xz number[]
function m:dealBufBloodThunder(buffData, xz) end

---@param buffData number[]
function m:dealBufOffset(buffData) end

---@param buffData number
function m:removeBuf(buffData) end

---@param buId number
---@param bufId number
---@param bufSysId number
---@param isAddEffDelay boolean
function m:addBuf(buId, bufId, bufSysId, isAddEffDelay) end

---@overload fun(bu:BattleUnit, bufIds:number[])
---@param data VoBuffOnSkill[]
---@param isAddEffDelay boolean
function m:addBufs(data, isAddEffDelay) end

---@param data VoBuffOnSkill[]
function m:addBufEffFromWait(data) end

---@param bu BattleUnit
---@param bufId number
function m:addBufFromWait(bu, bufId) end

BuffUtil = m
return m
