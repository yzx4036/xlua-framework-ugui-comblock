---@class SpineDrawerValuePair : UnityEngine.MonoBehaviour
---@field public str string
---@field public property UnityEditor.SerializedProperty
local m = {}

SpineDrawerValuePair = m
return m
