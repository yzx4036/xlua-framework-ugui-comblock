---@class UICamera.GetAnyKeyFunc : System.MulticastDelegate
local m = {}

---@virtual
---@return boolean
function m:Invoke() end

---@virtual
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return boolean
function m:EndInvoke(result) end

UICamera.GetAnyKeyFunc = m
return m
