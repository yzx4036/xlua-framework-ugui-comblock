---@class MapEditor.InfluenceInitializeAssist : UnityEngine.MonoBehaviour
---@field public InitColor UnityEngine.Color @static
---@field public InitAlpha number @static
---@field public rhombusPrefab UnityEngine.GameObject
local m = {}

function m:Initialize() end

---@param isInit boolean
function m:ComplementGrid(isInit) end

---@static
---@param go UnityEngine.GameObject
---@param x number
---@param y number
function m.VerifyPosition(go, x, y) end

MapEditor.InfluenceInitializeAssist = m
return m
