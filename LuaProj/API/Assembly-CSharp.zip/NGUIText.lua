---@class NGUIText : System.Object
---@field public bitmapFont UIFont @static
---@field public dynamicFont UnityEngine.Font @static
---@field public glyph NGUIText.GlyphInfo @static
---@field public fontSize number @static
---@field public fontScale number @static
---@field public pixelDensity number @static
---@field public fontStyle UnityEngine.FontStyle @static
---@field public alignment NGUIText.Alignment @static
---@field public tint UnityEngine.Color @static
---@field public rectWidth number @static
---@field public rectHeight number @static
---@field public regionWidth number @static
---@field public regionHeight number @static
---@field public maxLines number @static
---@field public gradient boolean @static
---@field public gradientBottom UnityEngine.Color @static
---@field public gradientTop UnityEngine.Color @static
---@field public encoding boolean @static
---@field public spacingX number @static
---@field public spacingY number @static
---@field public premultiply boolean @static
---@field public symbolStyle NGUIText.SymbolStyle @static
---@field public finalSize number @static
---@field public finalSpacingX number @static
---@field public finalLineHeight number @static
---@field public baseline number @static
---@field public useSymbols boolean @static
local m = {}

---@overload fun(request:boolean) @static
---@static
function m.Update() end

---@static
---@param text string
function m.Prepare(text) end

---@static
---@param text string
---@param index number
---@param textLength number
---@return BMSymbol
function m.GetSymbol(text, index, textLength) end

---@static
---@param ch number
---@param prev number
---@return number
function m.GetGlyphWidth(ch, prev) end

---@static
---@param ch number
---@param prev number
---@return NGUIText.GlyphInfo
function m.GetGlyph(ch, prev) end

---@static
---@param text string
---@param index number
---@return number
function m.ParseAlpha(text, index) end

---@overload fun(text:string):UnityEngine.Color @static
---@static
---@param text string
---@param offset number
---@return UnityEngine.Color
function m.ParseColor(text, offset) end

---@overload fun(text:string):UnityEngine.Color @static
---@static
---@param text string
---@param offset number
---@return UnityEngine.Color
function m.ParseColor24(text, offset) end

---@static
---@param text string
---@param offset number
---@return UnityEngine.Color
function m.ParseColor32(text, offset) end

---@overload fun(text:string, c:UnityEngine.Color):string @static
---@static
---@param c UnityEngine.Color
---@return string
function m.EncodeColor(c) end

---@static
---@param a number
---@return string
function m.EncodeAlpha(a) end

---@static
---@param c UnityEngine.Color
---@return string
function m.EncodeColor24(c) end

---@static
---@param c UnityEngine.Color
---@return string
function m.EncodeColor32(c) end

---@overload fun(text:string, index:System.Int32, colors:BetterList_1_UnityEngine_Color_, premultiply:boolean, sub:System.Int32, bold:System.Boolean, italic:System.Boolean, underline:System.Boolean, strike:System.Boolean, ignoreColor:System.Boolean):boolean, System.Int32, System.Int32, System.Boolean, System.Boolean, System.Boolean, System.Boolean, System.Boolean @static
---@static
---@param text string
---@param index System.Int32
---@return boolean, System.Int32
function m.ParseSymbol(text, index) end

---@static
---@param ch number
---@return boolean
function m.IsHex(ch) end

---@static
---@param text string
---@return string
function m.StripSymbols(text) end

---@overload fun(verts:BetterList_1_UnityEngine_Vector3_, indexOffset:number, printedWidth:number) @static
---@static
---@param verts BetterList_1_UnityEngine_Vector3_
---@param indexOffset number
---@param printedWidth number
---@param elements number
function m.Align(verts, indexOffset, printedWidth, elements) end

---@static
---@param verts BetterList_1_UnityEngine_Vector3_
---@param indices BetterList_1_System_Int32_
---@param pos UnityEngine.Vector2
---@return number
function m.GetExactCharacterIndex(verts, indices, pos) end

---@static
---@param verts BetterList_1_UnityEngine_Vector3_
---@param indices BetterList_1_System_Int32_
---@param pos UnityEngine.Vector2
---@return number
function m.GetApproximateCharacterIndex(verts, indices, pos) end

---@static
---@param s System.Text.StringBuilder
---@return System.Text.StringBuilder
function m.EndLine(s) end

---@static
---@param text string
---@return UnityEngine.Vector2
function m.CalculatePrintedSize(text) end

---@static
---@param text string
---@return number
function m.CalculateOffsetToFit(text) end

---@static
---@param text string
---@return string
function m.GetEndOfLineThatFits(text) end

---@overload fun(text:string):boolean, System.String @static
---@overload fun(text:string, keepCharCount:boolean, wrapLineColors:boolean, useEllipsis:boolean):boolean, System.String @static
---@overload fun(text:string, keepCharCount:boolean, wrapLineColors:boolean):boolean, System.String @static
---@static
---@param text string
---@param wrapLineColors boolean
---@return boolean, System.String
function m.WrapText(text, wrapLineColors) end

---@static
---@param text string
---@param verts BetterList_1_UnityEngine_Vector3_
---@param uvs BetterList_1_UnityEngine_Vector2_
---@param cols BetterList_1_UnityEngine_Color32_
function m.Print(text, verts, uvs, cols) end

---@static
---@param text string
---@param verts BetterList_1_UnityEngine_Vector3_
---@param indices BetterList_1_System_Int32_
function m.PrintApproximateCharacterPositions(text, verts, indices) end

---@static
---@param text string
---@param verts BetterList_1_UnityEngine_Vector3_
---@param indices BetterList_1_System_Int32_
function m.PrintExactCharacterPositions(text, verts, indices) end

---@static
---@param text string
---@param start number
---@param end number
---@param caret BetterList_1_UnityEngine_Vector3_
---@param highlight BetterList_1_UnityEngine_Vector3_
function m.PrintCaretAndSelection(text, start, end, caret, highlight) end

---@static
---@param text System.String
---@param index System.Int32
---@param prefix string
---@return boolean, System.String, System.Int32
function m.ReplaceLink(text, index, prefix) end

---@static
---@param text System.String
---@param index System.Int32
---@param keyword string
---@param link string
---@return boolean, System.String, System.Int32
function m.InsertHyperlink(text, index, keyword, link) end

---@static
---@param text System.String
---@return System.String
function m.ReplaceLinks(text) end

NGUIText = m
return m
