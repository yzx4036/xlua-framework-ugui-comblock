---@class LowMaterials : UnityEngine.MonoBehaviour
---@field public LowMaterialName string
local m = {}

LowMaterials = m
return m
