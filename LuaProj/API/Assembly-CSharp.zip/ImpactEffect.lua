---@class ImpactEffect : UnityEngine.MonoBehaviour
local m = {}

ImpactEffect = m
return m
