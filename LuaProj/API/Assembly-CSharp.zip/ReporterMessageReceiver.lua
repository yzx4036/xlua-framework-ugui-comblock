---@class ReporterMessageReceiver : UnityEngine.MonoBehaviour
local m = {}

ReporterMessageReceiver = m
return m
