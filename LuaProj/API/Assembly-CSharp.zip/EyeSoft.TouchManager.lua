---@class EyeSoft.TouchManager : Singleton_1_EyeSoft_TouchManager_
---@field public _allLayers table<number, EyeSoft.LayerInfo>
---@field public Item EyeSoft.LayerInfo
local m = {}

---@virtual
function m:Init() end

---@virtual
function m:Dispose() end

---@param enable boolean
function m:SetEasyTouch(enable) end

function m:Clear() end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnTap(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnDoubleTap(gt) end

---@param type number
---@param gt HedgehogTeam.EasyTouch.Gesture
function m:GuideEvent(type, gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnTouchStart(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnTouchEnd(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnSwipeBegin(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnSwipe(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnSwipeEnd(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnDragBegin(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnDrag(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnDragEnd(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnPinchBegin(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnPinchIn(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnPinchOut(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnPinchEnd(gt) end

---@param gt HedgehogTeam.EasyTouch.Gesture
function m:OnUIElimentTouchUp(gt) end

---@param layer number
---@param type number
---@param call fun(gt:HedgehogTeam.EasyTouch.Gesture):boolean
function m:AddEvent(layer, type, call) end

---@param layer number
---@param type number
---@param call fun(gt:HedgehogTeam.EasyTouch.Gesture):boolean
function m:RemoveEvent(layer, type, call) end

---@param layer EyeSoft.LayerInfo
function m:AddLayer(layer) end

---@overload fun(key:number)
---@param layer EyeSoft.LayerInfo
function m:RemoveLayer(layer) end

---@static
---@return boolean
function m.IsPointerOverUIObject() end

EyeSoft.TouchManager = m
return m
