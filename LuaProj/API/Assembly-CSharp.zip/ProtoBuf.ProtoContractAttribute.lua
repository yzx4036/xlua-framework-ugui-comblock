---@class ProtoBuf.ProtoContractAttribute : System.Attribute
---@field public Name string
---@field public ImplicitFirstTag number
---@field public UseProtoMembersOnly boolean
---@field public IgnoreListHandling boolean
---@field public ImplicitFields ProtoBuf.ImplicitFields
---@field public InferTagFromName boolean
---@field public DataMemberOffset number
---@field public SkipConstructor boolean
---@field public AsReferenceDefault boolean
---@field public EnumPassthru boolean
local m = {}

ProtoBuf.ProtoContractAttribute = m
return m
