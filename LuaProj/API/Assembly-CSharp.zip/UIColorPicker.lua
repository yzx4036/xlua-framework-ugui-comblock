---@class UIColorPicker : UnityEngine.MonoBehaviour
---@field public current UIColorPicker @static
---@field public value UnityEngine.Color
---@field public selectionWidget UIWidget
---@field public onChange EventDelegate[]
local m = {}

---@overload fun(c:UnityEngine.Color):UnityEngine.Vector2
---@param v UnityEngine.Vector2
function m:Select(v) end

---@static
---@param x number
---@param y number
---@return UnityEngine.Color
function m.Sample(x, y) end

UIColorPicker = m
return m
