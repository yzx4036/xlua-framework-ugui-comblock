---@class UIWrapContent : UnityEngine.MonoBehaviour
---@field public itemSize number
---@field public cullContent boolean
---@field public minIndex number
---@field public maxIndex number
---@field public hideInactive boolean
---@field public onInitializeItem fun(go:UnityEngine.GameObject, wrapIndex:number, realIndex:number)
local m = {}

---@virtual
function m:SortBasedOnScrollMovement() end

---@virtual
function m:SortAlphabetically() end

function m:UpdateChildData() end

---@virtual
function m:WrapContent() end

UIWrapContent = m
return m
