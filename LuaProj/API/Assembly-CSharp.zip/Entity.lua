---@class Entity : System.Object
---@field public id number
---@field public deleteFlag boolean
---@field public deadFlag boolean
---@field public m_sceneModel SceneModel
---@field public effmanager EffectManager
---@field public isDisposed boolean
---@field public rotationSpeed number
---@field public name string
---@field public Position UnityEngine.Vector3
---@field public Rotation UnityEngine.Quaternion
---@field public Scale UnityEngine.Vector3
---@field public scaleZ number
---@field public Layer number
---@field public Visible boolean
---@field public NeedLerpRotation boolean
---@field public RotationSpeed number
local m = {}

---@param value number
function m:SetDirect(value) end

---@virtual
---@param _dt number
function m:Update(_dt) end

---@virtual
function m:Release() end

---@overload fun(position:UnityEngine.Vector3, isRotaY:boolean, needLerp:boolean)
---@overload fun(position:UnityEngine.Vector3, isRotaY:boolean)
---@param other Entity
---@param isRotaY boolean
function m:FaceTo(other, isRotaY) end

---@param translat UnityEngine.Vector3
function m:Translate(translat) end

Entity = m
return m
