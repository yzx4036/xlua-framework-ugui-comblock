---@class SkEffForward : SkEffBase
local m = {}

SkEffForward = m
return m
