---@class EnumHurtMoveType : System.Enum
---@field public JT_BACK EnumHurtMoveType @static
---@field public JF EnumHurtMoveType @static
---@field public value__ number
local m = {}

EnumHurtMoveType = m
return m
