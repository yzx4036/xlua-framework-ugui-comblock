---@class EyeSoft.ConstLayer : System.Object
---@field public sDefault string @static
---@field public sCamera string @static
---@field public sAttacker string @static
---@field public sUI string @static
---@field public sUI_MAIN string @static
---@field public sUI_POPUP string @static
---@field public sUI_HUD string @static
---@field public sUI_GUIDE string @static
---@field public sFloor string @static
---@field public sFloorLight string @static
---@field public sRenderTexture string @static
---@field public sJiaose string @static
---@field public sGeneral string @static
---@field public sWater string @static
---@field public Default number @static
---@field public Camera number @static
---@field public Attacker number @static
---@field public General number @static
---@field public UI number @static
---@field public UI_MAIN number @static
---@field public UI_POPUP number @static
---@field public UI_HUD number @static
---@field public UI_GUIDE number @static
---@field public Floor number @static
---@field public FloorLight number @static
---@field public RenderTexture number @static
---@field public FxLayer number @static
---@field public WaterLayer number @static
---@field public EasyTouch number @static
---@field public UICameraMask number @static
local m = {}

---@static
---@return number
function m.GetUIMask() end

---@static
---@return number
function m.GetMainMask() end

---@static
---@return number
function m.GetHudMask() end

---@static
---@return number
function m.GetPopUpMask() end

EyeSoft.ConstLayer = m
return m
