---@class XLua.LuaException : System.Exception
local m = {}

XLua.LuaException = m
return m
