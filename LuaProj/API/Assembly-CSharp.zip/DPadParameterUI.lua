---@class DPadParameterUI : UnityEngine.MonoBehaviour
local m = {}

---@param value boolean
function m:SetClassicalInertia(value) end

---@param value boolean
function m:SetTimePushInertia(value) end

function m:SetClassicalTwoAxesCount() end

function m:SetClassicalFourAxesCount() end

function m:SetTimePushTwoAxesCount() end

function m:SetTimePushFourAxesCount() end

DPadParameterUI = m
return m
