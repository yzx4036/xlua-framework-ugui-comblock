---@class ProtoBuf.ProtoAfterDeserializationAttribute : System.Attribute
local m = {}

ProtoBuf.ProtoAfterDeserializationAttribute = m
return m
