---@class SkEffWang : SkEffBase
local m = {}

SkEffWang = m
return m
