---@class ClipBoard : System.Object
local m = {}

---@overload fun(format:string) @static
---@static
---@param format string
---@param args any[]|any
function m.Copy(format, args) end

ClipBoard = m
return m
