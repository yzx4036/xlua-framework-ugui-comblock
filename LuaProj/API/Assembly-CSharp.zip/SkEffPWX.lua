---@class SkEffPWX : SkEffBase
local m = {}

SkEffPWX = m
return m
