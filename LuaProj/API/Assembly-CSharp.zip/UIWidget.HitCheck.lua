---@class UIWidget.HitCheck : System.MulticastDelegate
local m = {}

---@virtual
---@param worldPos UnityEngine.Vector3
---@return boolean
function m:Invoke(worldPos) end

---@virtual
---@param worldPos UnityEngine.Vector3
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(worldPos, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return boolean
function m:EndInvoke(result) end

UIWidget.HitCheck = m
return m
