---@class MutliFingersScreenTouch : UnityEngine.MonoBehaviour
---@field public touchGameObject UnityEngine.GameObject
local m = {}

MutliFingersScreenTouch = m
return m
