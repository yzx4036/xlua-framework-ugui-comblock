---@class DeadUtil : PureSingleton_1_DeadUtil_
local m = {}

---@param type EnumFightDeathType
---@param way number
---@param bu BattleUnit
function m:PlayDie(type, way, bu) end

DeadUtil = m
return m
