---@class SQLite4Unity3d.UniqueAttribute : SQLite4Unity3d.IndexedAttribute
---@field public Unique boolean
local m = {}

SQLite4Unity3d.UniqueAttribute = m
return m
