---@class XLua.CSObjectWrap.UnityEngineEventsUnityEventWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineEventsUnityEventWrap = m
return m
