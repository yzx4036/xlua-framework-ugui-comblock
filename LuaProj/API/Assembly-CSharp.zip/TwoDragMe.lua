---@class TwoDragMe : UnityEngine.MonoBehaviour
local m = {}

TwoDragMe = m
return m
