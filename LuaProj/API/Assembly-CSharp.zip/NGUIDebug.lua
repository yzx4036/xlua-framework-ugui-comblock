---@class NGUIDebug : UnityEngine.MonoBehaviour
---@field public debugRaycast boolean @static
local m = {}

---@static
function m.CreateInstance() end

---@overload fun() @static
---@overload fun(s:string) @static
---@static
---@param objs any[]|any
function m.Log(objs) end

---@static
function m.Clear() end

---@static
---@param b UnityEngine.Bounds
function m.DrawBounds(b) end

NGUIDebug = m
return m
