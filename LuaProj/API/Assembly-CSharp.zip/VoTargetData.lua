---@class VoTargetData : System.Object
---@field public id number
---@field public attackStatus number
---@field public attackHurt number
---@field public hp number
---@field public angry number
---@field public isDirectHurt number
---@field public moveData VoTargetMoveData
---@field public reboundDamage number
---@field public xisouHp number
local m = {}

VoTargetData = m
return m
