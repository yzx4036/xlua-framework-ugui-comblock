---@class LoadRandonNpc : UnityEngine.MonoBehaviour
---@field public IsLowDontLoad boolean
---@field public Delay number
---@field public NpcList string[]
---@field public NeedPlayAni boolean
---@field public Loop boolean
---@field public actionEnum EnumAction
local m = {}

LoadRandonNpc = m
return m
