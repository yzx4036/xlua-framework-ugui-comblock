---@class Delay : UnityEngine.MonoBehaviour
---@field public delayTime number
local m = {}

---@param addTime number
function m:AddTime(addTime) end

Delay = m
return m
