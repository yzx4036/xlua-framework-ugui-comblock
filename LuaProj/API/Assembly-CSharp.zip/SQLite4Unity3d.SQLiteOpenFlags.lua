---@class SQLite4Unity3d.SQLiteOpenFlags : System.Enum
---@field public ReadOnly SQLite4Unity3d.SQLiteOpenFlags @static
---@field public ReadWrite SQLite4Unity3d.SQLiteOpenFlags @static
---@field public Create SQLite4Unity3d.SQLiteOpenFlags @static
---@field public NoMutex SQLite4Unity3d.SQLiteOpenFlags @static
---@field public FullMutex SQLite4Unity3d.SQLiteOpenFlags @static
---@field public SharedCache SQLite4Unity3d.SQLiteOpenFlags @static
---@field public PrivateCache SQLite4Unity3d.SQLiteOpenFlags @static
---@field public ProtectionComplete SQLite4Unity3d.SQLiteOpenFlags @static
---@field public ProtectionCompleteUnlessOpen SQLite4Unity3d.SQLiteOpenFlags @static
---@field public ProtectionCompleteUntilFirstUserAuthentication SQLite4Unity3d.SQLiteOpenFlags @static
---@field public ProtectionNone SQLite4Unity3d.SQLiteOpenFlags @static
---@field public value__ number
local m = {}

SQLite4Unity3d.SQLiteOpenFlags = m
return m
