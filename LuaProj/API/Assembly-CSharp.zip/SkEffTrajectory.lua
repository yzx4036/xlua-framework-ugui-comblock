---@class SkEffTrajectory : SkEffBase
local m = {}

SkEffTrajectory = m
return m
