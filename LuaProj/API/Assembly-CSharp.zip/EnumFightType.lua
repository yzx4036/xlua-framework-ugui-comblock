---@class EnumFightType : System.Enum
---@field public PLOT EnumFightType @static
---@field public PLOT_GZ EnumFightType @static
---@field public value__ number
local m = {}

EnumFightType = m
return m
