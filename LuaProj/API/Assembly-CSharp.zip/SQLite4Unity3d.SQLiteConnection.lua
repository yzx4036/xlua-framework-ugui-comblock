---@class SQLite4Unity3d.SQLiteConnection : System.Object
---@field public Handle System.IntPtr
---@field public DatabasePath string
---@field public Trace boolean
---@field public TimeExecution boolean
---@field public StoreDateTimeAsTicks boolean
---@field public SyncObject any
---@field public BusyTimeout System.TimeSpan
---@field public TableMappings System.Collections.Generic.IEnumerable_1_SQLite4Unity3d_TableMapping_
---@field public IsInTransaction boolean
local m = {}

---@param value fun(message:string)
function m:add_TraceEvent(value) end

---@param value fun(message:string)
function m:remove_TraceEvent(value) end

---@param value fun(executionTime:System.TimeSpan, totalExecutionTime:System.TimeSpan)
function m:add_TimeExecutionEvent(value) end

---@param value fun(executionTime:System.TimeSpan, totalExecutionTime:System.TimeSpan)
function m:remove_TimeExecutionEvent(value) end

function m:Open() end

---@param onoff number
function m:EnableLoadExtension(onoff) end

---@overload fun(type:System.Type):SQLite4Unity3d.TableMapping
---@overload fun():SQLite4Unity3d.TableMapping
---@param type System.Type
---@param createFlags SQLite4Unity3d.CreateFlags
---@return SQLite4Unity3d.TableMapping
function m:GetMapping(type, createFlags) end

---@return number
function m:DropTable() end

---@overload fun():number
---@overload fun(ty:System.Type, createFlags:SQLite4Unity3d.CreateFlags):number
---@overload fun(ty:System.Type):number
---@param createFlags SQLite4Unity3d.CreateFlags
---@return number
function m:CreateTable(createFlags) end

---@overload fun(indexName:string, tableName:string, columnNames:string[]):number
---@overload fun(indexName:string, tableName:string, columnName:string, unique:boolean):number
---@overload fun(indexName:string, tableName:string, columnName:string):number
---@overload fun(tableName:string, columnName:string, unique:boolean):number
---@overload fun(tableName:string, columnName:string):number
---@overload fun(tableName:string, columnNames:string[], unique:boolean):number
---@overload fun(tableName:string, columnNames:string[]):number
---@overload fun(property:System.Linq.Expressions.LambdaExpression, unique:boolean)
---@overload fun(property:System.Linq.Expressions.LambdaExpression)
---@param indexName string
---@param tableName string
---@param columnNames string[]
---@param unique boolean
---@return number
function m:CreateIndex(indexName, tableName, columnNames, unique) end

---@param tableName string
---@return SQLite4Unity3d.SQLiteConnection.ColumnInfo[]
function m:GetTableInfo(tableName) end

---@overload fun(cmdText:string):SQLite4Unity3d.SQLiteCommand
---@param cmdText string
---@param ps any[]|any
---@return SQLite4Unity3d.SQLiteCommand
function m:CreateCommand(cmdText, ps) end

---@overload fun(query:string):number
---@param query string
---@param args any[]|any
---@return number
function m:Execute(query, args) end

---@overload fun(query:string):any
---@param query string
---@param args any[]|any
---@return any
function m:ExecuteScalar(query, args) end

---@overload fun(query:string):any[]
---@overload fun(map:SQLite4Unity3d.TableMapping, query:string, args:any[]|any):any[]
---@overload fun(map:SQLite4Unity3d.TableMapping, query:string):any[]
---@param query string
---@param args any[]|any
---@return any[]
function m:Query(query, args) end

---@overload fun(query:string):any
---@overload fun(map:SQLite4Unity3d.TableMapping, query:string, args:any[]|any):System.Collections.Generic.IEnumerable_1_System_Object_
---@overload fun(map:SQLite4Unity3d.TableMapping, query:string):System.Collections.Generic.IEnumerable_1_System_Object_
---@param query string
---@param args any[]|any
---@return any
function m:DeferredQuery(query, args) end

---@return SQLite4Unity3d.BaseTableQuery
function m:Table() end

---@overload fun(predicate:System.Linq.Expressions.LambdaExpression):any
---@param pk any
---@return any
function m:Get(pk) end

---@overload fun(pk:any, map:SQLite4Unity3d.TableMapping):any
---@overload fun(predicate:System.Linq.Expressions.LambdaExpression):any
---@param pk any
---@return any
function m:Find(pk) end

function m:BeginTransaction() end

---@return string
function m:SaveTransactionPoint() end

function m:Rollback() end

---@param savepoint string
function m:RollbackTo(savepoint) end

---@param savepoint string
function m:Release(savepoint) end

function m:Commit() end

---@param action fun()
function m:RunInTransaction(action) end

---@param action fun()
function m:RunInDatabaseLock(action) end

---@overload fun(objects:System.Collections.IEnumerable, extra:string):number
---@overload fun(objects:System.Collections.IEnumerable, objType:System.Type):number
---@param objects System.Collections.IEnumerable
---@return number
function m:InsertAll(objects) end

---@overload fun(obj:any, objType:System.Type):number
---@overload fun(obj:any, extra:string):number
---@overload fun(obj:any, extra:string, objType:System.Type):number
---@param obj any
---@return number
function m:Insert(obj) end

---@overload fun(obj:any, objType:System.Type):number
---@param obj any
---@return number
function m:InsertOrReplace(obj) end

---@overload fun(obj:any, objType:System.Type):number
---@param obj any
---@return number
function m:Update(obj) end

---@param objects System.Collections.IEnumerable
---@return number
function m:UpdateAll(objects) end

---@overload fun(primaryKey:any):number
---@param objectToDelete any
---@return number
function m:Delete(objectToDelete) end

---@return number
function m:DeleteAll() end

---@virtual
function m:Dispose() end

function m:Close() end

SQLite4Unity3d.SQLiteConnection = m
return m
