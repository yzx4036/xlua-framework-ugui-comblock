---@class EffectManager : System.Object
local m = {}

---@param model SceneModel
function m:Initalize(model) end

---@param faceway number
function m:UpdateFaceWay(faceway) end

---@param baseInfo EffectBaseInfo
---@param fromPoint UnityEngine.Vector3
function m:AddEffect(baseInfo, fromPoint) end

---@param path string
---@param bindpoint EnumBindPoint
function m:RemoveEffect(path, bindpoint) end

---@param time number
function m:Pause(time) end

---@param minusTime number
function m:Play(minusTime) end

---@param deltaTime number
function m:Update(deltaTime) end

function m:Release() end

EffectManager = m
return m
