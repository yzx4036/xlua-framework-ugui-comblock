---@class SpinWithMouse : UnityEngine.MonoBehaviour
---@field public target UnityEngine.Transform
---@field public speed number
local m = {}

SpinWithMouse = m
return m
