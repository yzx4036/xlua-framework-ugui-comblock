---@class SortingGroup : UnityEngine.MonoBehaviour
---@field public sortingLayer string
---@field public sortingOrder number
local m = {}

SortingGroup = m
return m
