---@class PathDirect : MagicInBattle
---@field public isDoHurt boolean
---@field public hasReach boolean
local m = {}

---@virtual
---@param _dt number
function m:Update(_dt) end

PathDirect = m
return m
