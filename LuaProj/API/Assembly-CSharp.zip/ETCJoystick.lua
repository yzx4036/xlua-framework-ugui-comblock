---@class ETCJoystick : ETCBase
---@field public onMoveStart ETCJoystick.OnMoveStartHandler
---@field public onMove ETCJoystick.OnMoveHandler
---@field public onMoveSpeed ETCJoystick.OnMoveSpeedHandler
---@field public onMoveEnd ETCJoystick.OnMoveEndHandler
---@field public onTouchStart ETCJoystick.OnTouchStartHandler
---@field public onTouchUp ETCJoystick.OnTouchUpHandler
---@field public OnDownUp ETCJoystick.OnDownUpHandler
---@field public OnDownDown ETCJoystick.OnDownDownHandler
---@field public OnDownLeft ETCJoystick.OnDownLeftHandler
---@field public OnDownRight ETCJoystick.OnDownRightHandler
---@field public OnPressUp ETCJoystick.OnDownUpHandler
---@field public OnPressDown ETCJoystick.OnDownDownHandler
---@field public OnPressLeft ETCJoystick.OnDownLeftHandler
---@field public OnPressRight ETCJoystick.OnDownRightHandler
---@field public joystickType ETCJoystick.JoystickType
---@field public allowJoystickOverTouchPad boolean
---@field public radiusBase ETCJoystick.RadiusBase
---@field public radiusBaseValue number
---@field public axisX ETCAxis
---@field public axisY ETCAxis
---@field public thumb UnityEngine.RectTransform
---@field public joystickArea ETCJoystick.JoystickArea
---@field public userArea UnityEngine.RectTransform
---@field public isTurnAndMove boolean
---@field public tmSpeed number
---@field public tmAdditionnalRotation number
---@field public tmMoveCurve UnityEngine.AnimationCurve
---@field public tmLockInJump boolean
---@field public IsNoReturnThumb boolean
---@field public IsNoOffsetThumb boolean
local m = {}

---@virtual
function m:Start() end

---@virtual
function m:Update() end

---@virtual
function m:LateUpdate() end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerEnter(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerDown(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnBeginDrag(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnDrag(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerUp(eventData) end

---@return number
function m:GetRadius() end

function m:InitCurve() end

function m:InitTurnMoveCurve() end

ETCJoystick = m
return m
