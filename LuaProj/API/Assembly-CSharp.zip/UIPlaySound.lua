---@class UIPlaySound : UnityEngine.MonoBehaviour
---@field public audioClip UnityEngine.AudioClip
---@field public trigger UIPlaySound.Trigger
---@field public volume number
---@field public pitch number
local m = {}

function m:Play() end

UIPlaySound = m
return m
