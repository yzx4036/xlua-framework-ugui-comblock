---@class CharacterAnimationDungeon : UnityEngine.MonoBehaviour
local m = {}

CharacterAnimationDungeon = m
return m
