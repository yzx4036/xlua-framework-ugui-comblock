---@class Messenger : System.Object
---@field public eventTable table<number, fun(args:any[]):any> @static
---@field public permanentMessages number[] @static
local m = {}

---@static
---@param eventType number
function m.MarkAsPermanent(eventType) end

---@static
function m.Cleanup() end

---@static
function m.PrintEventTable() end

---@static
---@param eventType number
---@param listenerBeingAdded fun(args:any[]):any
function m.OnListenerAdding(eventType, listenerBeingAdded) end

---@static
---@param eventType number
---@param listenerBeingRemoved fun(args:any[]):any
function m.OnListenerRemoving(eventType, listenerBeingRemoved) end

---@static
---@param eventType number
function m.OnListenerRemoved(eventType) end

---@static
---@param eventType number
function m.RemovedUIMgrOnBroad(eventType) end

---@static
---@param eventType number
function m.OnBroadcasting(eventType) end

---@static
---@param eventType number
---@return Messenger.BroadcastException
function m.CreateBroadcastSignatureException(eventType) end

---@overload fun(eventType:number, handler:(fun(arg1:any))) @static
---@overload fun(eventType:number, handler:(fun(arg1:any, arg2:any))) @static
---@overload fun(eventType:number, handler:(fun(arg1:any, arg2:any, arg3:any))) @static
---@static
---@param eventType number
---@param handler fun()
function m.AddListener(eventType, handler) end

---@overload fun(eventType:number, handler:(fun(arg1:any))) @static
---@overload fun(eventType:number, handler:(fun(arg1:any, arg2:any))) @static
---@overload fun(eventType:number, handler:(fun(arg1:any, arg2:any, arg3:any))) @static
---@static
---@param eventType number
---@param handler fun()
function m.RemoveListener(eventType, handler) end

---@overload fun(eventType:number, arg1:any) @static
---@overload fun(eventType:number, arg1:any, arg2:any) @static
---@overload fun(eventType:number, arg1:any, arg2:any, arg3:any) @static
---@static
---@param eventType number
function m.Broadcast(eventType) end

Messenger = m
return m
