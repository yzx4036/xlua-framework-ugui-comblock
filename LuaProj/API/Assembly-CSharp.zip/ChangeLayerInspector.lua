---@class ChangeLayerInspector : UnityEditor.Editor
local m = {}

---@virtual
function m:OnInspectorGUI() end

---@param t UnityEngine.Transform
---@param layer number
function m:SetChildLayer(t, layer) end

ChangeLayerInspector = m
return m
