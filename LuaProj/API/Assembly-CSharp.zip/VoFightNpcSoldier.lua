---@class VoFightNpcSoldier : VoFightObj
local m = {}

VoFightNpcSoldier = m
return m
