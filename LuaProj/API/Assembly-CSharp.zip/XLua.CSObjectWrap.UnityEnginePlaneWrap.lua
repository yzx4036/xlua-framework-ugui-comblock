---@class XLua.CSObjectWrap.UnityEnginePlaneWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEnginePlaneWrap = m
return m
