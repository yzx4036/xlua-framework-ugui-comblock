---@class UISnapshotPoint : UnityEngine.MonoBehaviour
---@field public isOrthographic boolean
---@field public nearClip number
---@field public farClip number
---@field public fieldOfView number
---@field public orthoSize number
---@field public thumbnail UnityEngine.Texture2D
local m = {}

UISnapshotPoint = m
return m
