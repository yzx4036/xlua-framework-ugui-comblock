---@class AssetBundles.ResourceAsyncOperation : System.Object
---@field public Current any
---@field public isDone boolean
---@field public progress number
local m = {}

---@abstract
function m:Update() end

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Reset() end

---@abstract
---@return boolean
function m:IsDone() end

---@abstract
---@return number
function m:Progress() end

---@virtual
function m:Dispose() end

AssetBundles.ResourceAsyncOperation = m
return m
