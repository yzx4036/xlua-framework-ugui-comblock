---@class GDTimer : System.Object
---@field public Instance GDTimer @static
local m = {}

---@overload fun(_delay:number, loopCount:number, trigger:(fun(id:number, obj:any))):number
---@overload fun(_delay:number, loopCount:number, trigger:(fun(id:number, obj:any)), obj:any):number
---@overload fun(_delay:number, loopCount:number, trigger:(fun(id:number, obj:any))):number
---@param _delay number
---@param loopCount number
---@param trigger fun(id:number, obj:any)
---@param obj any
---@return number
function m:AddTimer(_delay, loopCount, trigger, obj) end

---@param id number
---@return boolean
function m:RemoveTimer(id) end

---@param id number
---@param addTime number
function m:UpdateTimer(id, addTime) end

function m:Update() end

GDTimer = m
return m
