---@class VoTargetMoveData : System.Object
---@field public moveType number
---@field public movePosX number
---@field public movePosY number
local m = {}

VoTargetMoveData = m
return m
