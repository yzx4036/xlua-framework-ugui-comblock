---@class UICamera.ControlScheme : System.Enum
---@field public Mouse UICamera.ControlScheme @static
---@field public Touch UICamera.ControlScheme @static
---@field public Controller UICamera.ControlScheme @static
---@field public value__ number
local m = {}

UICamera.ControlScheme = m
return m
