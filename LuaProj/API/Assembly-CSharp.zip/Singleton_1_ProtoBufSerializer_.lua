---@class Singleton_1_ProtoBufSerializer_ : System.Object
---@field public instance ProtoBufSerializer @static
local m = {}

---@static
function m.Release() end

---@virtual
function m:Init() end

---@abstract
function m:Dispose() end

Singleton_1_ProtoBufSerializer_ = m
return m
