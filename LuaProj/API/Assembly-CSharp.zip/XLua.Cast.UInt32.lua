---@class XLua.Cast.UInt32 : XLua.Cast.Any_1_System_UInt32_
local m = {}

XLua.Cast.UInt32 = m
return m
