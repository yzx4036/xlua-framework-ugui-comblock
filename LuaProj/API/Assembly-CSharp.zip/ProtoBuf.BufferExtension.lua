---@class ProtoBuf.BufferExtension : System.Object
local m = {}

ProtoBuf.BufferExtension = m
return m
