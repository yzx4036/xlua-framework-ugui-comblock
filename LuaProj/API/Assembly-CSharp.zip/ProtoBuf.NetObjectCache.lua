---@class ProtoBuf.NetObjectCache : System.Object
local m = {}

ProtoBuf.NetObjectCache = m
return m
