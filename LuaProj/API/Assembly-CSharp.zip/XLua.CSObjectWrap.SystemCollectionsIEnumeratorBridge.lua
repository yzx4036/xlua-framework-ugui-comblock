---@class XLua.CSObjectWrap.SystemCollectionsIEnumeratorBridge : XLua.LuaBase
---@field public Current any
local m = {}

---@static
---@param reference number
---@param luaenv XLua.LuaEnv
---@return XLua.LuaBase
function m.__Create(reference, luaenv) end

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Reset() end

XLua.CSObjectWrap.SystemCollectionsIEnumeratorBridge = m
return m
