---@class FightPlotManager : PureSingleton_1_FightPlotManager_
local m = {}

function m:DealLoadScene() end

---@param guideId number
function m:DealFightPrePlot(guideId) end

function m:DealUIGuideCallback() end

---@param plotId number
function m:DealPlot(plotId) end

FightPlotManager = m
return m
