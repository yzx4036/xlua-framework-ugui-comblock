---@class HttpInfo : System.Object
---@field public url string
---@field public type HTTP_TYPE
---@field public formData System.Collections.Generic.Dictionary_2_System_String_System_String_
---@field public byteData string
---@field public timeOut number
---@field public callbackDel fun(obj:UnityEngine.WWW)
local m = {}

HttpInfo = m
return m
