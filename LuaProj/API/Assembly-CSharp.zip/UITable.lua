---@class UITable : UIWidgetContainer
---@field public columns number
---@field public direction UITable.Direction
---@field public sorting UITable.Sorting
---@field public pivot UIWidget.Pivot
---@field public cellAlignment UIWidget.Pivot
---@field public hideInactive boolean
---@field public keepWithinPanel boolean
---@field public padding UnityEngine.Vector2
---@field public onReposition fun()
---@field public onCustomSort fun(x:UnityEngine.Transform, y:UnityEngine.Transform):number
---@field public repositionNow boolean
local m = {}

---@return UnityEngine.Transform[]
function m:GetChildList() end

---@virtual
function m:Reposition() end

UITable = m
return m
