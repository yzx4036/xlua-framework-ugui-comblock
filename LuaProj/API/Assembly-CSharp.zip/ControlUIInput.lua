---@class ControlUIInput : UnityEngine.MonoBehaviour
---@field public getAxisText UnityEngine.UI.Text
---@field public getAxisSpeedText UnityEngine.UI.Text
---@field public getAxisYText UnityEngine.UI.Text
---@field public getAxisYSpeedText UnityEngine.UI.Text
---@field public downRightText UnityEngine.UI.Text
---@field public downDownText UnityEngine.UI.Text
---@field public downLeftText UnityEngine.UI.Text
---@field public downUpText UnityEngine.UI.Text
---@field public rightText UnityEngine.UI.Text
---@field public downText UnityEngine.UI.Text
---@field public leftText UnityEngine.UI.Text
---@field public upText UnityEngine.UI.Text
local m = {}

ControlUIInput = m
return m
