---@class FingerTouch : UnityEngine.MonoBehaviour
---@field public deltaPosition UnityEngine.Vector3
---@field public fingerId number
local m = {}

---@param ind number
function m:InitTouch(ind) end

FingerTouch = m
return m
