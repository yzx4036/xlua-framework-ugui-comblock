---@class ProtoBuf.SubItemToken : System.ValueType
local m = {}

ProtoBuf.SubItemToken = m
return m
