---@class VoFightObj : System.Object
---@field public id number
---@field public sysId number
---@field public type EnumFightObjType
---@field public isNpc boolean
---@field public name string
---@field public direct EnumFightDirect
---@field public bingzhongType BingZhongType
---@field public horseBody string
---@field public body string
---@field public weapon string
---@field public isJinXiangWepongEff boolean
---@field public speed number
---@field public battleUnit BattleUnit
---@field public xOff number
---@field public yOff number
---@field public scale number
---@field public moveRate number
---@field public moveRate_heng number
---@field public shadowWid number
---@field public entranceWay EnumEntranceType
---@field public order number
---@field public country number
---@field public terrainAdd number
---@field public terrainMinus number
---@field public zhwType number
---@field public isZhengLastDie boolean
---@field public modelType EnumSceneModelType
---@field public hpMax number
---@field public hp number
---@field public angry number
---@field public IsDie boolean
local m = {}

---@param value number
---@param deathType EnumFightDeathType
---@param isDisHpUpdate boolean
function m:setHp(value, deathType, isDisHpUpdate) end

---@param value EnumFightDirect
function m:resetDirect(value) end

VoFightObj = m
return m
