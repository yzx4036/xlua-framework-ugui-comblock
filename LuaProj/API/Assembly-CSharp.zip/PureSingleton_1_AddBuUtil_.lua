---@class PureSingleton_1_AddBuUtil_ : System.Object
---@field public Instance AddBuUtil @static
local m = {}

PureSingleton_1_AddBuUtil_ = m
return m
