---@class CreateDBScript : UnityEngine.MonoBehaviour
---@field public DebugText UnityEngine.UI.Text
local m = {}

CreateDBScript = m
return m
