---@class MeleeWeaponTrail : UnityEngine.MonoBehaviour
---@field public Emit boolean
---@field public Use boolean
local m = {}

MeleeWeaponTrail = m
return m
