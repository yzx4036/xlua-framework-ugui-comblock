---@class FlyNormal : FlyWordBase
local m = {}

---@virtual
---@param res string
---@param num number
function m:Init(res, num) end

FlyNormal = m
return m
