---@class SortingLayerAttribute : UnityEngine.PropertyAttribute
local m = {}

SortingLayerAttribute = m
return m
