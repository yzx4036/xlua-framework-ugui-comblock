---@class UIInput.OnReturnKey : System.Enum
---@field public Default UIInput.OnReturnKey @static
---@field public Submit UIInput.OnReturnKey @static
---@field public NewLine UIInput.OnReturnKey @static
---@field public value__ number
local m = {}

UIInput.OnReturnKey = m
return m
