---@class TweenOrthoSize : UITweener
---@field public from number
---@field public to number
---@field public cachedCamera UnityEngine.Camera
---@field public orthoSize number
---@field public value number
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param to number
---@return TweenOrthoSize
function m.Begin(go, duration, to) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenOrthoSize = m
return m
