---@class EnumBuffAttribute : System.Enum
---@field public NONE EnumBuffAttribute @static
---@field public FROST EnumBuffAttribute @static
---@field public STONE EnumBuffAttribute @static
---@field public FIRE EnumBuffAttribute @static
---@field public Invincible EnumBuffAttribute @static
---@field public MIAN_YI EnumBuffAttribute @static
---@field public SHUI_PAO EnumBuffAttribute @static
---@field public WU_XING EnumBuffAttribute @static
---@field public ZHONG_DU EnumBuffAttribute @static
---@field public value__ number
local m = {}

EnumBuffAttribute = m
return m
