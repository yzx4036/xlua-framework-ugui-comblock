---@class UIPanel : UIRect
---@field public list UIPanel[] @static
---@field public nextUnusedDepth number @static
---@field public onGeometryUpdated fun()
---@field public showInPanelTool boolean
---@field public generateNormals boolean
---@field public widgetsAreStatic boolean
---@field public cullWhileDragging boolean
---@field public alwaysOnScreen boolean
---@field public anchorOffset boolean
---@field public softBorderPadding boolean
---@field public renderQueue UIPanel.RenderQueue
---@field public startingRenderQueue number
---@field public widgets UIWidget[]
---@field public drawCalls UIDrawCall[]
---@field public worldToLocal UnityEngine.Matrix4x4
---@field public drawCallClipRange UnityEngine.Vector4
---@field public onClipMove fun(panel:UIPanel)
---@field public sortingLayerName string
---@field public canBeAnchored boolean
---@field public alpha number
---@field public depth number
---@field public sortingOrder number
---@field public width number
---@field public height number
---@field public halfPixelOffset boolean
---@field public usedForUI boolean
---@field public drawCallOffset UnityEngine.Vector3
---@field public clipping UIDrawCall.Clipping
---@field public parentPanel UIPanel
---@field public clipCount number
---@field public hasClipping boolean
---@field public hasCumulativeClipping boolean
---@field public clipsChildren boolean
---@field public clipOffset UnityEngine.Vector2
---@field public clipTexture UnityEngine.Texture2D
---@field public clipRange UnityEngine.Vector4
---@field public baseClipRegion UnityEngine.Vector4
---@field public finalClipRegion UnityEngine.Vector4
---@field public clipSoftness UnityEngine.Vector2
---@field public localCorners UnityEngine.Vector3[]
---@field public worldCorners UnityEngine.Vector3[]
local m = {}

---@static
---@param a UIPanel
---@param b UIPanel
---@return number
function m.CompareFunc(a, b) end

---@virtual
---@param relativeTo UnityEngine.Transform
---@return UnityEngine.Vector3[]
function m:GetSides(relativeTo) end

---@virtual
---@param includeChildren boolean
function m:Invalidate(includeChildren) end

---@virtual
---@param frameID number
---@return number
function m:CalculateFinalAlpha(frameID) end

---@virtual
---@param x number
---@param y number
---@param width number
---@param height number
function m:SetRect(x, y, width, height) end

---@overload fun(worldPos:UnityEngine.Vector3):boolean
---@overload fun(w:UIWidget):boolean
---@param a UnityEngine.Vector3
---@param b UnityEngine.Vector3
---@param c UnityEngine.Vector3
---@param d UnityEngine.Vector3
---@return boolean
function m:IsVisible(a, b, c, d) end

---@param w UIWidget
---@return boolean
function m:Affects(w) end

function m:RebuildAllDrawCalls() end

function m:SetDirty() end

---@virtual
function m:ParentHasChanged() end

function m:SortWidgets() end

---@param dc UIDrawCall
---@return boolean
function m:FillDrawCall(dc) end

---@param w UIWidget
---@return UIDrawCall
function m:FindDrawCall(w) end

---@param w UIWidget
function m:AddWidget(w) end

---@param w UIWidget
function m:RemoveWidget(w) end

function m:Refresh() end

---@virtual
---@param min UnityEngine.Vector2
---@param max UnityEngine.Vector2
---@return UnityEngine.Vector3
function m:CalculateConstrainOffset(min, max) end

---@overload fun(target:UnityEngine.Transform, immediate:boolean):boolean
---@param target UnityEngine.Transform
---@param targetBounds UnityEngine.Bounds
---@param immediate boolean
---@return boolean, UnityEngine.Bounds
function m:ConstrainTargetToBounds(target, targetBounds, immediate) end

---@overload fun(trans:UnityEngine.Transform, createIfMissing:boolean):UIPanel @static
---@overload fun(trans:UnityEngine.Transform, createIfMissing:boolean, layer:number):UIPanel @static
---@static
---@param trans UnityEngine.Transform
---@return UIPanel
function m.Find(trans) end

---@return UnityEngine.Vector2
function m:GetWindowSize() end

---@return UnityEngine.Vector2
function m:GetViewSize() end

---@return UIWidget[]
function m:GetWidgets() end

UIPanel = m
return m
