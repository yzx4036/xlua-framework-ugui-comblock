---@class ControlUIEvent : UnityEngine.MonoBehaviour
---@field public moveStartText UnityEngine.UI.Text
---@field public moveText UnityEngine.UI.Text
---@field public moveSpeedText UnityEngine.UI.Text
---@field public moveEndText UnityEngine.UI.Text
---@field public touchStartText UnityEngine.UI.Text
---@field public touchUpText UnityEngine.UI.Text
---@field public downRightText UnityEngine.UI.Text
---@field public downDownText UnityEngine.UI.Text
---@field public downLeftText UnityEngine.UI.Text
---@field public downUpText UnityEngine.UI.Text
---@field public rightText UnityEngine.UI.Text
---@field public downText UnityEngine.UI.Text
---@field public leftText UnityEngine.UI.Text
---@field public upText UnityEngine.UI.Text
local m = {}

function m:MoveStart() end

---@param move UnityEngine.Vector2
function m:Move(move) end

---@param move UnityEngine.Vector2
function m:MoveSpeed(move) end

function m:MoveEnd() end

function m:TouchStart() end

function m:TouchUp() end

function m:DownRight() end

function m:DownDown() end

function m:DownLeft() end

function m:DownUp() end

function m:Right() end

function m:Down() end

function m:Left() end

function m:Up() end

ControlUIEvent = m
return m
