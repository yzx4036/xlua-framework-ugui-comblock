---@class UIButtonRotation : UnityEngine.MonoBehaviour
---@field public tweenTarget UnityEngine.Transform
---@field public hover UnityEngine.Vector3
---@field public pressed UnityEngine.Vector3
---@field public duration number
local m = {}

UIButtonRotation = m
return m
