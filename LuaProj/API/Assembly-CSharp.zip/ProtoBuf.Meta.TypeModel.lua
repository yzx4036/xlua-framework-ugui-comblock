---@class ProtoBuf.Meta.TypeModel : System.Object
---@field public netDataPoolDelegate fun(protoType:System.Type):any
---@field public bufferPoolDelegate fun(expectedSize:number):string
---@field public ForwardsOnly boolean
local m = {}

---@overload fun(dest:System.IO.Stream, value:any, context:ProtoBuf.SerializationContext)
---@overload fun(dest:ProtoBuf.ProtoWriter, value:any)
---@param dest System.IO.Stream
---@param value any
function m:Serialize(dest, value) end

---@overload fun(source:System.IO.Stream, value:any, type:System.Type, style:ProtoBuf.PrefixStyle, expectedField:number, resolver:(fun(fieldNumber:number):System.Type)):any
---@overload fun(source:System.IO.Stream, value:any, type:System.Type, style:ProtoBuf.PrefixStyle, expectedField:number, resolver:(fun(fieldNumber:number):System.Type)):any, System.Int32
---@param source System.IO.Stream
---@param value any
---@param type System.Type
---@param style ProtoBuf.PrefixStyle
---@param fieldNumber number
---@return any
function m:DeserializeWithLengthPrefix(source, value, type, style, fieldNumber) end

---@overload fun(source:System.IO.Stream, type:System.Type, style:ProtoBuf.PrefixStyle, expectedField:number, resolver:(fun(fieldNumber:number):System.Type), context:ProtoBuf.SerializationContext):System.Collections.IEnumerable
---@overload fun(source:System.IO.Stream, style:ProtoBuf.PrefixStyle, expectedField:number):any
---@overload fun(source:System.IO.Stream, style:ProtoBuf.PrefixStyle, expectedField:number, context:ProtoBuf.SerializationContext):any
---@param source System.IO.Stream
---@param type System.Type
---@param style ProtoBuf.PrefixStyle
---@param expectedField number
---@param resolver fun(fieldNumber:number):System.Type
---@return System.Collections.IEnumerable
function m:DeserializeItems(source, type, style, expectedField, resolver) end

---@overload fun(dest:System.IO.Stream, value:any, type:System.Type, style:ProtoBuf.PrefixStyle, fieldNumber:number, context:ProtoBuf.SerializationContext)
---@param dest System.IO.Stream
---@param value any
---@param type System.Type
---@param style ProtoBuf.PrefixStyle
---@param fieldNumber number
function m:SerializeWithLengthPrefix(dest, value, type, style, fieldNumber) end

---@overload fun(source:System.IO.Stream, value:any, type:System.Type, context:ProtoBuf.SerializationContext):any
---@overload fun(source:System.IO.Stream, value:any, type:System.Type, length:number):any
---@overload fun(source:System.IO.Stream, value:any, type:System.Type, length:number, context:ProtoBuf.SerializationContext):any
---@overload fun(source:ProtoBuf.ProtoReader, value:any, type:System.Type):any
---@param source System.IO.Stream
---@param value any
---@param type System.Type
---@return any
function m:Deserialize(source, value, type) end

---@static
---@return ProtoBuf.Meta.RuntimeTypeModel
function m.Create() end

---@param type System.Type
---@return boolean
function m:IsDefined(type) end

---@param value any
---@return any
function m:DeepClone(value) end

---@static
---@param type System.Type
function m.ThrowCannotCreateInstance(type) end

---@param type System.Type
---@return boolean
function m:CanSerializeContractType(type) end

---@param type System.Type
---@return boolean
function m:CanSerialize(type) end

---@param type System.Type
---@return boolean
function m:CanSerializeBasicType(type) end

---@virtual
---@param type System.Type
---@return string
function m:GetSchema(type) end

---@param value fun(sender:any, args:ProtoBuf.Meta.TypeFormatEventArgs)
function m:add_DynamicTypeFormatting(value) end

---@param value fun(sender:any, args:ProtoBuf.Meta.TypeFormatEventArgs)
function m:remove_DynamicTypeFormatting(value) end

ProtoBuf.Meta.TypeModel = m
return m
