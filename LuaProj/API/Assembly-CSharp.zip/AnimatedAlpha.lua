---@class AnimatedAlpha : UnityEngine.MonoBehaviour
---@field public alpha number
local m = {}

AnimatedAlpha = m
return m
