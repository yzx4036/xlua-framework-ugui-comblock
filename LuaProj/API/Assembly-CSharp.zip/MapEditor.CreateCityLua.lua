---@class MapEditor.CreateCityLua : System.Object
local m = {}

---@static
---@param mCityDic table<number, MapEditor.CityInfo>
---@param fileName string
function m.CreateLuaFile(mCityDic, fileName) end

---@static
---@param path string
---@return string
function m.GetFileName(path) end

MapEditor.CreateCityLua = m
return m
