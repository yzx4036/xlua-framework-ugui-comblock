---@class DragMe : UnityEngine.MonoBehaviour
local m = {}

DragMe = m
return m
