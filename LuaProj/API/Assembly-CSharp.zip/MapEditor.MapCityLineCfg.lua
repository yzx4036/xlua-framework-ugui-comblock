---@class MapEditor.MapCityLineCfg : System.Object
---@field public lineList MapEditor.CityLineInfo[]
local m = {}

MapEditor.MapCityLineCfg = m
return m
