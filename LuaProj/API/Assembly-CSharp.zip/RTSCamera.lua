---@class RTSCamera : UnityEngine.MonoBehaviour
local m = {}

RTSCamera = m
return m
