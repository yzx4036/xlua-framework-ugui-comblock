---@class VoMousePos : System.Object
---@field public pos UnityEngine.Vector3
---@field public time number
local m = {}

VoMousePos = m
return m
