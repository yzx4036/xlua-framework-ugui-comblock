---@class Part2d : UnityEngine.MonoBehaviour
---@field public Actions ActionInfo2d[]
---@field public isLuaUpdate boolean
local m = {}

function m:InitData() end

---@param animationName string
---@param way number
---@param loop boolean
---@param speed number
---@param isResetTime boolean
---@param now number
---@return number
function m:PlayAnimation(animationName, way, loop, speed, isResetTime, now) end

---@param isSample boolean
function m:StopAnimatoin(isSample) end

---@param now number
function m:Update(now) end

Part2d = m
return m
