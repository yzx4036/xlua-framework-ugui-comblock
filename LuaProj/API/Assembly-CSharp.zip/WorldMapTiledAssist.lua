---@class WorldMapTiledAssist : UnityEngine.MonoBehaviour
local m = {}

function m:TiledPosition() end

WorldMapTiledAssist = m
return m
