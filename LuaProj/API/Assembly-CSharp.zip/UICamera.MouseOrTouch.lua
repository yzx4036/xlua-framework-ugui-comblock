---@class UICamera.MouseOrTouch : System.Object
---@field public key UnityEngine.KeyCode
---@field public pos UnityEngine.Vector2
---@field public lastPos UnityEngine.Vector2
---@field public delta UnityEngine.Vector2
---@field public totalDelta UnityEngine.Vector2
---@field public pressedCam UnityEngine.Camera
---@field public last UnityEngine.GameObject
---@field public current UnityEngine.GameObject
---@field public pressed UnityEngine.GameObject
---@field public dragged UnityEngine.GameObject
---@field public pressTime number
---@field public clickTime number
---@field public clickNotification UICamera.ClickNotification
---@field public touchBegan boolean
---@field public pressStarted boolean
---@field public dragStarted boolean
---@field public ignoreDelta number
---@field public deltaTime number
---@field public isOverUI boolean
local m = {}

UICamera.MouseOrTouch = m
return m
