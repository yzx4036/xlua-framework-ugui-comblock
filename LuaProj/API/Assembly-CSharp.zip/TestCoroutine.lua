---@class TestCoroutine : UnityEngine.MonoBehaviour
local m = {}

TestCoroutine = m
return m
