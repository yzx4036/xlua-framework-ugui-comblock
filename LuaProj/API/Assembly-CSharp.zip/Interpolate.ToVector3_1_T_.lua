---@class Interpolate.ToVector3_1_T_ : System.MulticastDelegate
local m = {}

---@virtual
---@param v any
---@return UnityEngine.Vector3
function m:Invoke(v) end

---@virtual
---@param v any
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(v, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return UnityEngine.Vector3
function m:EndInvoke(result) end

Interpolate.ToVector3_1_T_ = m
return m
