---@class EyeSoft.UtilClick : System.Object
---@field public IsVaildClick boolean @static
---@field public last System.DateTime @static
---@field public LastFrameCount number @static
---@field public FinishTouchFrame number @static
local m = {}

---@static
---@return boolean
function m.IsVaildTouch() end

---@static
function m.SetFinishTouchFrame() end

EyeSoft.UtilClick = m
return m
