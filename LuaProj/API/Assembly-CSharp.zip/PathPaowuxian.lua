---@class PathPaowuxian : MagicInBattle
local m = {}

function m:Init() end

---@virtual
---@param _dt number
function m:Update(_dt) end

PathPaowuxian = m
return m
