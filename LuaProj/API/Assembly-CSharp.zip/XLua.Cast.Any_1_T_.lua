---@class XLua.Cast.Any_1_T_ : System.Object
---@field public Target any
local m = {}

XLua.Cast.Any_1_T_ = m
return m
