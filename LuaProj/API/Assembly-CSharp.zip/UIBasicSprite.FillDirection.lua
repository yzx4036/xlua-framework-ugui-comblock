---@class UIBasicSprite.FillDirection : System.Enum
---@field public Horizontal UIBasicSprite.FillDirection @static
---@field public Vertical UIBasicSprite.FillDirection @static
---@field public Radial90 UIBasicSprite.FillDirection @static
---@field public Radial180 UIBasicSprite.FillDirection @static
---@field public Radial360 UIBasicSprite.FillDirection @static
---@field public value__ number
local m = {}

UIBasicSprite.FillDirection = m
return m
