---@class BattleGmAssist : System.Object
local m = {}

---@static
---@return string
function m.ImportConfig() end

---@static
---@param fileName string
---@return string
function m.ImportDefaultConfig(fileName) end

---@static
---@param json string
---@param fileName string
function m.ExportConfig(json, fileName) end

BattleGmAssist = m
return m
