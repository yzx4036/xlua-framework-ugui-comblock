---@class MapEditor.CreateMistyLua : System.Object
local m = {}

---@static
---@param mCityDic table<number, MapEditor.MistyInfo[]>
---@param fileName string
function m.CreateLuaFile(mCityDic, fileName) end

MapEditor.CreateMistyLua = m
return m
