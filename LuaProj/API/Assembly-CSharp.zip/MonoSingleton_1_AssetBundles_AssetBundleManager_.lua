---@class MonoSingleton_1_AssetBundles_AssetBundleManager_ : UnityEngine.MonoBehaviour
---@field public Instance AssetBundles.AssetBundleManager @static
local m = {}

function m:Startup() end

function m:DestroySelf() end

---@virtual
function m:Dispose() end

MonoSingleton_1_AssetBundles_AssetBundleManager_ = m
return m
