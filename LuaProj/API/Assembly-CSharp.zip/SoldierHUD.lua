---@class SoldierHUD : BasicHUD
local m = {}

---@virtual
---@param fightObjType EnumFightObjType
function m:Init(fightObjType) end

SoldierHUD = m
return m
