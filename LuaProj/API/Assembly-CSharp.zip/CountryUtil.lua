---@class CountryUtil : System.Object
local m = {}

---@static
---@param country number
---@param excelbody string
---@return string
function m.GetSoldierBody(country, excelbody) end

CountryUtil = m
return m
