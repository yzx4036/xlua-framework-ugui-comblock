---@class TestBezierPath : UnityEngine.MonoBehaviour
local m = {}

TestBezierPath = m
return m
