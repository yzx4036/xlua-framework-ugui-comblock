---@class UICamera.EventType : System.Enum
---@field public World_3D UICamera.EventType @static
---@field public UI_3D UICamera.EventType @static
---@field public World_2D UICamera.EventType @static
---@field public UI_2D UICamera.EventType @static
---@field public value__ number
local m = {}

UICamera.EventType = m
return m
