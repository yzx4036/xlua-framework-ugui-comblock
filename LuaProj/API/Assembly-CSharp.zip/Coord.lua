---@class Coord : System.Object
---@field public x number
---@field public y number
---@field public cityId number
local m = {}

---@param coord Coord
---@return boolean
function m:equals(coord) end

Coord = m
return m
