---@class ProtoBuf.PrefixStyle : System.Enum
---@field public None ProtoBuf.PrefixStyle @static
---@field public Base128 ProtoBuf.PrefixStyle @static
---@field public Fixed32 ProtoBuf.PrefixStyle @static
---@field public Fixed32BigEndian ProtoBuf.PrefixStyle @static
---@field public value__ number
local m = {}

ProtoBuf.PrefixStyle = m
return m
