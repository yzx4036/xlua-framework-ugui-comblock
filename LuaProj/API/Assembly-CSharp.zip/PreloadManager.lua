---@class PreloadManager : PureSingleton_1_PreloadManager_
local m = {}

---@param initData com.proto.S2C_WAR_BATTLE_INIT
---@return string[]
function m:GetLoadData(initData) end

---@param objInfo VoFightObj
function m:loadBuSkillInMiddle(objInfo) end

PreloadManager = m
return m
