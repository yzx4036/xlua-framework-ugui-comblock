---@class ProtoBuf.Serializers.NullDecorator : ProtoBuf.Serializers.ProtoDecoratorBase
---@field public Tag number @static
---@field public ExpectedType System.Type
---@field public ReturnsValue boolean
---@field public RequiresOldValue boolean
local m = {}

---@virtual
---@param value any
---@param source ProtoBuf.ProtoReader
---@return any
function m:Read(value, source) end

---@virtual
---@param value any
---@param dest ProtoBuf.ProtoWriter
function m:Write(value, dest) end

ProtoBuf.Serializers.NullDecorator = m
return m
