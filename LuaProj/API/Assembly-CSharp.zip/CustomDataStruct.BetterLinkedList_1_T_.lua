---@class CustomDataStruct.BetterLinkedList_1_T_ : System.Object
---@field public Count number
---@field public First any
---@field public Last any
local m = {}

---@overload fun(node:any, value:any):any
---@param node any
---@param newNode any
function m:AddAfter(node, newNode) end

---@overload fun(node:any, value:any):any
---@param node any
---@param newNode any
function m:AddBefore(node, newNode) end

---@overload fun(node:any)
---@param value any
---@return any
function m:AddFirst(value) end

---@overload fun(value:any):any
---@param node any
function m:AddLast(node) end

function m:Clear() end

---@param value any
---@return boolean
function m:Contains(value) end

---@param array any[]
---@param index number
function m:CopyTo(array, index) end

---@param value any
---@return any
function m:Find(value) end

---@param value any
---@return any
function m:FindLast(value) end

---@return System.ValueType
function m:GetEnumerator() end

---@overload fun(value:any):boolean
---@param node any
function m:Remove(node) end

function m:RemoveFirst() end

function m:RemoveLast() end

CustomDataStruct.BetterLinkedList_1_T_ = m
return m
