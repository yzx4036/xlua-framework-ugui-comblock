---@class UITooltip : UnityEngine.MonoBehaviour
---@field public isVisible boolean @static
---@field public uiCamera UnityEngine.Camera
---@field public text UILabel
---@field public tooltipRoot UnityEngine.GameObject
---@field public background UISprite
---@field public appearSpeed number
---@field public scalingTransitions boolean
local m = {}

---@static
---@param text string
function m.ShowText(text) end

---@static
---@param text string
function m.Show(text) end

---@static
function m.Hide() end

UITooltip = m
return m
