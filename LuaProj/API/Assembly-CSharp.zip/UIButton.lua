---@class UIButton : UIButtonColor
---@field public current UIButton @static
---@field public dragHighlight boolean
---@field public hoverSprite string
---@field public pressedSprite string
---@field public disabledSprite string
---@field public hoverSprite2D UnityEngine.Sprite
---@field public pressedSprite2D UnityEngine.Sprite
---@field public disabledSprite2D UnityEngine.Sprite
---@field public pixelSnap boolean
---@field public onClick EventDelegate[]
---@field public isEnabled boolean
---@field public normalSprite string
---@field public normalSprite2D UnityEngine.Sprite
local m = {}

---@virtual
---@param state UIButtonColor.State
---@param immediate boolean
function m:SetState(state, immediate) end

UIButton = m
return m
