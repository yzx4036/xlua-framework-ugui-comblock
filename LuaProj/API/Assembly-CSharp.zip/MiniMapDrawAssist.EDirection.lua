---@class MiniMapDrawAssist.EDirection : System.Enum
---@field public Left MiniMapDrawAssist.EDirection @static
---@field public Right MiniMapDrawAssist.EDirection @static
---@field public Up MiniMapDrawAssist.EDirection @static
---@field public Down MiniMapDrawAssist.EDirection @static
---@field public value__ number
local m = {}

MiniMapDrawAssist.EDirection = m
return m
