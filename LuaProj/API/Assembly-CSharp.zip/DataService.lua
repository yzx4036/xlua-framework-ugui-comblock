---@class DataService : System.Object
local m = {}

---@return number
function m:CreateTable() end

---@return number
function m:DropTable() end

---@overload fun(target:EyeSoft.Data.DataModelBase):number
---@param target EyeSoft.Data.DataModelBase
---@param isReplace boolean
---@return number
function m:InsertOneData(target, isReplace) end

---@param key any
---@return number
function m:DeleteOneData(key) end

---@param target EyeSoft.Data.DataModelBase
---@return number
function m:UpdateOneRowData(target) end

---@return any
function m:GetAllDataByT() end

---@param key any
---@return EyeSoft.Data.DataModelBase
function m:GetOneDataByTWithPrimaryKey(key) end

---@return any
function m:GetSyncObject() end

function m:OpenConnection() end

function m:CloseConnection() end

function m:Dispose() end

DataService = m
return m
