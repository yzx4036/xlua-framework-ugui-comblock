---@class UIPlaySound.Trigger : System.Enum
---@field public OnClick UIPlaySound.Trigger @static
---@field public OnMouseOver UIPlaySound.Trigger @static
---@field public OnMouseOut UIPlaySound.Trigger @static
---@field public OnPress UIPlaySound.Trigger @static
---@field public OnRelease UIPlaySound.Trigger @static
---@field public Custom UIPlaySound.Trigger @static
---@field public OnEnable UIPlaySound.Trigger @static
---@field public OnDisable UIPlaySound.Trigger @static
---@field public value__ number
local m = {}

UIPlaySound.Trigger = m
return m
