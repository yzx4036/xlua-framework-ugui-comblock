---@class IPv6SupportMidleware : System.Object
local m = {}

---@static
---@param serverIp string
---@param serverPorts string
---@return System.String, System.Net.Sockets.AddressFamily
function m.getIPType(serverIp, serverPorts) end

IPv6SupportMidleware = m
return m
