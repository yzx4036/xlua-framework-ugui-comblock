---@class ProtoBuf.Serializer : System.Object
---@field public ListItemTag number @static
local m = {}

---@static
---@return string
function m.GetProto() end

---@static
---@param instance any
---@return any
function m.DeepClone(instance) end

---@static
---@param source System.IO.Stream
---@param instance any
---@return any
function m.Merge(source, instance) end

---@static
---@param source System.IO.Stream
---@return any
function m.Deserialize(source) end

---@static
---@param destination System.IO.Stream
---@param instance any
function m.Serialize(destination, instance) end

---@static
---@param instance any
---@return any
function m.ChangeType(instance) end

---@static
function m.PrepareSerializer() end

---@static
---@param source System.IO.Stream
---@param style ProtoBuf.PrefixStyle
---@param fieldNumber number
---@return any
function m.DeserializeItems(source, style, fieldNumber) end

---@overload fun(source:System.IO.Stream, style:ProtoBuf.PrefixStyle, fieldNumber:number):any @static
---@static
---@param source System.IO.Stream
---@param style ProtoBuf.PrefixStyle
---@return any
function m.DeserializeWithLengthPrefix(source, style) end

---@static
---@param source System.IO.Stream
---@param instance any
---@param style ProtoBuf.PrefixStyle
---@return any
function m.MergeWithLengthPrefix(source, instance, style) end

---@overload fun(destination:System.IO.Stream, instance:any, style:ProtoBuf.PrefixStyle, fieldNumber:number) @static
---@static
---@param destination System.IO.Stream
---@param instance any
---@param style ProtoBuf.PrefixStyle
function m.SerializeWithLengthPrefix(destination, instance, style) end

---@overload fun(buffer:string, index:number, count:number, style:ProtoBuf.PrefixStyle):boolean, System.Int32 @static
---@static
---@param source System.IO.Stream
---@param style ProtoBuf.PrefixStyle
---@return boolean, System.Int32
function m.TryReadLengthPrefix(source, style) end

---@static
function m.FlushPool() end

ProtoBuf.Serializer = m
return m
