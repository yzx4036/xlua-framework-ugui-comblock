---@class MapEditor.MapInfluenceCfg : System.Object
---@field public cityList MapEditor.InfluenceInfo[]
local m = {}

MapEditor.MapInfluenceCfg = m
return m
