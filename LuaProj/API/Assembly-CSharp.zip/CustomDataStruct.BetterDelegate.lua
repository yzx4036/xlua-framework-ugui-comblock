---@class CustomDataStruct.BetterDelegate : System.Object
local m = {}

---@static
function m.Cleanup() end

---@overload fun(callback:(fun(args:any[]):any), arg1:any):CustomDataStruct.IDelegateAction @static
---@overload fun(callback:(fun(args:any[]):any), arg1:any, arg2:any):CustomDataStruct.IDelegateAction @static
---@overload fun(callback:(fun(args:any[]):any), arg1:any, arg2:any, arg3:any):CustomDataStruct.IDelegateAction @static
---@static
---@param callback fun(args:any[]):any
---@return CustomDataStruct.IDelegateAction
function m.GetAction(callback) end

CustomDataStruct.BetterDelegate = m
return m
