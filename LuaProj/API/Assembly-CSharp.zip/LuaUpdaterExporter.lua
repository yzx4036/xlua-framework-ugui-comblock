---@class LuaUpdaterExporter : System.Object
---@field public CSharpCallLua System.Type[] @static
local m = {}

LuaUpdaterExporter = m
return m
