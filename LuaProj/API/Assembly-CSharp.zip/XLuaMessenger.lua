---@class XLuaMessenger : System.Object
---@field public MessageNameTypeMap table<number, System.Type> @static
local m = {}

---@static
---@param eventType number
---@param func XLua.LuaFunction
---@return fun(args:any[]):any
function m.CreateDelegate(eventType, func) end

---@static
---@param eventType number
---@param handler fun(args:any[]):any
function m.AddListener(eventType, handler) end

---@static
---@param eventType number
---@param handler fun(args:any[]):any
function m.RemoveListener(eventType, handler) end

---@overload fun(eventType:number, arg1:any, arg2:any) @static
---@overload fun(eventType:number, arg1:any, arg2:any, arg3:any) @static
---@static
---@param eventType number
---@param arg1 any
function m.Broadcast(eventType, arg1) end

---@static
---@param type System.Type
---@param valueObj any
---@return any
function m.CastType(type, valueObj) end

XLuaMessenger = m
return m
