---@class EyeSoft.EventCallLua : System.MulticastDelegate
local m = {}

---@virtual
---@param targetLua XLua.LuaTable
---@param gt HedgehogTeam.EasyTouch.Gesture
---@return boolean
function m:Invoke(targetLua, gt) end

---@virtual
---@param targetLua XLua.LuaTable
---@param gt HedgehogTeam.EasyTouch.Gesture
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(targetLua, gt, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return boolean
function m:EndInvoke(result) end

EyeSoft.EventCallLua = m
return m
