---@class BasicHUD : System.Object
---@field public gameObject UnityEngine.GameObject
---@field public transform UnityEngine.Transform
---@field public fightObjType EnumFightObjType
local m = {}

---@virtual
---@param fightObjType EnumFightObjType
function m:Init(fightObjType) end

---@param _status boolean
function m:Visible(_status) end

---@param _value number
function m:SetMaxValue(_value) end

---@virtual
---@param _value number
---@param whitevalue number
function m:UpdateHp(_value, whitevalue) end

---@virtual
---@param country number
---@param name string
function m:SetCountryAndName(country, name) end

function m:Dispose() end

---@param _pos UnityEngine.Vector3
function m:Update(_pos) end

BasicHUD = m
return m
