---@class SkEffCol : SkEffBase
local m = {}

SkEffCol = m
return m
