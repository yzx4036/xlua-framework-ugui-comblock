---@class SceneEffLodData : System.Object
---@field public EffName string
---@field public ShowDistance number
---@field public HideDistance number
local m = {}

SceneEffLodData = m
return m
