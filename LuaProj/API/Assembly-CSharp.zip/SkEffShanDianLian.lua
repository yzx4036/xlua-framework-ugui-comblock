---@class SkEffShanDianLian : SkEffBase
local m = {}

SkEffShanDianLian = m
return m
