---@class UINoticeTip : MonoSingleton_1_UINoticeTip_
---@field public LastClickIndex number @static
---@field public IsShowing boolean
---@field public UIGameObject UnityEngine.GameObject
---@field public progress number
---@field public isDone boolean
local m = {}

---@param title string
---@param content string
---@param btnText string
---@param callback fun()
function m:ShowOneButtonTip(title, content, btnText, callback) end

---@param title string
---@param content string
---@param btnText1 string
---@param btnText2 string
---@param callback1 fun()
---@param callback2 fun()
function m:ShowTwoButtonTip(title, content, btnText1, btnText2, callback1, callback2) end

---@param title string
---@param content string
---@param btnText1 string
---@param btnText2 string
---@param btnText3 string
---@param callback1 fun()
---@param callback2 fun()
---@param callback3 fun()
function m:ShowThreeButtonTip(title, content, btnText1, btnText2, btnText3, callback1, callback2, callback3) end

function m:HideTip() end

---@return System.Collections.IEnumerator
function m:WaitForResponse() end

---@virtual
function m:Dispose() end

UINoticeTip = m
return m
