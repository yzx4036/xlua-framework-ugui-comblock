---@class AssetBundles.EditorAssetAsyncLoader : AssetBundles.BaseAssetAsyncLoader
local m = {}

---@virtual
function m:Update() end

---@virtual
---@return boolean
function m:IsDone() end

---@virtual
---@return number
function m:Progress() end

AssetBundles.EditorAssetAsyncLoader = m
return m
