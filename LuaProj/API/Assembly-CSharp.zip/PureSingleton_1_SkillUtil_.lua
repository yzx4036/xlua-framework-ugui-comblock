---@class PureSingleton_1_SkillUtil_ : System.Object
---@field public Instance SkillUtil @static
local m = {}

PureSingleton_1_SkillUtil_ = m
return m
