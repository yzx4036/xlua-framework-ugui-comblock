---@class AssetBundles.EditorAssetBundleAsyncLoader : AssetBundles.BaseAssetBundleAsyncLoader
local m = {}

---@virtual
---@return boolean
function m:IsDone() end

---@virtual
---@return number
function m:Progress() end

---@virtual
function m:Update() end

---@virtual
function m:Dispose() end

AssetBundles.EditorAssetBundleAsyncLoader = m
return m
