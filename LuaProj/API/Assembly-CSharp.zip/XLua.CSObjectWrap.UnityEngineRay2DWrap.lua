---@class XLua.CSObjectWrap.UnityEngineRay2DWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineRay2DWrap = m
return m
