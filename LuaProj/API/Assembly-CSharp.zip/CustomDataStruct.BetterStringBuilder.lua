---@class CustomDataStruct.BetterStringBuilder : System.Object
---@field public BufferSize number
---@field public Item number
---@field public Capacity number
---@field public Length number
---@field public MaxCapacity number
local m = {}

---@static
function m.Cleanup() end

function m:ClearBuffer() end

---@overload fun(value:string)
---@overload fun(value:number)
---@overload fun(value:number, precision:number)
---@overload fun(value:number)
---@overload fun(value:any)
---@overload fun(value:number, precision:number)
---@overload fun(value:number)
---@overload fun(value:number)
---@overload fun(value:number)
---@overload fun(value:number)
---@overload fun(value:number)
---@overload fun(value:number)
---@overload fun(value:number[])
---@overload fun(value:number, repeatCount:number)
---@overload fun(value:string, startIndex:number, count:number)
---@overload fun(value:number[], startIndex:number, charCount:number)
---@param value boolean
function m:Append(value) end

---@overload fun(format:string, arg0:any, arg1:any)
---@overload fun(format:string, arg0:any, arg1:any, arg2:any)
---@overload fun(format:string, arg0:number)
---@overload fun(format:string, arg0:number, arg1:number)
---@overload fun(format:string, arg0:number, arg1:number, arg2:number)
---@param format string
---@param arg0 any
function m:AppendFormat(format, arg0) end

---@overload fun(value:string)
function m:AppendLine() end

---@param sourceIndex number
---@param destination number[]
---@param destinationIndex number
---@param count number
function m:CopyTo(sourceIndex, destination, destinationIndex, count) end

---@param capacity number
---@return number
function m:EnsureCapacity(capacity) end

---@overload fun(sb:CustomDataStruct.BetterStringBuilder):boolean
---@overload fun(str:string):boolean
---@overload fun(str:string, startIndex:number, length:number):boolean
---@param sb System.Text.StringBuilder
---@return boolean
function m:Equals(sb) end

---@param str string
---@param selfPartStartIndex number
---@param slefPartLength number
---@return boolean
function m:PartEquals(str, selfPartStartIndex, slefPartLength) end

---@overload fun(index:number, value:number)
---@overload fun(index:number, value:number)
---@overload fun(index:number, value:number, precision:number)
---@overload fun(index:number, value:number)
---@overload fun(index:number, value:number)
---@overload fun(index:number, value:number)
---@overload fun(index:number, value:any)
---@overload fun(index:number, value:number, precision:number)
---@overload fun(index:number, value:boolean)
---@overload fun(index:number, value:number)
---@overload fun(index:number, value:number)
---@overload fun(index:number, value:string)
---@overload fun(index:number, value:number[])
---@overload fun(index:number, value:string, count:number)
---@overload fun(index:number, value:number[], startIndex:number, charCount:number)
---@param index number
---@param value number
function m:Insert(index, value) end

---@param startIndex number
---@param length number
function m:Remove(startIndex, length) end

function m:Clear() end

---@overload fun(oldChar:number, newChar:number)
---@overload fun(oldValue:string, newValue:string, startIndex:number, count:number)
---@overload fun(oldChar:number, newChar:number, startIndex:number, count:number)
---@param oldValue string
---@param newValue string
function m:Replace(oldValue, newValue) end

---@overload fun(startIndex:number, length:number):string
---@virtual
---@return string
function m:ToString() end

function m:ToLower() end

function m:ToUpper() end

CustomDataStruct.BetterStringBuilder = m
return m
