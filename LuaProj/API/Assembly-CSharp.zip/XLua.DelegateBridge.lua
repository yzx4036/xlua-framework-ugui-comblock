---@class XLua.DelegateBridge : XLua.DelegateBridgeBase
---@field public Gen_Flag boolean @static
local m = {}

function m:__Gen_Delegate_Imp0() end

---@param p0 number
function m:__Gen_Delegate_Imp1(p0) end

---@param p0 number
---@param p1 number
function m:__Gen_Delegate_Imp2(p0, p1) end

---@param p0 string
function m:__Gen_Delegate_Imp3(p0) end

---@param p0 any
---@param p1 number
---@param p2 string
function m:__Gen_Delegate_Imp4(p0, p1, p2) end

---@param p0 number
function m:__Gen_Delegate_Imp5(p0) end

---@param p0 UnityEngine.WWW
function m:__Gen_Delegate_Imp6(p0) end

---@param p0 UnityEngine.Vector2
function m:__Gen_Delegate_Imp7(p0) end

---@param p0 XLua.LuaTable
---@param p1 HedgehogTeam.EasyTouch.Gesture
---@return boolean
function m:__Gen_Delegate_Imp8(p0, p1) end

---@param p0 any
function m:__Gen_Delegate_Imp9(p0) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 UnityEngine.LogType
function m:__Gen_Delegate_Imp10(p0, p1, p2, p3) end

---@param p0 any
---@param p1 LoggerHelper.LOG_TYPE
---@param p2 any
function m:__Gen_Delegate_Imp11(p0, p1, p2) end

---@param p0 any
---@return string
function m:__Gen_Delegate_Imp12(p0) end

---@param p0 any
---@param p1 any
---@param p2 boolean
---@return string[]
function m:__Gen_Delegate_Imp13(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@return string[]
function m:__Gen_Delegate_Imp14(p0, p1) end

---@param p0 any
---@return string[]
function m:__Gen_Delegate_Imp15(p0) end

---@param p0 any
---@param p1 any
---@return boolean
function m:__Gen_Delegate_Imp16(p0, p1) end

---@param p0 any
---@return string
function m:__Gen_Delegate_Imp17(p0) end

---@param p0 any
---@return boolean
function m:__Gen_Delegate_Imp18(p0) end

---@return number
function m:__Gen_Delegate_Imp19() end

---@param p0 any
---@param p1 boolean
function m:__Gen_Delegate_Imp20(p0, p1) end

---@param p0 any
---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp21(p0) end

---@param p0 any
---@param p1 any
function m:__Gen_Delegate_Imp22(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 any
---@param p3 any
function m:__Gen_Delegate_Imp23(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@param p4 any
function m:__Gen_Delegate_Imp24(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@param p4 any
---@param p5 any
---@param p6 any
function m:__Gen_Delegate_Imp25(p0, p1, p2, p3, p4, p5, p6) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@param p4 any
---@param p5 any
---@param p6 any
---@param p7 any
---@param p8 any
function m:__Gen_Delegate_Imp26(p0, p1, p2, p3, p4, p5, p6, p7, p8) end

---@param p0 any
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp27(p0) end

---@param p0 any
---@return number
function m:__Gen_Delegate_Imp28(p0) end

---@param p0 any
---@param p1 boolean
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp29(p0, p1) end

---@param p0 any
---@param p1 number
---@return boolean
function m:__Gen_Delegate_Imp30(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 boolean
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp31(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@return string
function m:__Gen_Delegate_Imp32(p0, p1) end

---@param p0 any
---@param p1 any
---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp33(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 any
function m:__Gen_Delegate_Imp34(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return System.Collections.IEnumerator
function m:__Gen_Delegate_Imp35(p0, p1, p2) end

---@param p0 any
---@return XLua.LuaEnv
function m:__Gen_Delegate_Imp36(p0) end

---@param p0 any
---@param p1 any
---@return any[]
function m:__Gen_Delegate_Imp37(p0, p1) end

---@param p0 System.String
---@return string, System.String
function m:__Gen_Delegate_Imp38(p0) end

---@param p0 any
---@param p1 UnityEngine.SceneManagement.Scene
---@param p2 UnityEngine.SceneManagement.LoadSceneMode
function m:__Gen_Delegate_Imp39(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any[]
---@return any[]
function m:__Gen_Delegate_Imp40(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@param p2 System.Int32
---@return System.Int32
function m:__Gen_Delegate_Imp41(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@param p2 number
function m:__Gen_Delegate_Imp42(p0, p1, p2) end

---@return string
function m:__Gen_Delegate_Imp43() end

---@param p0 any
---@return AssetBundles.Manifest
function m:__Gen_Delegate_Imp44(p0) end

---@param p0 any
---@param p1 any
---@param p2 boolean
function m:__Gen_Delegate_Imp45(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@return UnityEngine.AssetBundle
function m:__Gen_Delegate_Imp46(p0, p1) end

---@param p0 any
---@param p1 any
---@return UnityEngine.Object
function m:__Gen_Delegate_Imp47(p0, p1) end

---@param p0 any
---@param p1 any
---@return AssetBundles.ResourceWebRequester
function m:__Gen_Delegate_Imp48(p0, p1) end

---@param p0 any
---@param p1 any
---@return number
function m:__Gen_Delegate_Imp49(p0, p1) end

---@param p0 any
---@param p1 any
---@return AssetBundles.BaseAssetBundleAsyncLoader
function m:__Gen_Delegate_Imp50(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 boolean
---@return AssetBundles.ResourceWebRequester
function m:__Gen_Delegate_Imp51(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@param p2 boolean
---@param p3 boolean
---@param p4 boolean
---@return boolean
function m:__Gen_Delegate_Imp52(p0, p1, p2, p3, p4) end

---@param p0 any
---@param p1 any
---@param p2 boolean
---@param p3 boolean
---@return boolean
function m:__Gen_Delegate_Imp53(p0, p1, p2, p3) end

---@param p0 any
---@param p1 boolean
---@param p2 boolean
---@return number
function m:__Gen_Delegate_Imp54(p0, p1, p2) end

---@param p0 any
---@param p1 any
---@return boolean, System.String, System.String
function m:__Gen_Delegate_Imp55(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 any
---@return AssetBundles.BaseAssetAsyncLoader
function m:__Gen_Delegate_Imp56(p0, p1, p2) end

---@param p0 any
---@return System.Collections.Generic.HashSet_1_System_String_
function m:__Gen_Delegate_Imp57(p0) end

---@param p0 any
---@return System.Collections.Generic.ICollection_1_System_String_
function m:__Gen_Delegate_Imp58(p0) end

---@param p0 any
---@return System.Collections.Generic.Dictionary_2_System_String_AssetBundles_ResourceWebRequester_
function m:__Gen_Delegate_Imp59(p0) end

---@param p0 any
---@return System.Collections.Generic.Queue_1_AssetBundles_ResourceWebRequester_
function m:__Gen_Delegate_Imp60(p0) end

---@param p0 any
---@return AssetBundles.ResourceWebRequester[]
function m:__Gen_Delegate_Imp61(p0) end

---@param p0 any
---@return AssetBundles.AssetBundleAsyncLoader[]
function m:__Gen_Delegate_Imp62(p0) end

---@param p0 any
---@return AssetBundles.AssetAsyncLoader[]
function m:__Gen_Delegate_Imp63(p0) end

---@param p0 any
---@param p1 any
---@return string
function m:__Gen_Delegate_Imp64(p0, p1) end

---@param p0 any
---@return number
function m:__Gen_Delegate_Imp65(p0) end

---@param p0 any
---@return System.Collections.Generic.Dictionary_2_System_String_System_Collections_Generic_List_1_System_String__
function m:__Gen_Delegate_Imp66(p0) end

---@param p0 any
---@param p1 any
---@return string[]
function m:__Gen_Delegate_Imp67(p0, p1) end

---@return AssetBundles.AssetAsyncLoader
function m:__Gen_Delegate_Imp68() end

---@param p0 any
---@param p1 number
function m:__Gen_Delegate_Imp69(p0, p1) end

---@return AssetBundles.AssetBundleAsyncLoader
function m:__Gen_Delegate_Imp70() end

---@return AssetBundles.ResourceWebRequester
function m:__Gen_Delegate_Imp71() end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 boolean
---@param p4 boolean
function m:__Gen_Delegate_Imp72(p0, p1, p2, p3, p4) end

---@param p0 any
---@return UnityEngine.AssetBundle
function m:__Gen_Delegate_Imp73(p0) end

---@param p0 any
---@return UnityEngine.AssetBundleManifest
function m:__Gen_Delegate_Imp74(p0) end

---@param p0 any
---@param p1 any
---@return UnityEngine.Hash128
function m:__Gen_Delegate_Imp75(p0, p1) end

---@param p0 UnityEngine.RuntimePlatform
---@return string
function m:__Gen_Delegate_Imp76(p0) end

---@param p0 number
---@param p1 boolean
---@param p2 boolean
---@return CustomDataStruct.StreamBuffer
function m:__Gen_Delegate_Imp77(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return string
function m:__Gen_Delegate_Imp78(p0, p1, p2) end

---@param p0 number
---@return string
function m:__Gen_Delegate_Imp79(p0) end

---@param p0 any
---@param p1 boolean
---@param p2 boolean
function m:__Gen_Delegate_Imp80(p0, p1, p2) end

---@param p0 any
---@return System.IO.MemoryStream
function m:__Gen_Delegate_Imp81(p0) end

---@param p0 any
---@return System.IO.BinaryReader
function m:__Gen_Delegate_Imp82(p0) end

---@param p0 any
---@return System.IO.BinaryWriter
function m:__Gen_Delegate_Imp83(p0) end

---@param p0 any
---@param p1 any
---@param p2 number
---@param p3 number
---@param p4 number
function m:__Gen_Delegate_Imp84(p0, p1, p2, p3, p4) end

---@param p0 any
---@return number
function m:__Gen_Delegate_Imp85(p0) end

---@param p0 any
---@param p1 number
function m:__Gen_Delegate_Imp86(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 boolean
---@param p3 boolean
function m:__Gen_Delegate_Imp87(p0, p1, p2, p3) end

---@param p0 any
---@param p1 any
---@return GameChannel.BaseChannel
function m:__Gen_Delegate_Imp88(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 any
---@param p3 any
---@param p4 any
---@param p5 any
function m:__Gen_Delegate_Imp89(p0, p1, p2, p3, p4, p5) end

---@virtual
---@param type System.Type
---@return fun(args:any[]):any
function m:GetDelegateByType(type) end

---@param L System.IntPtr
---@param nArgs number
---@param nResults number
---@param errFunc number
function m:PCall(L, nArgs, nResults, errFunc) end

function m:InvokeSessionStart() end

---@param nRet number
function m:Invoke(nRet) end

function m:InvokeSessionEnd() end

---@return any
function m:InvokeSessionEndWithResult() end

---@param p any
function m:InParam(p) end

---@param ps any[]
function m:InParams(ps) end

---@param pos number
---@return any
function m:OutParam(pos) end

---@overload fun(p1:any)
---@overload fun(p1:any, p2:any)
---@overload fun(p1:any, p2:any, p3:any)
---@overload fun(p1:any, p2:any, p3:any, p4:any)
function m:Action() end

---@overload fun(p1:any):any
---@overload fun(p1:any, p2:any):any
---@overload fun(p1:any, p2:any, p3:any):any
---@overload fun(p1:any, p2:any, p3:any, p4:any):any
---@return any
function m:Func() end

XLua.DelegateBridge = m
return m
