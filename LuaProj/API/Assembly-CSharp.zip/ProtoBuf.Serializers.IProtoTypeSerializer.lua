---@class ProtoBuf.Serializers.IProtoTypeSerializer : table
local m = {}

---@abstract
---@param callbackType ProtoBuf.Meta.TypeModel.CallbackType
---@return boolean
function m:HasCallbacks(callbackType) end

---@abstract
---@return boolean
function m:CanCreateInstance() end

---@abstract
---@param source ProtoBuf.ProtoReader
---@return any
function m:CreateInstance(source) end

---@abstract
---@param value any
---@param callbackType ProtoBuf.Meta.TypeModel.CallbackType
---@param context ProtoBuf.SerializationContext
function m:Callback(value, callbackType, context) end

ProtoBuf.Serializers.IProtoTypeSerializer = m
return m
