---@class EyeSoft.Data.DataModelBase : System.Object
local m = {}

EyeSoft.Data.DataModelBase = m
return m
