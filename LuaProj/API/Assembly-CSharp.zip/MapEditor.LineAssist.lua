---@class MapEditor.LineAssist : UnityEngine.MonoBehaviour
---@field public width number
---@field public height number
---@field public pointA number
---@field public pointB number
---@field public TheirLine string
---@field public lineCfg MapEditor.MapCityLineCfg
---@field public isInit boolean
---@field public lineDic System.Collections.Generic.Dictionary_2_System_String_MapEditor_CityLineInfo_
---@field public lineList MapEditor.GridInfo[]
---@field public cityLine string
local m = {}

function m:Init() end

function m:Save() end

---@param x number
---@param z number
function m:ClickGrid(x, z) end

---@param x number
---@param z number
function m:ShowGridLine(x, z) end

function m:ClearCurrentCity() end

---@param x number
---@param y number
---@return boolean
function m:IsValidCoord(x, y) end

---@param list MapEditor.GridInfo[]
function m:SortNode(list) end

---@param info MapEditor.GridInfo
---@return UnityEngine.Vector2
function m:ToVector2(info) end

MapEditor.LineAssist = m
return m
