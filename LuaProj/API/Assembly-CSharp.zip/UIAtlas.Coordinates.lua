---@class UIAtlas.Coordinates : System.Enum
---@field public Pixels UIAtlas.Coordinates @static
---@field public TexCoords UIAtlas.Coordinates @static
---@field public value__ number
local m = {}

UIAtlas.Coordinates = m
return m
