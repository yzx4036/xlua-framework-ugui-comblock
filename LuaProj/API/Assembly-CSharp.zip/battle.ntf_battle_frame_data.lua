---@class battle.ntf_battle_frame_data : System.Object
---@field public time number
---@field public slot_list battle.ntf_battle_frame_data.one_slot[]
---@field public server_from_slot number
---@field public server_to_slot number
---@field public server_curr_frame number
---@field public is_check_frame number
local m = {}

battle.ntf_battle_frame_data = m
return m
