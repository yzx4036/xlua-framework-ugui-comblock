---@class Battle.ScenePreloaded : System.Object
local m = {}

---@virtual
---@param paths string[]
function m:InitPreloadedQueue(paths) end

---@virtual
function m:StartPreloaded() end

---@virtual
---@return boolean
function m:IsDone() end

Battle.ScenePreloaded = m
return m
