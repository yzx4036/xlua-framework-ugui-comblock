---@class EyeSoft.MatchKit.IDataBlackBoard : table
local m = {}

---@abstract
function m:Init() end

---@abstract
---@param id number
---@return MatchKitEx.ICfgData
function m:LoadCfgData(id) end

---@abstract
---@param id number
---@return MatchKitEx.ICfgData
function m:GetCfgData(id) end

---@abstract
---@param id number
---@return EyeSoft.Data.DataModelBase
function m:GetModelDataById(id) end

---@abstract
---@param newValue EyeSoft.Data.DataModelBase
---@return boolean
function m:UpdateModelData(newValue) end

EyeSoft.MatchKit.IDataBlackBoard = m
return m
