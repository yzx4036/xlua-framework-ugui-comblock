---@class HTTP_TYPE : System.Enum
---@field public GET HTTP_TYPE @static
---@field public POST HTTP_TYPE @static
---@field public value__ number
local m = {}

HTTP_TYPE = m
return m
