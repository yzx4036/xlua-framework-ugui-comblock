---@class UIEventTrigger : UnityEngine.MonoBehaviour
---@field public current UIEventTrigger @static
---@field public onHoverOver EventDelegate[]
---@field public onHoverOut EventDelegate[]
---@field public onPress EventDelegate[]
---@field public onRelease EventDelegate[]
---@field public onSelect EventDelegate[]
---@field public onDeselect EventDelegate[]
---@field public onClick EventDelegate[]
---@field public onDoubleClick EventDelegate[]
---@field public onDragStart EventDelegate[]
---@field public onDragEnd EventDelegate[]
---@field public onDragOver EventDelegate[]
---@field public onDragOut EventDelegate[]
---@field public onDrag EventDelegate[]
---@field public isColliderEnabled boolean
local m = {}

UIEventTrigger = m
return m
