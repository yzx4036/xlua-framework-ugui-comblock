---@class PureSingleton_1_PreloadManager_ : System.Object
---@field public Instance PreloadManager @static
local m = {}

PureSingleton_1_PreloadManager_ = m
return m
