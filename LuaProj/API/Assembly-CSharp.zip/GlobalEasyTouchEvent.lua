---@class GlobalEasyTouchEvent : UnityEngine.MonoBehaviour
---@field public statText UnityEngine.UI.Text
local m = {}

GlobalEasyTouchEvent = m
return m
