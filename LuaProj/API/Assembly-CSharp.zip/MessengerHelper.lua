---@class MessengerHelper : UnityEngine.MonoBehaviour
local m = {}

function m:OnLevelWasLoaded() end

MessengerHelper = m
return m
