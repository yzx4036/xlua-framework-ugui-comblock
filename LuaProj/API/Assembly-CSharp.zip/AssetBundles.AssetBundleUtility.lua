---@class AssetBundles.AssetBundleUtility : System.Object
local m = {}

---@overload fun():string @static
---@static
---@param assetPath string
---@return string
function m.GetStreamingAssetsFilePath(assetPath) end

---@overload fun():string @static
---@static
---@param assetPath string
---@return string
function m.GetStreamingAssetsDataPath(assetPath) end

---@overload fun():string @static
---@static
---@param assetPath string
---@return string
function m.GetPersistentFilePath(assetPath) end

---@overload fun():string @static
---@static
---@param assetPath string
---@return string
function m.GetPersistentDataPath(assetPath) end

---@static
---@param filePath string
---@return boolean
function m.CheckPersistentFileExsits(filePath) end

---@static
---@param filePath string
---@return string
function m.GetAssetBundleFileUrl(filePath) end

---@static
---@param assetPath string
---@return string
function m.AssetBundlePathToAssetBundleName(assetPath) end

---@static
---@param assetPath string
---@return string
function m.PackagePathToAssetsPath(assetPath) end

---@static
---@param assetPath string
---@return boolean
function m.IsPackagePath(assetPath) end

---@static
---@param assetPath string
---@return string
function m.AssetsPathToPackagePath(assetPath) end

AssetBundles.AssetBundleUtility = m
return m
