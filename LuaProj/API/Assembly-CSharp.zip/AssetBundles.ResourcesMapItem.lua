---@class AssetBundles.ResourcesMapItem : System.Object
---@field public assetbundleName string
---@field public assetName string
local m = {}

AssetBundles.ResourcesMapItem = m
return m
