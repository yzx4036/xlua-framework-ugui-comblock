---@class EyeSoft.Data.SQLiteManager : MonoSingleton_1_EyeSoft_Data_SQLiteManager_
local m = {}

---@return number
function m:CreateTable() end

---@return number
function m:DropTable() end

---@param target EyeSoft.Data.DataModelBase
---@param isReplace boolean
---@return number
function m:InsertOneData(target, isReplace) end

---@param key any
---@return number
function m:DeleteOneData(key) end

---@param target EyeSoft.Data.DataModelBase
---@return number
function m:UpdateOneRowData(target) end

---@return EyeSoft.Data.DataModelBase[]
function m:GetAllDataByT() end

---@param key any
---@return EyeSoft.Data.DataModelBase
function m:GetOneDataByTWithPrimaryKey(key) end

---@virtual
function m:Dispose() end

EyeSoft.Data.SQLiteManager = m
return m
