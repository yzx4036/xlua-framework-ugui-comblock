---@class MiniMapDrawAssist.CfgMapInfluence : System.Object
---@field public infos System.Collections.Generic.Dictionary_2_System_String_MiniMapDrawAssist_CfgMapInfluenceInfo_
local m = {}

MiniMapDrawAssist.CfgMapInfluence = m
return m
