---@class ActionUnit : Entity
local m = {}

---@param body string
---@param weapon string
---@param horse string
---@param resType EnumSceneModelType
---@param delayTime number
function m:Initialize(body, weapon, horse, resType, delayTime) end

---@overload fun(action:string, loop:boolean, horseSpeed:number, bodySpeed:number) @virtual
---@overload fun(action:string, loop:boolean, horseSpeed:number) @virtual
---@overload fun(action:string, loop:boolean) @virtual
---@virtual
---@param action string
---@param loop boolean
---@param horseSpeed number
---@param bodySpeed number
---@param fadeTime number
function m:SetAction(action, loop, horseSpeed, bodySpeed, fadeTime) end

---@return string
function m:GetAction() end

---@virtual
---@param _dt number
function m:Update(_dt) end

---@return number
function m:getActionTime() end

---@virtual
function m:Release() end

ActionUnit = m
return m
