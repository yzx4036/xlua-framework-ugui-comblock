---@class XLua.CSObjectWrap.SystemArrayWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.SystemArrayWrap = m
return m
