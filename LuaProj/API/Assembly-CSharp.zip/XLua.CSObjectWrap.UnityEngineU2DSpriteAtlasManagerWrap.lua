---@class XLua.CSObjectWrap.UnityEngineU2DSpriteAtlasManagerWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineU2DSpriteAtlasManagerWrap = m
return m
