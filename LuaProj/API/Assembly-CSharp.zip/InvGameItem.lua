---@class InvGameItem : System.Object
---@field public quality InvGameItem.Quality
---@field public itemLevel number
---@field public baseItemID number
---@field public baseItem InvBaseItem
---@field public name string
---@field public statMultiplier number
---@field public color UnityEngine.Color
local m = {}

---@return InvStat[]
function m:CalculateStats() end

InvGameItem = m
return m
