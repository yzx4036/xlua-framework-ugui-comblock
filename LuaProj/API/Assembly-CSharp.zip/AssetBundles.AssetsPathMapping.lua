---@class AssetBundles.AssetsPathMapping : System.Object
---@field public AssetbundleName string
---@field public AssetName string
local m = {}

---@param content string
function m:Initialize(content) end

---@param assetPath string
---@return boolean, System.String, System.String
function m:MapAssetPath(assetPath) end

---@param assetbundleName string
---@return string[]
function m:GetAllAssetNames(assetbundleName) end

---@param assetName string
---@return string
function m:GetAssetBundleName(assetName) end

AssetBundles.AssetsPathMapping = m
return m
