---@class XLua.CSObjectWrap.UnityEngineUITextWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineUITextWrap = m
return m
