---@class EyeSoft.GamePlatform : System.Enum
---@field public Windows EyeSoft.GamePlatform @static
---@field public OSX EyeSoft.GamePlatform @static
---@field public Android EyeSoft.GamePlatform @static
---@field public iOS EyeSoft.GamePlatform @static
---@field public value__ number
local m = {}

EyeSoft.GamePlatform = m
return m
