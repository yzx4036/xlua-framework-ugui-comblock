---@class VoTweener : System.Object
---@field public relateBuId number
---@field public tw Holoville.HOTween.Tweener
local m = {}

VoTweener = m
return m
