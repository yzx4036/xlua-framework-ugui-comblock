---@class UICamera.BoolDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param go UnityEngine.GameObject
---@param state boolean
function m:Invoke(go, state) end

---@virtual
---@param go UnityEngine.GameObject
---@param state boolean
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(go, state, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UICamera.BoolDelegate = m
return m
