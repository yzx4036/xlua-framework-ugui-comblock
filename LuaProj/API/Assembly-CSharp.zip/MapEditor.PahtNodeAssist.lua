---@class MapEditor.PahtNodeAssist : UnityEngine.MonoBehaviour
local m = {}

MapEditor.PahtNodeAssist = m
return m
