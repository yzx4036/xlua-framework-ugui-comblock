---@class CubeSelect : UnityEngine.MonoBehaviour
local m = {}

CubeSelect = m
return m
