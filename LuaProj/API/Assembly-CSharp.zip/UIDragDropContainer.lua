---@class UIDragDropContainer : UnityEngine.MonoBehaviour
---@field public reparentTarget UnityEngine.Transform
local m = {}

UIDragDropContainer = m
return m
