---@class UIBasicSprite.Flip : System.Enum
---@field public Nothing UIBasicSprite.Flip @static
---@field public Horizontally UIBasicSprite.Flip @static
---@field public Vertically UIBasicSprite.Flip @static
---@field public Both UIBasicSprite.Flip @static
---@field public value__ number
local m = {}

UIBasicSprite.Flip = m
return m
