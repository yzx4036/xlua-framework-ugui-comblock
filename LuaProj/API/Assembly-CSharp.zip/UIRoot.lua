---@class UIRoot : UnityEngine.MonoBehaviour
---@field public list UIRoot[] @static
---@field public scalingStyle UIRoot.Scaling
---@field public manualWidth number
---@field public manualHeight number
---@field public minimumHeight number
---@field public maximumHeight number
---@field public fitWidth boolean
---@field public fitHeight boolean
---@field public adjustByDPI boolean
---@field public shrinkPortraitUI boolean
---@field public constraint UIRoot.Constraint
---@field public activeScaling UIRoot.Scaling
---@field public activeHeight number
---@field public pixelSizeAdjustment number
local m = {}

---@overload fun(height:number):number
---@static
---@param go UnityEngine.GameObject
---@return number
function m.GetPixelSizeAdjustment(go) end

---@overload fun()
---@param updateAnchors boolean
function m:UpdateScale(updateAnchors) end

---@overload fun(funcName:string, param:any) @static
---@static
---@param funcName string
function m.Broadcast(funcName) end

UIRoot = m
return m
