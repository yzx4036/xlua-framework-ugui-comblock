---@class AddBuUtil : PureSingleton_1_AddBuUtil_
local m = {}

---@param herodata com.proto.HeroWarData
---@param serverBuData com.proto.CombatUnit
---@param delayTime number
---@return BattleUnit
function m:generateBu(herodata, serverBuData, delayTime) end

---@param sceneUnits com.proto.SceneCombatUnit[]
function m:generateSceneCombatUnit(sceneUnits) end

---@param zhwData com.proto.SceneCombatUnit
---@return BattleUnit
function m:GenerateZhaoHuanWu(zhwData) end

---@param eid number
---@param body string
---@param x number
---@param y number
---@return BattleUnit
function m:GenerateDeadUnit(eid, body, x, y) end

---@param bu BattleUnit
---@param type EnumEntranceType
function m:dealAddBu(bu, type) end

AddBuUtil = m
return m
