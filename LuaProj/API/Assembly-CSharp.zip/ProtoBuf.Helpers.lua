---@class ProtoBuf.Helpers : System.Object
---@field public EmptyTypes System.Type[] @static
local m = {}

---@static
---@param builder System.Text.StringBuilder
---@return System.Text.StringBuilder
function m.AppendLine(builder) end

---@static
---@param value string
---@return boolean
function m.IsNullOrEmpty(value) end

---@overload fun(message:string) @static
---@static
---@param message string
---@param obj any
function m.DebugWriteLine(message, obj) end

---@static
---@param message string
function m.TraceWriteLine(message) end

---@overload fun(condition:boolean, message:string, args:any[]|any) @static
---@overload fun(condition:boolean, message:string) @static
---@overload fun(condition:boolean) @static
---@static
---@param condition boolean
---@param message string
function m.DebugAssert(condition, message) end

---@static
---@param keys number[]
---@param values any[]
function m.Sort(keys, values) end

---@static
---@param from string
---@param fromIndex number
---@param to string
---@param toIndex number
---@param count number
function m.BlockCopy(from, fromIndex, to, toIndex, count) end

---@overload fun(value:number):boolean @static
---@static
---@param value number
---@return boolean
function m.IsInfinity(value) end

---@static
---@param type System.Type
---@return ProtoBuf.ProtoTypeCode
function m.GetTypeCode(type) end

ProtoBuf.Helpers = m
return m
