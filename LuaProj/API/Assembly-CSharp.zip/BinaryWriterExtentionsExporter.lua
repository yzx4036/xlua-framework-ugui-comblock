---@class BinaryWriterExtentionsExporter : System.Object
---@field public LuaCallCSharp System.Type[] @static
local m = {}

BinaryWriterExtentionsExporter = m
return m
