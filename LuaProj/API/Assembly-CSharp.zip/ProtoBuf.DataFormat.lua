---@class ProtoBuf.DataFormat : System.Enum
---@field public Default ProtoBuf.DataFormat @static
---@field public ZigZag ProtoBuf.DataFormat @static
---@field public TwosComplement ProtoBuf.DataFormat @static
---@field public FixedSize ProtoBuf.DataFormat @static
---@field public Group ProtoBuf.DataFormat @static
---@field public value__ number
local m = {}

ProtoBuf.DataFormat = m
return m
