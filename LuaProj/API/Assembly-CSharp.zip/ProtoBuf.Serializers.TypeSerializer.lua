---@class ProtoBuf.Serializers.TypeSerializer : System.Object
---@field public ExpectedType System.Type
local m = {}

---@virtual
---@param callbackType ProtoBuf.Meta.TypeModel.CallbackType
---@return boolean
function m:HasCallbacks(callbackType) end

---@virtual
---@param value any
---@param callbackType ProtoBuf.Meta.TypeModel.CallbackType
---@param context ProtoBuf.SerializationContext
function m:Callback(value, callbackType, context) end

---@virtual
---@param value any
---@param dest ProtoBuf.ProtoWriter
function m:Write(value, dest) end

---@virtual
---@param value any
---@param source ProtoBuf.ProtoReader
---@return any
function m:Read(value, source) end

ProtoBuf.Serializers.TypeSerializer = m
return m
