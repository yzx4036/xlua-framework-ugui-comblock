---@class LuaTest : UnityEngine.MonoBehaviour
local m = {}

LuaTest = m
return m
