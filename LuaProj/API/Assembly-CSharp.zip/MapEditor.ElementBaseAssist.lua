---@class MapEditor.ElementBaseAssist : UnityEngine.MonoBehaviour
---@field public id number
local m = {}

MapEditor.ElementBaseAssist = m
return m
