---@class VoSkillArt : System.Object
---@field public id string
---@field public attAction EnumAction
---@field public attEff string
---@field public attEffScale number
---@field public attEffJinxiang boolean
---@field public attEffBeginTime number
---@field public attEffUseTime number
---@field public attEffBP EnumBindPoint
---@field public attEff2 string
---@field public attEffScale2 number
---@field public attEffJinxiang2 boolean
---@field public attEffBeginTime2 number
---@field public attEffUseTime2 number
---@field public attEffBP2 EnumBindPoint
---@field public moveType number
---@field public moveSpeed number
---@field public hurtEff string
---@field public hurtEffScale number
---@field public hurtBeginTime number
---@field public hurtUseTime number
---@field public hurtDelayTime string
---@field public worldEff string
---@field public worldEff2 string
---@field public worldEff3 string
---@field public effStepVo VoEffStep
local m = {}

---@param content string
---@return string
function m:ParseString(content) end

VoSkillArt = m
return m
