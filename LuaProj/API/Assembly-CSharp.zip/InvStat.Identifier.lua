---@class InvStat.Identifier : System.Enum
---@field public Strength InvStat.Identifier @static
---@field public Constitution InvStat.Identifier @static
---@field public Agility InvStat.Identifier @static
---@field public Intelligence InvStat.Identifier @static
---@field public Damage InvStat.Identifier @static
---@field public Crit InvStat.Identifier @static
---@field public Armor InvStat.Identifier @static
---@field public Health InvStat.Identifier @static
---@field public Mana InvStat.Identifier @static
---@field public Other InvStat.Identifier @static
---@field public value__ number
local m = {}

InvStat.Identifier = m
return m
