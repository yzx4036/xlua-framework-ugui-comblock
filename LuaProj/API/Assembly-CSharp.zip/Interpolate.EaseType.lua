---@class Interpolate.EaseType : System.Enum
---@field public Linear Interpolate.EaseType @static
---@field public EaseInQuad Interpolate.EaseType @static
---@field public EaseOutQuad Interpolate.EaseType @static
---@field public EaseInOutQuad Interpolate.EaseType @static
---@field public EaseInCubic Interpolate.EaseType @static
---@field public EaseOutCubic Interpolate.EaseType @static
---@field public EaseInOutCubic Interpolate.EaseType @static
---@field public EaseInQuart Interpolate.EaseType @static
---@field public EaseOutQuart Interpolate.EaseType @static
---@field public EaseInOutQuart Interpolate.EaseType @static
---@field public EaseInQuint Interpolate.EaseType @static
---@field public EaseOutQuint Interpolate.EaseType @static
---@field public EaseInOutQuint Interpolate.EaseType @static
---@field public EaseInSine Interpolate.EaseType @static
---@field public EaseOutSine Interpolate.EaseType @static
---@field public EaseInOutSine Interpolate.EaseType @static
---@field public EaseInExpo Interpolate.EaseType @static
---@field public EaseOutExpo Interpolate.EaseType @static
---@field public EaseInOutExpo Interpolate.EaseType @static
---@field public EaseInCirc Interpolate.EaseType @static
---@field public EaseOutCirc Interpolate.EaseType @static
---@field public EaseInOutCirc Interpolate.EaseType @static
---@field public value__ number
local m = {}

Interpolate.EaseType = m
return m
