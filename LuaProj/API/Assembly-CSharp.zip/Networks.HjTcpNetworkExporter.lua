---@class Networks.HjTcpNetworkExporter : System.Object
---@field public LuaCallCSharp System.Type[] @static
---@field public CSharpCallLua System.Type[] @static
local m = {}

Networks.HjTcpNetworkExporter = m
return m
