---@class ETCAxis : System.Object
---@field public name string
---@field public autoLinkTagPlayer boolean
---@field public autoTag string
---@field public player UnityEngine.GameObject
---@field public enable boolean
---@field public invertedAxis boolean
---@field public speed number
---@field public deadValue number
---@field public valueMethod ETCAxis.AxisValueMethod
---@field public curveValue UnityEngine.AnimationCurve
---@field public isEnertia boolean
---@field public inertia number
---@field public inertiaThreshold number
---@field public isAutoStab boolean
---@field public autoStabThreshold number
---@field public autoStabSpeed number
---@field public isClampRotation boolean
---@field public maxAngle number
---@field public minAngle number
---@field public isValueOverTime boolean
---@field public overTimeStep number
---@field public maxOverTimeValue number
---@field public axisValue number
---@field public axisSpeedValue number
---@field public axisThreshold number
---@field public isLockinJump boolean
---@field public axisState ETCAxis.AxisState
---@field public directAction ETCAxis.DirectAction
---@field public axisInfluenced ETCAxis.AxisInfluenced
---@field public actionOn ETCAxis.ActionOn
---@field public directCharacterController UnityEngine.CharacterController
---@field public directRigidBody UnityEngine.Rigidbody
---@field public gravity number
---@field public currentGravity number
---@field public isJump boolean
---@field public unityAxis string
---@field public showGeneralInspector boolean
---@field public showDirectInspector boolean
---@field public showInertiaInspector boolean
---@field public showSimulatinInspector boolean
---@field public directTransform UnityEngine.Transform
local m = {}

function m:InitAxis() end

---@overload fun(realValue:number, isOnDrag:boolean, type:ETCBase.ControlType)
---@param realValue number
---@param isOnDrag boolean
---@param type ETCBase.ControlType
---@param deltaTime boolean
function m:UpdateAxis(realValue, isOnDrag, type, deltaTime) end

function m:UpdateButton() end

function m:ResetAxis() end

function m:DoDirectAction() end

function m:DoGravity() end

function m:InitDeadCurve() end

ETCAxis = m
return m
