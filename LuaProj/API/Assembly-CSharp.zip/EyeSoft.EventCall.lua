---@class EyeSoft.EventCall : System.MulticastDelegate
local m = {}

---@virtual
---@param gt HedgehogTeam.EasyTouch.Gesture
---@return boolean
function m:Invoke(gt) end

---@virtual
---@param gt HedgehogTeam.EasyTouch.Gesture
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(gt, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return boolean
function m:EndInvoke(result) end

EyeSoft.EventCall = m
return m
