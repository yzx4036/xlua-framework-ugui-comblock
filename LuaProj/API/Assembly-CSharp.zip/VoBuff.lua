---@class VoBuff : System.Object
---@field public id number
---@field public sysId number
---@field public isLoop boolean
---@field public effPos EnumBindPoint
---@field public buffAttrbute EnumBuffAttribute
---@field public isNoRotate boolean
---@field public is_interrupt_skill boolean
---@field public relative_skill number
---@field public localScale number
---@field public bufWord string
---@field public isAdd boolean
---@field public bl number
local m = {}

---@param type EnumFightObjType
---@return string
function m:GetEffectId(type) end

VoBuff = m
return m
