---@class ProtoBufSerializer : Singleton_1_ProtoBufSerializer_
local m = {}

---@virtual
function m:Init() end

---@virtual
function m:Dispose() end

---@static
---@param dest System.IO.Stream
---@param instance any
function m.Serialize(dest, instance) end

---@overload fun(source:System.IO.Stream, type:System.Type):any @static
---@static
---@param source System.IO.Stream
---@param type System.Type
---@param length number
---@return any
function m.Deserialize(source, type, length) end

ProtoBufSerializer = m
return m
