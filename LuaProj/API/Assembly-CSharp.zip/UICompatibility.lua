---@class UICompatibility : UnityEngine.MonoBehaviour
local m = {}

---@param value boolean
function m:SetCompatibility(value) end

UICompatibility = m
return m
