---@class ShakeCamera : UnityEngine.MonoBehaviour
---@field public delay number
---@field public duration number
---@field public strengthValue number
---@field public strengthVector3 UnityEngine.Vector3
---@field public vibrato number
---@field public randomness number
---@field public snapping boolean
---@field public fadeOut boolean
local m = {}

ShakeCamera = m
return m
