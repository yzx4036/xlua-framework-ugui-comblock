---@class SQLite4Unity3d.IgnoreAttribute : System.Attribute
local m = {}

SQLite4Unity3d.IgnoreAttribute = m
return m
