---@class MapEditor.CityInfo : System.Object
---@field public cityId number
---@field public x number
---@field public z number
---@field public mistyList MapEditor.MistyInfo[]
local m = {}

MapEditor.CityInfo = m
return m
