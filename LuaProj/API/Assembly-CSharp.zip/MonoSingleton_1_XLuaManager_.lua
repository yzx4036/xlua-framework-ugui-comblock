---@class MonoSingleton_1_XLuaManager_ : UnityEngine.MonoBehaviour
---@field public Instance XLuaManager @static
local m = {}

function m:Startup() end

function m:DestroySelf() end

---@virtual
function m:Dispose() end

MonoSingleton_1_XLuaManager_ = m
return m
