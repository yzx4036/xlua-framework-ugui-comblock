---@class Battle.BattleRequest : System.Object
local m = {}

---@static
function m.Req() end

---@static
function m.WAR_TEST() end

---@static
---@param battleId number
---@param buId number
function m.WAR_USE_ANAGER_SKILL(battleId, buId) end

---@static
---@param battleId number
function m.WAR_SYS_QUIT_BATTLE(battleId) end

---@static
---@param battleId number
function m.WAR_START_WAR(battleId) end

---@static
---@param battleId number
---@param buIds number[]
function m.WAR_QUERY_HERO_DATA(battleId, buIds) end

---@static
---@param battleId number
function m.WARPROXY_GUIDE_UNFROZEN(battleId) end

Battle.BattleRequest = m
return m
