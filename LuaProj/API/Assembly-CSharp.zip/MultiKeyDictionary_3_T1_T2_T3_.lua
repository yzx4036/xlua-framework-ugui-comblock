---@class MultiKeyDictionary_3_T1_T2_T3_ : any
---@field public Item table<any, any>
local m = {}

---@param key1 any
---@param key2 any
---@return boolean
function m:ContainsKey(key1, key2) end

MultiKeyDictionary_3_T1_T2_T3_ = m
return m
