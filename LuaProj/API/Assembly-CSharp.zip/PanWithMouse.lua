---@class PanWithMouse : UnityEngine.MonoBehaviour
---@field public degrees UnityEngine.Vector2
---@field public range number
local m = {}

PanWithMouse = m
return m
