---@class XLua.CSObjectWrap.UnityEngineBehaviourWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineBehaviourWrap = m
return m
