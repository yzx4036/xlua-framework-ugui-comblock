---@class MapEditor.InfluenceInfo : System.Object
---@field public cityType number
---@field public gridList MapEditor.GridInfo[]
local m = {}

MapEditor.InfluenceInfo = m
return m
