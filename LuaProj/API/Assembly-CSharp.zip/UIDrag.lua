---@class UIDrag : UnityEngine.MonoBehaviour
local m = {}

UIDrag = m
return m
