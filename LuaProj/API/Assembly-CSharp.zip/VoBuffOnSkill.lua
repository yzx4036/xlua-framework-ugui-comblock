---@class VoBuffOnSkill : System.Object
---@field public buId number
---@field public bufId number
---@field public bufSysId number
---@field public happenTime number
---@field public removeBufId number
local m = {}

VoBuffOnSkill = m
return m
