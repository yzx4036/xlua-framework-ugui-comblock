---@class EnumCountry : System.Enum
---@field public wei EnumCountry @static
---@field public shu EnumCountry @static
---@field public wu EnumCountry @static
---@field public value__ number
local m = {}

EnumCountry = m
return m
