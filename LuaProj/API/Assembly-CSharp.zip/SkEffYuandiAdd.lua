---@class SkEffYuandiAdd : SkEffBase
local m = {}

SkEffYuandiAdd = m
return m
