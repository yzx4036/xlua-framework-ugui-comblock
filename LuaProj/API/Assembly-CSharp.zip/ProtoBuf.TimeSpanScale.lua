---@class ProtoBuf.TimeSpanScale : System.Enum
---@field public Days ProtoBuf.TimeSpanScale @static
---@field public Hours ProtoBuf.TimeSpanScale @static
---@field public Minutes ProtoBuf.TimeSpanScale @static
---@field public Seconds ProtoBuf.TimeSpanScale @static
---@field public Milliseconds ProtoBuf.TimeSpanScale @static
---@field public Ticks ProtoBuf.TimeSpanScale @static
---@field public MinMax ProtoBuf.TimeSpanScale @static
---@field public value__ number
local m = {}

ProtoBuf.TimeSpanScale = m
return m
