---@class NGUIMath : System.Object
local m = {}

---@static
---@param from number
---@param to number
---@param factor number
---@return number
function m.Lerp(from, to, factor) end

---@static
---@param val number
---@param max number
---@return number
function m.ClampIndex(val, max) end

---@static
---@param val number
---@param max number
---@return number
function m.RepeatIndex(val, max) end

---@static
---@param angle number
---@return number
function m.WrapAngle(angle) end

---@static
---@param val number
---@return number
function m.Wrap01(val) end

---@static
---@param ch number
---@return number
function m.HexToDecimal(ch) end

---@static
---@param num number
---@return number
function m.DecimalToHexChar(num) end

---@static
---@param num number
---@return string
function m.DecimalToHex8(num) end

---@static
---@param num number
---@return string
function m.DecimalToHex24(num) end

---@static
---@param num number
---@return string
function m.DecimalToHex32(num) end

---@static
---@param c UnityEngine.Color
---@return number
function m.ColorToInt(c) end

---@static
---@param val number
---@return UnityEngine.Color
function m.IntToColor(val) end

---@static
---@param val number
---@param bits number
---@return string
function m.IntToBinary(val, bits) end

---@static
---@param val number
---@return UnityEngine.Color
function m.HexToColor(val) end

---@static
---@param rect UnityEngine.Rect
---@param width number
---@param height number
---@return UnityEngine.Rect
function m.ConvertToTexCoords(rect, width, height) end

---@static
---@param rect UnityEngine.Rect
---@param width number
---@param height number
---@param round boolean
---@return UnityEngine.Rect
function m.ConvertToPixels(rect, width, height, round) end

---@overload fun(rect:UnityEngine.Rect, width:number, height:number):UnityEngine.Rect @static
---@static
---@param rect UnityEngine.Rect
---@return UnityEngine.Rect
function m.MakePixelPerfect(rect) end

---@static
---@param minRect UnityEngine.Vector2
---@param maxRect UnityEngine.Vector2
---@param minArea UnityEngine.Vector2
---@param maxArea UnityEngine.Vector2
---@return UnityEngine.Vector2
function m.ConstrainRect(minRect, maxRect, minArea, maxArea) end

---@static
---@param trans UnityEngine.Transform
---@return UnityEngine.Bounds
function m.CalculateAbsoluteWidgetBounds(trans) end

---@overload fun(trans:UnityEngine.Transform, considerInactive:boolean):UnityEngine.Bounds @static
---@overload fun(relativeTo:UnityEngine.Transform, content:UnityEngine.Transform):UnityEngine.Bounds @static
---@overload fun(relativeTo:UnityEngine.Transform, content:UnityEngine.Transform, considerInactive:boolean, considerChildren:boolean):UnityEngine.Bounds @static
---@overload fun(relativeTo:UnityEngine.Transform, content:UnityEngine.Transform, considerInactive:boolean):UnityEngine.Bounds @static
---@static
---@param trans UnityEngine.Transform
---@return UnityEngine.Bounds
function m.CalculateRelativeWidgetBounds(trans) end

---@overload fun(velocity:UnityEngine.Vector2, strength:number, deltaTime:number):UnityEngine.Vector2, UnityEngine.Vector2 @static
---@static
---@param velocity UnityEngine.Vector3
---@param strength number
---@param deltaTime number
---@return UnityEngine.Vector3, UnityEngine.Vector3
function m.SpringDampen(velocity, strength, deltaTime) end

---@overload fun(from:number, to:number, strength:number, deltaTime:number):number @static
---@overload fun(from:UnityEngine.Vector2, to:UnityEngine.Vector2, strength:number, deltaTime:number):UnityEngine.Vector2 @static
---@overload fun(from:UnityEngine.Vector3, to:UnityEngine.Vector3, strength:number, deltaTime:number):UnityEngine.Vector3 @static
---@overload fun(from:UnityEngine.Quaternion, to:UnityEngine.Quaternion, strength:number, deltaTime:number):UnityEngine.Quaternion @static
---@static
---@param strength number
---@param deltaTime number
---@return number
function m.SpringLerp(strength, deltaTime) end

---@static
---@param from number
---@param to number
---@param maxAngle number
---@return number
function m.RotateTowards(from, to, maxAngle) end

---@overload fun(worldPoints:UnityEngine.Vector3[], mousePos:UnityEngine.Vector2, cam:UnityEngine.Camera):number @static
---@static
---@param screenPoints UnityEngine.Vector2[]
---@param mousePos UnityEngine.Vector2
---@return number
function m.DistanceToRectangle(screenPoints, mousePos) end

---@static
---@param pv UIWidget.Pivot
---@return UnityEngine.Vector2
function m.GetPivotOffset(pv) end

---@static
---@param offset UnityEngine.Vector2
---@return UIWidget.Pivot
function m.GetPivot(offset) end

---@static
---@param w UIRect
---@param x number
---@param y number
function m.MoveWidget(w, x, y) end

---@static
---@param rect UIRect
---@param x number
---@param y number
function m.MoveRect(rect, x, y) end

---@overload fun(w:UIWidget, pivot:UIWidget.Pivot, x:number, y:number, minWidth:number, minHeight:number, maxWidth:number, maxHeight:number) @static
---@static
---@param w UIWidget
---@param pivot UIWidget.Pivot
---@param x number
---@param y number
---@param minWidth number
---@param minHeight number
function m.ResizeWidget(w, pivot, x, y, minWidth, minHeight) end

---@overload fun(w:UIWidget, left:number, bottom:number, right:number, top:number, minWidth:number, minHeight:number) @static
---@overload fun(w:UIWidget, left:number, bottom:number, right:number, top:number, minWidth:number, minHeight:number, maxWidth:number, maxHeight:number) @static
---@static
---@param w UIWidget
---@param left number
---@param bottom number
---@param right number
---@param top number
function m.AdjustWidget(w, left, bottom, right, top) end

---@static
---@param height number
---@return number
function m.AdjustByDPI(height) end

---@static
---@param pos UnityEngine.Vector2
---@param relativeTo UnityEngine.Transform
---@return UnityEngine.Vector2
function m.ScreenToPixels(pos, relativeTo) end

---@static
---@param pos UnityEngine.Vector2
---@param relativeTo UnityEngine.Transform
---@return UnityEngine.Vector2
function m.ScreenToParentPixels(pos, relativeTo) end

---@static
---@param worldPos UnityEngine.Vector3
---@param worldCam UnityEngine.Camera
---@param uiCam UnityEngine.Camera
---@param relativeTo UnityEngine.Transform
---@return UnityEngine.Vector3
function m.WorldToLocalPoint(worldPos, worldCam, uiCam, relativeTo) end

---@overload fun(trans:UnityEngine.Transform, worldPos:UnityEngine.Vector3, worldCam:UnityEngine.Camera) @static
---@overload fun(trans:UnityEngine.Transform, target:UnityEngine.Transform) @static
---@static
---@param trans UnityEngine.Transform
---@param worldPos UnityEngine.Vector3
---@param worldCam UnityEngine.Camera
---@param myCam UnityEngine.Camera
function m.OverlayPosition(trans, worldPos, worldCam, myCam) end

NGUIMath = m
return m
