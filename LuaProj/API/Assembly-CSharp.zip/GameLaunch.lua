---@class GameLaunch : UnityEngine.MonoBehaviour
---@field public bootBgRawImg UnityEngine.UI.RawImage
local m = {}

GameLaunch = m
return m
