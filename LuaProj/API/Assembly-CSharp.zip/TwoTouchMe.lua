---@class TwoTouchMe : UnityEngine.MonoBehaviour
local m = {}

TwoTouchMe = m
return m
