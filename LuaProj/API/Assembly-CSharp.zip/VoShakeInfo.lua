---@class VoShakeInfo : System.Object
---@field public time number
---@field public x number
---@field public y number
---@field public z number
local m = {}

VoShakeInfo = m
return m
