---@class FallType : System.Enum
---@field public None FallType @static
---@field public HurtNormal FallType @static
---@field public HurtSkill FallType @static
---@field public CritNormal FallType @static
---@field public CritSkill FallType @static
---@field public Mianyi FallType @static
---@field public Dodge FallType @static
---@field public Pofang FallType @static
---@field public Rebound FallType @static
---@field public Xisou FallType @static
---@field public ZhongDu FallType @static
---@field public value__ number
local m = {}

FallType = m
return m
