---@class PureSingleton_1_RunUtil_ : System.Object
---@field public Instance RunUtil @static
local m = {}

PureSingleton_1_RunUtil_ = m
return m
