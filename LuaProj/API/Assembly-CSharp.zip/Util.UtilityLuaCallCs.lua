---@class Util.UtilityLuaCallCs : System.Object
local m = {}

---@static
---@param key number
---@param module XLua.LuaTable
---@return EyeSoft.TouchLayerLua
function m.CreateTouchLayer(key, module) end

---@static
---@param layer EyeSoft.TouchLayerLua
function m.AddTouchLayer(layer) end

---@static
---@param layer EyeSoft.TouchLayerLua
function m.RemoveTouchLayer(layer) end

---@static
---@param cameraGo UnityEngine.GameObject
function m.AddCameraToEasyTouch(cameraGo) end

---@static
---@param cameraGo UnityEngine.GameObject
function m.RemoveCameraFromEasyTouch(cameraGo) end

Util.UtilityLuaCallCs = m
return m
