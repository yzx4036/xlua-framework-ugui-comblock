---@class InvDatabase : UnityEngine.MonoBehaviour
---@field public list InvDatabase[] @static
---@field public databaseID number
---@field public items InvBaseItem[]
---@field public iconAtlas UIAtlas
local m = {}

---@static
---@param id32 number
---@return InvBaseItem
function m.FindByID(id32) end

---@static
---@param exact string
---@return InvBaseItem
function m.FindByName(exact) end

---@static
---@param item InvBaseItem
---@return number
function m.FindItemID(item) end

InvDatabase = m
return m
