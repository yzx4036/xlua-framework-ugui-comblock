---@class Battle.BattleResponse : System.Object
local m = {}

---@static
function m.RegisterNetMessage() end

---@static
---@param cmd number
---@param body string
function m.ProcessNetMessage(cmd, body) end

Battle.BattleResponse = m
return m
