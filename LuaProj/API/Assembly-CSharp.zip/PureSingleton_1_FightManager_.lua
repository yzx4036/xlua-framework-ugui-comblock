---@class PureSingleton_1_FightManager_ : System.Object
---@field public Instance FightManager @static
local m = {}

PureSingleton_1_FightManager_ = m
return m
