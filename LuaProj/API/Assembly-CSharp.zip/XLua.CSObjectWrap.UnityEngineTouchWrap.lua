---@class XLua.CSObjectWrap.UnityEngineTouchWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineTouchWrap = m
return m
