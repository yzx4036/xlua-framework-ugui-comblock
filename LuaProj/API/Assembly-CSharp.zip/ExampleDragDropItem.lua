---@class ExampleDragDropItem : UIDragDropItem
---@field public prefab UnityEngine.GameObject
local m = {}

ExampleDragDropItem = m
return m
