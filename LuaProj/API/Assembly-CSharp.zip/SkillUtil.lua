---@class SkillUtil : PureSingleton_1_SkillUtil_
local m = {}

---@param data number[]
function m:dealStopSkills(data) end

---@param data com.proto.RealTimeWar[]
function m:dealHeartSkills(data) end

---@param data com.proto.RealTimeWar
function m:dealSkill(data) end

SkillUtil = m
return m
