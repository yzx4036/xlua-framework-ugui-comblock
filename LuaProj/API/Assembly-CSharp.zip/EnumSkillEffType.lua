---@class EnumSkillEffType : System.Enum
---@field public EFF_SINGLE EnumSkillEffType @static
---@field public EFF_GROUP EnumSkillEffType @static
---@field public TRAJECTORY EnumSkillEffType @static
---@field public FLY_PAOWUXIAN EnumSkillEffType @static
---@field public FLY_FORWARD EnumSkillEffType @static
---@field public ROUND_ROW EnumSkillEffType @static
---@field public ROUND_COL EnumSkillEffType @static
---@field public SHAN_DIAN_LIAN EnumSkillEffType @static
---@field public RANDOM_HIT EnumSkillEffType @static
---@field public DIAN_JI EnumSkillEffType @static
---@field public TAN_SHE EnumSkillEffType @static
---@field public YUAN_DI_ADD EnumSkillEffType @static
---@field public WANG EnumSkillEffType @static
---@field public FLY_PWX_FLOOR EnumSkillEffType @static
---@field public value__ number
local m = {}

EnumSkillEffType = m
return m
