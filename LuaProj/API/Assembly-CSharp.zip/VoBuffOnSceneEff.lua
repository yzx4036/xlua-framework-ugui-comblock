---@class VoBuffOnSceneEff : System.Object
---@field public bufId number
---@field public bufSysId number
---@field public happenTime number
---@field public pos UnityEngine.Vector2
local m = {}

VoBuffOnSceneEff = m
return m
