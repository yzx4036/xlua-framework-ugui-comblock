---@class AssetBundles.AssetAsyncLoader : AssetBundles.BaseAssetAsyncLoader
---@field public Sequence number
---@field public AssetName string
local m = {}

---@static
---@return AssetBundles.AssetAsyncLoader
function m.Get() end

---@static
---@param creater AssetBundles.AssetAsyncLoader
function m.Recycle(creater) end

---@overload fun(assetName:string, loader:AssetBundles.BaseAssetBundleAsyncLoader)
---@param assetName string
---@param asset UnityEngine.Object
function m:Init(assetName, asset) end

---@virtual
---@return boolean
function m:IsDone() end

---@virtual
---@return number
function m:Progress() end

---@virtual
function m:Update() end

---@virtual
function m:Dispose() end

AssetBundles.AssetAsyncLoader = m
return m
