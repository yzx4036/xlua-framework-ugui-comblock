---@class VoFightAddEff : System.Object
---@field public unit Entity
---@field public attEff string
---@field public bindpoint EnumBindPoint
---@field public time number
---@field public effJinxiang boolean
---@field public xOff number
---@field public yOff number
---@field public scale number
local m = {}

VoFightAddEff = m
return m
