---@class XLua.CSObjectWrap.CSAndLuaPBTestWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.CSAndLuaPBTestWrap = m
return m
