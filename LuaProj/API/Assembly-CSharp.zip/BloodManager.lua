---@class BloodManager : PureSingleton_1_BloodManager_
---@field public listHud BasicHUD[]
local m = {}

---@param figthObjType EnumFightObjType
---@return BasicHUD
function m:GetBasicHUD(figthObjType) end

---@param hud BasicHUD
function m:ReleaseBasicHUD(hud) end

BloodManager = m
return m
