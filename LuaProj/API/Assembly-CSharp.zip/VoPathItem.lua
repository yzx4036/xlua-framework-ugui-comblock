---@class VoPathItem : System.Object
---@field public bu BattleUnit
---@field public targetData VoTargetData
---@field public effstepVo VoEffStep
---@field public isDoHurt boolean
local m = {}

VoPathItem = m
return m
