---@class VoFightDeathUnit : VoFightObj
local m = {}

---@param elementId number
---@param body string
function m:Init(elementId, body) end

VoFightDeathUnit = m
return m
