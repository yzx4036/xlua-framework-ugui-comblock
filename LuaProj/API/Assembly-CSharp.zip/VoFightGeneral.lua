---@class VoFightGeneral : VoFightObj
local m = {}

VoFightGeneral = m
return m
