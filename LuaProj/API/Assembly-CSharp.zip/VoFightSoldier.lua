---@class VoFightSoldier : VoFightObj
local m = {}

VoFightSoldier = m
return m
