---@class ChangeLayer : UnityEngine.MonoBehaviour
local m = {}

ChangeLayer = m
return m
