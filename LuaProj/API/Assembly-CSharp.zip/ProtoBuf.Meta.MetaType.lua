---@class ProtoBuf.Meta.MetaType : System.Object
---@field public BaseType ProtoBuf.Meta.MetaType
---@field public IncludeSerializerMethod boolean
---@field public AsReferenceDefault boolean
---@field public HasCallbacks boolean
---@field public HasSubtypes boolean
---@field public Callbacks ProtoBuf.Meta.CallbackSet
---@field public Name string
---@field public Type System.Type
---@field public UseConstructor boolean
---@field public ConstructType System.Type
---@field public Item ProtoBuf.Meta.ValueMember
---@field public Item ProtoBuf.Meta.ValueMember
---@field public EnumPassthru boolean
---@field public IgnoreListHandling boolean
local m = {}

---@virtual
---@return string
function m:ToString() end

---@overload fun(fieldNumber:number, derivedType:System.Type, dataFormat:ProtoBuf.DataFormat):ProtoBuf.Meta.MetaType
---@param fieldNumber number
---@param derivedType System.Type
---@return ProtoBuf.Meta.MetaType
function m:AddSubType(fieldNumber, derivedType) end

---@overload fun(beforeSerialize:string, afterSerialize:string, beforeDeserialize:string, afterDeserialize:string):ProtoBuf.Meta.MetaType
---@param beforeSerialize System.Reflection.MethodInfo
---@param afterSerialize System.Reflection.MethodInfo
---@param beforeDeserialize System.Reflection.MethodInfo
---@param afterDeserialize System.Reflection.MethodInfo
---@return ProtoBuf.Meta.MetaType
function m:SetCallbacks(beforeSerialize, afterSerialize, beforeDeserialize, afterDeserialize) end

---@overload fun(factory:string):ProtoBuf.Meta.MetaType
---@param factory System.Reflection.MethodInfo
---@return ProtoBuf.Meta.MetaType
function m:SetFactory(factory) end

---@overload fun(memberName:string):ProtoBuf.Meta.MetaType
---@overload fun(memberNames:string[]):ProtoBuf.Meta.MetaType
---@overload fun():ProtoBuf.Meta.MetaType
---@overload fun(fieldNumber:number, memberName:string, defaultValue:any):ProtoBuf.Meta.MetaType
---@overload fun(fieldNumber:number, memberName:string, itemType:System.Type, defaultType:System.Type):ProtoBuf.Meta.MetaType
---@param fieldNumber number
---@param memberName string
---@return ProtoBuf.Meta.MetaType
function m:Add(fieldNumber, memberName) end

---@overload fun(fieldNumber:number, memberName:string, itemType:System.Type, defaultType:System.Type):ProtoBuf.Meta.ValueMember
---@param fieldNumber number
---@param memberName string
---@return ProtoBuf.Meta.ValueMember
function m:AddField(fieldNumber, memberName) end

---@param surrogateType System.Type
function m:SetSurrogate(surrogateType) end

---@return ProtoBuf.Meta.ValueMember[]
function m:GetFields() end

---@return ProtoBuf.Meta.SubType[]
function m:GetSubtypes() end

ProtoBuf.Meta.MetaType = m
return m
