---@class ETWindow : UnityEngine.MonoBehaviour
local m = {}

ETWindow = m
return m
