---@class FiefWrapCameraPos : UnityEngine.MonoBehaviour
---@field public width number
---@field public height number
---@field public mapAngle number
local m = {}

FiefWrapCameraPos = m
return m
