---@class ResPath : System.Object
---@field public MODEL string @static
---@field public MODEL_2D string @static
---@field public EFFECT string @static
---@field public EFFECT_LOW string @static
---@field public EFFECT_MID string @static
local m = {}

ResPath = m
return m
