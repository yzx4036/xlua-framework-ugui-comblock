---@class Singleton_1_EyeSoft_TouchManager_ : System.Object
---@field public instance EyeSoft.TouchManager @static
local m = {}

---@static
function m.Release() end

---@virtual
function m:Init() end

---@abstract
function m:Dispose() end

Singleton_1_EyeSoft_TouchManager_ = m
return m
