---@class EquipItems : UnityEngine.MonoBehaviour
---@field public itemIDs number[]
local m = {}

EquipItems = m
return m
