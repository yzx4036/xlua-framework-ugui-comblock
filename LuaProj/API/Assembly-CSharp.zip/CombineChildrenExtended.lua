---@class CombineChildrenExtended : UnityEngine.MonoBehaviour
---@field public frameToWait number
---@field public generateTriangleStrips boolean
---@field public combineOnStart boolean
---@field public destroyAfterOptimized boolean
---@field public castShadow boolean
---@field public receiveShadow boolean
---@field public keepLayer boolean
---@field public addMeshCollider boolean
local m = {}

function m:CallCombineOnAllChilds() end

function m:Combine() end

CombineChildrenExtended = m
return m
