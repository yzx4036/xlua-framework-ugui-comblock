---@class SQLite4Unity3d.BaseTableQuery : System.Object
local m = {}

SQLite4Unity3d.BaseTableQuery = m
return m
