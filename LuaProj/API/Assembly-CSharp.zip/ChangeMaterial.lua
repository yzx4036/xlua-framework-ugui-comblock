---@class ChangeMaterial : System.Object
local m = {}

---@static
---@param targetRend UnityEngine.Renderer
---@param targetMat UnityEngine.Material
---@param _type BattleMatType
function m.ChangeMat(targetRend, targetMat, _type) end

ChangeMaterial = m
return m
