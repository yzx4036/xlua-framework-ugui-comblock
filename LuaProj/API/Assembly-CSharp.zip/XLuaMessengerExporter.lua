---@class XLuaMessengerExporter : System.Object
---@field public LuaCallCSharp System.Type[] @static
---@field public CSharpCallLua1 System.Type[] @static
---@field public CSharpCallLua2 System.Type[] @static
local m = {}

XLuaMessengerExporter = m
return m
