---@class ProtoBuf.ProtoAfterSerializationAttribute : System.Attribute
local m = {}

ProtoBuf.ProtoAfterSerializationAttribute = m
return m
