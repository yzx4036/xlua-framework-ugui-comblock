---@class UIGrid : UIWidgetContainer
---@field public arrangement UIGrid.Arrangement
---@field public sorting UIGrid.Sorting
---@field public pivot UIWidget.Pivot
---@field public maxPerLine number
---@field public cellWidth number
---@field public cellHeight number
---@field public animateSmoothly boolean
---@field public hideInactive boolean
---@field public keepWithinPanel boolean
---@field public onReposition fun()
---@field public onCustomSort fun(x:UnityEngine.Transform, y:UnityEngine.Transform):number
---@field public repositionNow boolean
local m = {}

---@return UnityEngine.Transform[]
function m:GetChildList() end

---@param index number
---@return UnityEngine.Transform
function m:GetChild(index) end

---@param trans UnityEngine.Transform
---@return number
function m:GetIndex(trans) end

---@overload fun(trans:UnityEngine.Transform, sort:boolean)
---@param trans UnityEngine.Transform
function m:AddChild(trans) end

---@param t UnityEngine.Transform
---@return boolean
function m:RemoveChild(t) end

---@static
---@param a UnityEngine.Transform
---@param b UnityEngine.Transform
---@return number
function m.SortByNumber_A(a, b) end

---@static
---@param a UnityEngine.Transform
---@param b UnityEngine.Transform
---@return number
function m.SortByNumber_D(a, b) end

---@static
---@param a UnityEngine.Transform
---@param b UnityEngine.Transform
---@return number
function m.SortByName(a, b) end

---@static
---@param a UnityEngine.Transform
---@param b UnityEngine.Transform
---@return number
function m.SortHorizontal(a, b) end

---@static
---@param a UnityEngine.Transform
---@param b UnityEngine.Transform
---@return number
function m.SortVertical(a, b) end

---@virtual
function m:Reposition() end

function m:ConstrainWithinPanel() end

UIGrid = m
return m
