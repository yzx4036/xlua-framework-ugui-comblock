---@class BMSymbol : System.Object
---@field public sequence string
---@field public spriteName string
---@field public length number
---@field public offsetX number
---@field public offsetY number
---@field public width number
---@field public height number
---@field public advance number
---@field public uvRect UnityEngine.Rect
local m = {}

function m:MarkAsChanged() end

---@param atlas UIAtlas
---@return boolean
function m:Validate(atlas) end

BMSymbol = m
return m
