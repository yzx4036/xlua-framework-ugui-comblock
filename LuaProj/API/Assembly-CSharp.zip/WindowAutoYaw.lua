---@class WindowAutoYaw : UnityEngine.MonoBehaviour
---@field public updateOrder number
---@field public uiCamera UnityEngine.Camera
---@field public yawAmount number
local m = {}

WindowAutoYaw = m
return m
