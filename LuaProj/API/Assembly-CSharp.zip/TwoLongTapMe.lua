---@class TwoLongTapMe : UnityEngine.MonoBehaviour
local m = {}

TwoLongTapMe = m
return m
