---@class MapEditor.InfluenceAssist : UnityEngine.MonoBehaviour
---@field public color UnityEngine.Color
local m = {}

---@overload fun(go:UnityEngine.GameObject)
function m:ApplyColor() end

---@param go UnityEngine.GameObject
function m:RevertColor(go) end

function m:CreateCSharpFile() end

MapEditor.InfluenceAssist = m
return m
