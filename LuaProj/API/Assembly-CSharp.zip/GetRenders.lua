---@class GetRenders : UnityEngine.MonoBehaviour
local m = {}

GetRenders = m
return m
