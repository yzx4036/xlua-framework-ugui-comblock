---@class FightEnumUtil : System.Object
local m = {}

---@static
---@param type EnumFightObjType
---@return boolean
function m.isZhuJiang(type) end

---@static
---@param type EnumFightObjType
---@return boolean
function m.hasAction(type) end

---@static
---@param type number
---@return boolean
function m.isPlotFight(type) end

FightEnumUtil = m
return m
