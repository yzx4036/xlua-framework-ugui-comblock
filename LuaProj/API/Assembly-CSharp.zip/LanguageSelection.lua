---@class LanguageSelection : UnityEngine.MonoBehaviour
local m = {}

function m:Refresh() end

LanguageSelection = m
return m
