---@class SkillInfoManager : System.Object
local m = {}

---@static
---@return SkillInfoManager
function m.getInstance() end

---@static
---@param skillName string
---@return VoSkillArt
function m.getVoSkill(skillName) end

SkillInfoManager = m
return m
