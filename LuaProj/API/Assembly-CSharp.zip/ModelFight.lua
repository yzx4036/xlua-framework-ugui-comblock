---@class ModelFight : PureSingleton_1_ModelFight_
---@field public MAP_W number @static
---@field public MAP_H number @static
---@field public CENTER_X number @static
---@field public CENTER_Y number @static
---@field public GRID_SIZE_X number @static
---@field public GRID_SIZE_Y number @static
---@field public isShowUnitId boolean
---@field public isShowGrid boolean
---@field public isShowHorse boolean
---@field public isShowHpbar boolean
---@field public isShowFlyword boolean
---@field public isShowFiveEle boolean
---@field public isShowBufEff boolean
---@field public isShowBufMat boolean
---@field public isShowSkillAttack boolean
---@field public isShowSkillWorld boolean
---@field public isPloting boolean
---@field public guideId number
---@field public isEnterScene boolean
---@field public fightId number
---@field public fightType number
---@field public fightPlayMode number
---@field public isMoni boolean
---@field public terrainId number
---@field public cityId number
---@field public breakskill number
---@field public isPlayJiPo boolean
---@field public continueTime number
---@field public isMedia boolean
---@field public isFighting boolean
local m = {}

function m:ShowMap() end

function m:GetHeroData() end

---@return table<number, BattleUnit>
function m:GetBuDic() end

---@return number
function m:GetListCount() end

function m:PreLoadBuSkill() end

---@param id number
---@param magic MagicInBattle
function m:AddSceneMagic(id, magic) end

---@param id number
function m:RemoveSceneMagic(id) end

---@param gridX number
---@param gridZ number
---@param bu BattleUnit
function m:AddGridBu(gridX, gridZ, bu) end

---@param unit BattleUnit
function m:AddUnit(unit) end

---@param id number
function m:removeUnitById(id) end

---@param id number
---@param unit BattleUnit
function m:RemoveUnit(id, unit) end

---@param id number
---@return BattleUnit
function m:GetUnit(id) end

---@param sysId number
---@param direct EnumFightDirect
---@return BattleUnit
function m:getBuBySysId(sysId, direct) end

---@param attr EnumBuffAttribute
---@param direct EnumFightDirect
---@return BattleUnit
function m:GetBuByBufAttr(attr, direct) end

function m:ReSetBuAngle() end

---@return UnityEngine.Vector2
function m:GetBuCenterPos() end

---@param sysId number
---@return BattleUnit
function m:getGeneralBySysId(sysId) end

---@param orderId number
---@param direct EnumFightDirect
---@return BattleUnit
function m:getGeneralByOrderId(orderId, direct) end

---@param magic MagicInBattle
function m:addMagic(magic) end

---@param magic MagicInBattle
function m:removeMagic(magic) end

---@param value boolean
function m:showHideAll(value) end

---@param noStopBuIds number[]
---@param targetIds number[]
---@param showHpBar boolean
function m:setLayer(noStopBuIds, targetIds, showHpBar) end

---@param guid number
---@param relateId number
function m:AddTimeOut(guid, relateId) end

function m:ClearTimer() end

---@param now number
function m:checkTimer(now) end

---@param tw Holoville.HOTween.Tweener
---@param relateBuId number
function m:AddTweener(tw, relateBuId) end

function m:ClearTweener() end

---@param now number
function m:checkTweenner(now) end

---@param _dt number
function m:Update(_dt) end

---@return boolean
function m:GetIsPause() end

---@param time number
---@param noStopBuIds number[]
function m:PauseEff(time, noStopBuIds) end

function m:resetData() end

function m:Dispose() end

ModelFight = m
return m
