---@class UIPinch : UnityEngine.MonoBehaviour
local m = {}

function m:OnEnable() end

function m:OnDestroy() end

UIPinch = m
return m
