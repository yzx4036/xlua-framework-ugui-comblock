---@class Interpolate.Function : System.MulticastDelegate
local m = {}

---@virtual
---@param a number
---@param b number
---@param c number
---@param d number
---@return number
function m:Invoke(a, b, c, d) end

---@virtual
---@param a number
---@param b number
---@param c number
---@param d number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(a, b, c, d, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return number
function m:EndInvoke(result) end

Interpolate.Function = m
return m
