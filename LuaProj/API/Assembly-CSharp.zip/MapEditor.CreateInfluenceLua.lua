---@class MapEditor.CreateInfluenceLua : System.Object
local m = {}

---@static
---@param parentTf UnityEngine.Transform
function m.CreateTxtFile(parentTf) end

---@static
---@param parentTf UnityEngine.Transform
function m.CreateLuaFile(parentTf) end

MapEditor.CreateInfluenceLua = m
return m
