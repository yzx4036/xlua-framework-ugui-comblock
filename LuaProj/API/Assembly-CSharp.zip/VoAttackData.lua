---@class VoAttackData : System.Object
---@field public id number
---@field public hp number
---@field public angry number
---@field public isOffSet number
---@field public toPosX number
---@field public toPosY number
---@field public way number
local m = {}

VoAttackData = m
return m
