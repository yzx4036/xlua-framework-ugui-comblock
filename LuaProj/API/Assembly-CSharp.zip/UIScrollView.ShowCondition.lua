---@class UIScrollView.ShowCondition : System.Enum
---@field public Always UIScrollView.ShowCondition @static
---@field public OnlyIfNeeded UIScrollView.ShowCondition @static
---@field public WhenDragging UIScrollView.ShowCondition @static
---@field public value__ number
local m = {}

UIScrollView.ShowCondition = m
return m
