---@class URLSetting : System.Object
---@field public START_UP_URL string @static
---@field public SERVER_RESOURCE_URL string @static
---@field public APP_DOWNLOAD_URL string @static
---@field public LOGIN_URL string @static
---@field public REPORT_ERROR_URL string @static
---@field public SERVER_LIST_URL string @static
---@field public NOTICE_URL string @static
local m = {}

URLSetting = m
return m
