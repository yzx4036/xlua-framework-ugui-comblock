---@class Networks.MessageQueue : System.Object
local m = {}

---@virtual
---@param o string
function m:Add(o) end

---@virtual
---@param bytesList string[]
function m:MoveTo(bytesList) end

---@virtual
---@return boolean
function m:Empty() end

---@virtual
function m:Dispose() end

Networks.MessageQueue = m
return m
