---@class VoFightZhaoHuan : VoFightObj
---@field public effId string
local m = {}

---@param data com.proto.SceneCombatUnit
function m:Init(data) end

VoFightZhaoHuan = m
return m
