---@class BindPointUtil : System.Object
---@field public HEAD string @static
---@field public HIT string @static
---@field public HAND_RIGHT string @static
---@field public HAND_LEFT string @static
---@field public MA_AN string @static
---@field public WEAPON_RIGHT string @static
---@field public WEAPON_LEFT string @static
---@field public EFF1 string @static
---@field public EFF2 string @static
---@field public EFF3 string @static
---@field public WALL_HIT string @static
local m = {}

---@static
---@param type string
---@return EnumBindPoint
function m.GetEnumBindPoint(type) end

BindPointUtil = m
return m
