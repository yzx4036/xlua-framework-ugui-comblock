---@class CustomDataStruct.IDelegateBase : table
local m = {}

---@abstract
function m:Release() end

---@abstract
function m:Cleanup() end

CustomDataStruct.IDelegateBase = m
return m
