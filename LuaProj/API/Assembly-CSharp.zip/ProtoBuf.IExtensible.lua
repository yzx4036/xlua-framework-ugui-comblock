---@class ProtoBuf.IExtensible : table
local m = {}

---@abstract
---@param createIfMissing boolean
---@return ProtoBuf.IExtension
function m:GetExtensionObject(createIfMissing) end

ProtoBuf.IExtensible = m
return m
