---@class XLua.CSObjectWrap.UnityEngineTextAssetWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineTextAssetWrap = m
return m
