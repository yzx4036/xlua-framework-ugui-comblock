---@class SQLite4Unity3d.PrimaryKeyAttribute : System.Attribute
local m = {}

SQLite4Unity3d.PrimaryKeyAttribute = m
return m
