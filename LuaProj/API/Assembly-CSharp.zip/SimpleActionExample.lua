---@class SimpleActionExample : UnityEngine.MonoBehaviour
local m = {}

---@param gesture HedgehogTeam.EasyTouch.Gesture
function m:ChangeColor(gesture) end

---@param gesture HedgehogTeam.EasyTouch.Gesture
function m:TimePressed(gesture) end

---@param gesture HedgehogTeam.EasyTouch.Gesture
function m:DisplaySwipeAngle(gesture) end

---@param text string
function m:ChangeText(text) end

function m:ResetScale() end

SimpleActionExample = m
return m
