---@class UIButtonColor : UIWidgetContainer
---@field public tweenTarget UnityEngine.GameObject
---@field public hover UnityEngine.Color
---@field public pressed UnityEngine.Color
---@field public disabledColor UnityEngine.Color
---@field public duration number
---@field public state UIButtonColor.State
---@field public defaultColor UnityEngine.Color
---@field public isEnabled boolean
local m = {}

function m:ResetDefaultColor() end

function m:CacheDefaultColor() end

---@virtual
---@param state UIButtonColor.State
---@param instant boolean
function m:SetState(state, instant) end

---@virtual
---@param instant boolean
function m:UpdateColor(instant) end

UIButtonColor = m
return m
