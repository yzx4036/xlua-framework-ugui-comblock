---@class VoFightWallJianta : VoFightObj
---@field public towerHeight number
local m = {}

---@param data com.proto.SceneCombatUnit
---@param towerHeight number
function m:Init(data, towerHeight) end

VoFightWallJianta = m
return m
