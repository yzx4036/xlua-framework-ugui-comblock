---@class XLua.HotfixFlag : System.Enum
---@field public Stateless XLua.HotfixFlag @static
---@field public Stateful XLua.HotfixFlag @static
---@field public ValueTypeBoxing XLua.HotfixFlag @static
---@field public IgnoreProperty XLua.HotfixFlag @static
---@field public IgnoreNotPublic XLua.HotfixFlag @static
---@field public Inline XLua.HotfixFlag @static
---@field public IntKey XLua.HotfixFlag @static
---@field public AdaptByDelegate XLua.HotfixFlag @static
---@field public IgnoreCompilerGenerated XLua.HotfixFlag @static
---@field public NoBaseProxy XLua.HotfixFlag @static
---@field public value__ number
local m = {}

XLua.HotfixFlag = m
return m
