---@class EnvelopContent : UnityEngine.MonoBehaviour
---@field public targetRoot UnityEngine.Transform
---@field public padLeft number
---@field public padRight number
---@field public padBottom number
---@field public padTop number
local m = {}

function m:Execute() end

EnvelopContent = m
return m
