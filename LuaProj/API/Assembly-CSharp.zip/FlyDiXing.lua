---@class FlyDiXing : FlyWordBase
local m = {}

---@param dingXing number
---@param flag number
---@param value number
function m:InitWord(dingXing, flag, value) end

FlyDiXing = m
return m
