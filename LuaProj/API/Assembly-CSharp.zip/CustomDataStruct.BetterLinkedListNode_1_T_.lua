---@class CustomDataStruct.BetterLinkedListNode_1_T_ : System.Object
---@field public List any
---@field public Next CustomDataStruct.BetterLinkedListNode_1_T_
---@field public Previous CustomDataStruct.BetterLinkedListNode_1_T_
---@field public Value any
---@field public Node any
local m = {}

---@static
---@return CustomDataStruct.BetterLinkedListNode_1_T_
function m.Get() end

---@virtual
function m:Release() end

---@param list any
---@param value any
function m:InitInfo(list, value) end

CustomDataStruct.BetterLinkedListNode_1_T_ = m
return m
