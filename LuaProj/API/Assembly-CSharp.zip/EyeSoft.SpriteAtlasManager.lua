---@class EyeSoft.SpriteAtlasManager : MonoSingleton_1_EyeSoft_SpriteAtlasManager_
local m = {}

---@return System.Collections.IEnumerator
function m:Reset() end

---@param name string
---@return UnityEngine.U2D.SpriteAtlas
function m:GetSpriteAtlas(name) end

---@virtual
function m:Dispose() end

EyeSoft.SpriteAtlasManager = m
return m
