---@class VoTimeOut : System.Object
---@field public relateBuId number
---@field public guid number
---@field public beginTime number
---@field public recyleTime number
local m = {}

---@param now number
---@return boolean
function m:isTimeOut(now) end

---@param addTime number
function m:addRecyleTime(addTime) end

VoTimeOut = m
return m
