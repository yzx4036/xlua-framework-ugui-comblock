---@class ProtoBuf.Serializers.ICustomProtoSerializer : table
local m = {}

---@abstract
---@param target any
---@param value any
---@param fieldNumber number
function m:SetValue(target, value, fieldNumber) end

---@abstract
---@param target any
---@param fieldNumber number
---@return any
function m:GetValue(target, fieldNumber) end

ProtoBuf.Serializers.ICustomProtoSerializer = m
return m
