---@class SQLite4Unity3d.SQLiteConnectionString : System.Object
---@field public ConnectionString string
---@field public DatabasePath string
---@field public StoreDateTimeAsTicks boolean
local m = {}

SQLite4Unity3d.SQLiteConnectionString = m
return m
