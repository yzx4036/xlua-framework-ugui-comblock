---@class EyeSoft.ITouchEntity : table
local m = {}

---@abstract
function m:DoTouch() end

EyeSoft.ITouchEntity = m
return m
