---@class PureSingleton_1_BuffUtil_ : System.Object
---@field public Instance BuffUtil @static
local m = {}

PureSingleton_1_BuffUtil_ = m
return m
