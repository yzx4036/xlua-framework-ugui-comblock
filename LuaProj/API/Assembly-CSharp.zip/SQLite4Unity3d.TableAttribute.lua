---@class SQLite4Unity3d.TableAttribute : System.Attribute
---@field public Name string
local m = {}

SQLite4Unity3d.TableAttribute = m
return m
