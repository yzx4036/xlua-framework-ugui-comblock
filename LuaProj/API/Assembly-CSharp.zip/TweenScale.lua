---@class TweenScale : UITweener
---@field public from UnityEngine.Vector3
---@field public to UnityEngine.Vector3
---@field public updateTable boolean
---@field public cachedTransform UnityEngine.Transform
---@field public value UnityEngine.Vector3
---@field public scale UnityEngine.Vector3
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param scale UnityEngine.Vector3
---@return TweenScale
function m.Begin(go, duration, scale) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenScale = m
return m
