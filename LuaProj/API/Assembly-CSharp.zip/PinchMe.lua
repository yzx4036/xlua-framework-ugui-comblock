---@class PinchMe : UnityEngine.MonoBehaviour
local m = {}

PinchMe = m
return m
