---@class DelayShowChild : UnityEngine.MonoBehaviour
---@field public DelayTime number
local m = {}

DelayShowChild = m
return m
