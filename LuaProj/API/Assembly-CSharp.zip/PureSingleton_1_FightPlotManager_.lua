---@class PureSingleton_1_FightPlotManager_ : System.Object
---@field public Instance FightPlotManager @static
local m = {}

PureSingleton_1_FightPlotManager_ = m
return m
