---@class TweenAlpha : UITweener
---@field public from number
---@field public to number
---@field public alpha number
---@field public value number
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param alpha number
---@return TweenAlpha
function m.Begin(go, duration, alpha) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenAlpha = m
return m
