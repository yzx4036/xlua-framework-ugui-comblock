---@class AssetbundleUpdater : UnityEngine.MonoBehaviour
local m = {}

function m:TestHotfix() end

function m:StartCheckUpdate() end

AssetbundleUpdater = m
return m
