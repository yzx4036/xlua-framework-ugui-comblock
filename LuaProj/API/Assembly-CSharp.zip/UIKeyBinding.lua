---@class UIKeyBinding : UnityEngine.MonoBehaviour
---@field public keyCode UnityEngine.KeyCode
---@field public modifier UIKeyBinding.Modifier
---@field public action UIKeyBinding.Action
---@field public captionText string
local m = {}

---@static
---@param key UnityEngine.KeyCode
---@return boolean
function m.IsBound(key) end

---@virtual
---@return string
function m:ToString() end

---@static
---@param text string
---@return boolean, UnityEngine.KeyCode, UIKeyBinding.Modifier
function m.GetKeyCode(text) end

UIKeyBinding = m
return m
