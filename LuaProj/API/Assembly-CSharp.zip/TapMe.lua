---@class TapMe : UnityEngine.MonoBehaviour
local m = {}

TapMe = m
return m
