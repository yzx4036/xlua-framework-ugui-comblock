---@class DrawLineUtil : UnityEngine.MonoBehaviour
local m = {}

---@static
---@param pos UnityEngine.Vector3[]
---@param color UnityEngine.Color
---@return UnityEngine.GameObject
function m.BeginDraw(pos, color) end

function m:OnRenderObject() end

DrawLineUtil = m
return m
