---@class LoadExamples : UnityEngine.MonoBehaviour
local m = {}

---@param level string
function m:LoadExample(level) end

LoadExamples = m
return m
