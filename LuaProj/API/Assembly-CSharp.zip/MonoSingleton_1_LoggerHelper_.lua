---@class MonoSingleton_1_LoggerHelper_ : UnityEngine.MonoBehaviour
---@field public Instance LoggerHelper @static
local m = {}

function m:Startup() end

function m:DestroySelf() end

---@virtual
function m:Dispose() end

MonoSingleton_1_LoggerHelper_ = m
return m
