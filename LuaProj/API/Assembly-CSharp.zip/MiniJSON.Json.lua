---@class MiniJSON.Json : System.Object
local m = {}

---@static
---@param json string
---@return any
function m.Deserialize(json) end

---@static
---@param obj any
---@return string
function m.Serialize(obj) end

MiniJSON.Json = m
return m
