---@class AssetBundles.AssetBundleConfig : System.Object
---@field public localSvrAppPath string @static
---@field public AssetBundlesFolderName string @static
---@field public AssetBundleSuffix string @static
---@field public AssetsFolderName string @static
---@field public ChannelFolderName string @static
---@field public AssetsPathMapFileName string @static
---@field public VariantsMapFileName string @static
---@field public AssetBundleServerUrlFileName string @static
---@field public VariantMapParttren string @static
---@field public CommonMapPattren string @static
---@field public AtlasRoot string @static
---@field public AssetBundlesBuildOutputPath string @static
---@field public LocalSvrAppPath string @static
---@field public LocalSvrAppWorkPath string @static
---@field public IsEditorMode boolean @static
---@field public IsSimulateMode boolean @static
local m = {}

AssetBundles.AssetBundleConfig = m
return m
