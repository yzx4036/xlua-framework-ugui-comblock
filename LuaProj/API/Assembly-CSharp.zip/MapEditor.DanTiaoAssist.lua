---@class MapEditor.DanTiaoAssist : MapEditor.ElementBaseAssist
local m = {}

MapEditor.DanTiaoAssist = m
return m
