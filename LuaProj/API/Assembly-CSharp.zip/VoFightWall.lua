---@class VoFightWall : VoFightObj
local m = {}

---@param data com.proto.SceneCombatUnit
---@param wallbody string
function m:Init(data, wallbody) end

VoFightWall = m
return m
