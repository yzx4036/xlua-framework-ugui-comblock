---@class ProtoBuf.ProtoPartialMemberAttribute : ProtoBuf.ProtoMemberAttribute
---@field public MemberName string
local m = {}

ProtoBuf.ProtoPartialMemberAttribute = m
return m
