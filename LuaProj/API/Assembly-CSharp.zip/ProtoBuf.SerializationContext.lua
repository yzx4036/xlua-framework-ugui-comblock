---@class ProtoBuf.SerializationContext : System.Object
---@field public Context any
local m = {}

ProtoBuf.SerializationContext = m
return m
