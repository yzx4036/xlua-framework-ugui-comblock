---@class SkEffGroup : SkEffBase
local m = {}

SkEffGroup = m
return m
