---@class battle.one_cmd : System.Object
---@field public cmd_id number
---@field public UID number
---@field public cmd_data string
local m = {}

battle.one_cmd = m
return m
