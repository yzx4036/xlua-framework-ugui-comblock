---@class ProtoBuf.ProtoPartialIgnoreAttribute : ProtoBuf.ProtoIgnoreAttribute
---@field public MemberName string
local m = {}

ProtoBuf.ProtoPartialIgnoreAttribute = m
return m
