---@class SimpleHttp : UnityEngine.MonoBehaviour
---@field public newInstance SimpleHttp @static
local m = {}

---@overload fun(url:string, formData:System.Collections.Generic.Dictionary_2_System_String_System_String_, byteData:string, callback:(fun(obj:UnityEngine.WWW))) @static
---@static
---@param url string
---@param formData System.Collections.Generic.Dictionary_2_System_String_System_String_
---@param byteData string
---@param callback fun(obj:UnityEngine.WWW)
---@param timeOut number
function m.HttpGet(url, formData, byteData, callback, timeOut) end

---@overload fun(url:string, formData:System.Collections.Generic.Dictionary_2_System_String_System_String_, byteData:string, callback:(fun(obj:UnityEngine.WWW))) @static
---@static
---@param url string
---@param formData System.Collections.Generic.Dictionary_2_System_String_System_String_
---@param byteData string
---@param callback fun(obj:UnityEngine.WWW)
---@param timeOut number
function m.HttpPost(url, formData, byteData, callback, timeOut) end

---@param info HttpInfo
function m:StartHttp(info) end

SimpleHttp = m
return m
