---@class EyeSoft.Utility.UtilityByteConveter : System.Object
local m = {}

---@static
---@param obj any
---@return string
function m.Object2Bytes(obj) end

---@static
---@param buff string
---@return any
function m.Bytes2Object(buff) end

EyeSoft.Utility.UtilityByteConveter = m
return m
