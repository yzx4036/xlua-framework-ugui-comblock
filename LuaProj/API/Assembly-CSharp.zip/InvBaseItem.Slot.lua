---@class InvBaseItem.Slot : System.Enum
---@field public None InvBaseItem.Slot @static
---@field public Weapon InvBaseItem.Slot @static
---@field public Shield InvBaseItem.Slot @static
---@field public Body InvBaseItem.Slot @static
---@field public Shoulders InvBaseItem.Slot @static
---@field public Bracers InvBaseItem.Slot @static
---@field public Boots InvBaseItem.Slot @static
---@field public Trinket InvBaseItem.Slot @static
---@field public _LastDoNotUse InvBaseItem.Slot @static
---@field public value__ number
local m = {}

InvBaseItem.Slot = m
return m
