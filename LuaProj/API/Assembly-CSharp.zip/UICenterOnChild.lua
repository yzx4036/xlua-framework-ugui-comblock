---@class UICenterOnChild : UnityEngine.MonoBehaviour
---@field public springStrength number
---@field public nextPageThreshold number
---@field public onFinished fun()
---@field public onCenter fun(centeredObject:UnityEngine.GameObject)
---@field public centeredObject UnityEngine.GameObject
local m = {}

function m:Recenter() end

---@param target UnityEngine.Transform
function m:CenterOn(target) end

UICenterOnChild = m
return m
