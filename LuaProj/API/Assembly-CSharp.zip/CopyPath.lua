---@class CopyPath : UnityEditor.EditorWindow
local m = {}

---@static
function m.CopyGameObjectPath() end

---@static
function m.LogUnStaticGameObjectName() end

---@static
---@param obj UnityEngine.GameObject
---@return string
function m.GetGameObjectPath(obj) end

CopyPath = m
return m
