---@class LoadFightRes : System.Object
local m = {}

---@static
---@param assetName string
---@return UnityEngine.Object
function m.LoadAsset(assetName) end

---@static
---@param assetName string
---@param OnLoadedCallback fun(name:string, asset:UnityEngine.Object)
function m.LoadAsync(assetName, OnLoadedCallback) end

---@static
function m.Release() end

LoadFightRes = m
return m
