---@class VoSkillEdit : UnityEngine.MonoBehaviour
---@field public attBodyPrefeb UnityEngine.GameObject
---@field public attWeaponPrefeb UnityEngine.GameObject
---@field public attWeapon2Prefeb UnityEngine.GameObject
---@field public attHorsePrefeb UnityEngine.GameObject
---@field public hurtBodyPrefeb UnityEngine.GameObject
---@field public hurtWeaponPrefeb UnityEngine.GameObject
---@field public hurtHorsePrefeb UnityEngine.GameObject
---@field public attEffPrefeb UnityEngine.GameObject
---@field public attEff2Prefeb UnityEngine.GameObject
---@field public hurtEffPrefeb UnityEngine.GameObject
---@field public worldEffPrefeb UnityEngine.GameObject
---@field public worldEffPrefeb2 UnityEngine.GameObject
---@field public worldEffPrefeb3 UnityEngine.GameObject
---@field public id string
---@field public attbodyModel string
---@field public attweaponModel string
---@field public attweapon2Model string
---@field public attHorseModel string
---@field public attAction EnumAction
---@field public attEff string
---@field public attEffScale number
---@field public attEffBeginTime number
---@field public attEffUseTime number
---@field public attEffBP EnumBindPoint
---@field public attEff2 string
---@field public attEffScale2 number
---@field public attEffBeginTime2 number
---@field public attEffUseTime2 number
---@field public attEffBP2 EnumBindPoint
---@field public moveType number
---@field public moveUseTime number
---@field public moveBeginTime number
---@field public hurtBodyModel string
---@field public hurtWeaponModel string
---@field public hurtHorseModel string
---@field public hurtEff string
---@field public hurtEffScale number
---@field public hurtBeginTime number
---@field public hurtUseTime number
---@field public hurtDelayTime string
---@field public worldEff string
---@field public worldEff2 string
---@field public worldEff3 string
---@field public effInDoing string
---@field public hurtNum number
---@field public hurtPosX number
---@field public hurtPosZ number
---@field public hurtPosAdjustX number
---@field public hurtPosAdjustZ number
local m = {}

---@param name string
---@return string
function m:getString(name) end

---@param content string
---@return string
function m:ParseString(content) end

VoSkillEdit = m
return m
