---@class Logger : System.Object
---@field public clientVerstion string @static
---@field public loginUid string @static
---@field public localIP string @static
---@field public platName string @static
---@field public sceneName string @static
---@field public DEBUG_BUILD_VER string @static
---@field public platChannel string @static
---@field public useTime number @static
---@field public useMemory string @static
local m = {}

---@overload fun(s:string) @static
---@overload fun(o:any) @static
---@static
---@param s string
---@param p any[]|any
function m.Log(s, p) end

---@overload fun(color:UnityEngine.Color, s:string) @static
---@static
---@param color UnityEngine.Color
---@param s string
---@param p any[]|any
function m.LogColor(color, s, p) end

---@overload fun(s:string) @static
---@static
---@param s string
---@param p any[]|any
function m.LogToMainThread(s, p) end

---@overload fun(condition:boolean, s:string) @static
---@static
---@param condition boolean
---@param s string
---@param p any[]|any
function m.Assert(condition, s, p) end

---@overload fun(s:string) @static
---@static
---@param s string
---@param p any[]|any
function m.LogError(s, p) end

---@overload fun(s:string) @static
---@static
---@param s string
---@param p any[]|any
function m.LogErrorToMainThread(s, p) end

---@static
---@param str string
function m.LogStackTrace(str) end

---@static
function m.CheckReportError() end

---@static
function m.Watch() end

Logger = m
return m
