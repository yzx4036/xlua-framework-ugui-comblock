---@class EyeSoft.Utility.UtilityCSCallLua : System.Object
local m = {}

---@static
---@param pWindowName string
---@return boolean
function m.IsUIWindowShow(pWindowName) end

---@overload fun(pWindowName:string):boolean @static
---@static
---@param pWindowName string
---@param args any[]|any
---@return boolean
function m.ShowUIWindow(pWindowName, args) end

---@static
---@param pWindowName string
---@return boolean
function m.CloseUIWindow(pWindowName) end

---@static
---@param pSceneName string
---@return boolean
function m.PassiveSwitchLuaScene(pSceneName) end

---@static
---@param pSceneName string
---@return boolean
function m.SwitchLuaScene(pSceneName) end

EyeSoft.Utility.UtilityCSCallLua = m
return m
