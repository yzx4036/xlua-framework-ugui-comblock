---@class EnumFightDeathType : System.Enum
---@field public play_death EnumFightDeathType @static
---@field public fire EnumFightDeathType @static
---@field public black EnumFightDeathType @static
---@field public value__ number
local m = {}

EnumFightDeathType = m
return m
