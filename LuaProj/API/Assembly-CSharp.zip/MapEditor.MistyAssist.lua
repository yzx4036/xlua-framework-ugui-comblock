---@class MapEditor.MistyAssist : UnityEngine.MonoBehaviour
---@field public fileName string
local m = {}

function m:Save() end

---@param info MapEditor.ElementBaseAssist[]
---@return table<number, MapEditor.GridInfo>
function m:ToElementInfo(info) end

MapEditor.MistyAssist = m
return m
