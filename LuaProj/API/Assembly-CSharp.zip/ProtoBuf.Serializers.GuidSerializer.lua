---@class ProtoBuf.Serializers.GuidSerializer : System.Object
---@field public ExpectedType System.Type
local m = {}

---@virtual
---@param value any
---@param dest ProtoBuf.ProtoWriter
function m:Write(value, dest) end

---@virtual
---@param value any
---@param source ProtoBuf.ProtoReader
---@return any
function m:Read(value, source) end

ProtoBuf.Serializers.GuidSerializer = m
return m
