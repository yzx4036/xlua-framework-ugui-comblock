---@class XLua.CSObjectWrap.UnityEngineAnimationClipWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineAnimationClipWrap = m
return m
