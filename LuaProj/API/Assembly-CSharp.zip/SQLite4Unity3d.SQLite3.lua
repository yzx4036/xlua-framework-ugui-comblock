---@class SQLite4Unity3d.SQLite3 : System.Object
local m = {}

---@overload fun(filename:string, flags:number, zvfs:System.IntPtr):SQLite4Unity3d.SQLite3.Result, System.IntPtr @static
---@overload fun(filename:string, flags:number, zvfs:System.IntPtr):SQLite4Unity3d.SQLite3.Result, System.IntPtr @static
---@static
---@param filename string
---@return SQLite4Unity3d.SQLite3.Result, System.IntPtr
function m.Open(filename) end

---@static
---@param filename string
---@return SQLite4Unity3d.SQLite3.Result, System.IntPtr
function m.Open16(filename) end

---@static
---@param db System.IntPtr
---@param onoff number
---@return SQLite4Unity3d.SQLite3.Result
function m.EnableLoadExtension(db, onoff) end

---@static
---@param db System.IntPtr
---@return SQLite4Unity3d.SQLite3.Result
function m.Close(db) end

---@static
---@return SQLite4Unity3d.SQLite3.Result
function m.Initialize() end

---@static
---@return SQLite4Unity3d.SQLite3.Result
function m.Shutdown() end

---@static
---@param option SQLite4Unity3d.SQLite3.ConfigOption
---@return SQLite4Unity3d.SQLite3.Result
function m.Config(option) end

---@static
---@param directoryType number
---@param directoryPath string
---@return number
function m.SetDirectory(directoryType, directoryPath) end

---@static
---@param db System.IntPtr
---@param milliseconds number
---@return SQLite4Unity3d.SQLite3.Result
function m.BusyTimeout(db, milliseconds) end

---@static
---@param db System.IntPtr
---@return number
function m.Changes(db) end

---@overload fun(db:System.IntPtr, query:string):System.IntPtr @static
---@static
---@param db System.IntPtr
---@param sql string
---@param numBytes number
---@param pzTail System.IntPtr
---@return SQLite4Unity3d.SQLite3.Result, System.IntPtr
function m.Prepare2(db, sql, numBytes, pzTail) end

---@static
---@param stmt System.IntPtr
---@return SQLite4Unity3d.SQLite3.Result
function m.Step(stmt) end

---@static
---@param stmt System.IntPtr
---@return SQLite4Unity3d.SQLite3.Result
function m.Reset(stmt) end

---@static
---@param stmt System.IntPtr
---@return SQLite4Unity3d.SQLite3.Result
function m.Finalize(stmt) end

---@static
---@param db System.IntPtr
---@return number
function m.LastInsertRowid(db) end

---@static
---@param db System.IntPtr
---@return System.IntPtr
function m.Errmsg(db) end

---@static
---@param db System.IntPtr
---@return string
function m.GetErrmsg(db) end

---@static
---@param stmt System.IntPtr
---@param name string
---@return number
function m.BindParameterIndex(stmt, name) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return number
function m.BindNull(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@param val number
---@return number
function m.BindInt(stmt, index, val) end

---@static
---@param stmt System.IntPtr
---@param index number
---@param val number
---@return number
function m.BindInt64(stmt, index, val) end

---@static
---@param stmt System.IntPtr
---@param index number
---@param val number
---@return number
function m.BindDouble(stmt, index, val) end

---@static
---@param stmt System.IntPtr
---@param index number
---@param val string
---@param n number
---@param free System.IntPtr
---@return number
function m.BindText(stmt, index, val, n, free) end

---@static
---@param stmt System.IntPtr
---@param index number
---@param val string
---@param n number
---@param free System.IntPtr
---@return number
function m.BindBlob(stmt, index, val, n, free) end

---@static
---@param stmt System.IntPtr
---@return number
function m.ColumnCount(stmt) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return System.IntPtr
function m.ColumnName(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return string
function m.ColumnName16(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return SQLite4Unity3d.SQLite3.ColType
function m.ColumnType(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return number
function m.ColumnInt(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return number
function m.ColumnInt64(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return number
function m.ColumnDouble(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return System.IntPtr
function m.ColumnText(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return System.IntPtr
function m.ColumnText16(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return System.IntPtr
function m.ColumnBlob(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return number
function m.ColumnBytes(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return string
function m.ColumnString(stmt, index) end

---@static
---@param stmt System.IntPtr
---@param index number
---@return string
function m.ColumnByteArray(stmt, index) end

---@static
---@param db System.IntPtr
---@return SQLite4Unity3d.SQLite3.ExtendedResult
function m.ExtendedErrCode(db) end

---@static
---@return number
function m.LibVersionNumber() end

SQLite4Unity3d.SQLite3 = m
return m
