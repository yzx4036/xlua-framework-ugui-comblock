---@class SQLite4Unity3d.AutoIncrementAttribute : System.Attribute
local m = {}

SQLite4Unity3d.AutoIncrementAttribute = m
return m
