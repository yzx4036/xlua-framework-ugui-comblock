---@class EnumSkillMoveType : System.Enum
---@field public CHAN_YIN EnumSkillMoveType @static
---@field public TU_CHI EnumSkillMoveType @static
---@field public SUN_YI EnumSkillMoveType @static
---@field public value__ number
local m = {}

EnumSkillMoveType = m
return m
