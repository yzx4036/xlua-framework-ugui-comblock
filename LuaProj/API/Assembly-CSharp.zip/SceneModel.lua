---@class SceneModel : System.Object
---@field public isDisposed boolean
---@field public m_rootTrans UnityEngine.Transform
---@field public animationCd number
---@field public isStopAnimation boolean
---@field public changeMatType BattleMatType
---@field public AnimationName string
---@field public IsLoop boolean
---@field public ActionCompCall fun()
---@field public scaleZ number
---@field public Alpha number
local m = {}

---@param ModelPaths table<EnumSubModelType, string>
---@param parentObject ActionUnit
---@param resType EnumSceneModelType
---@param delayTime number
---@return boolean
function m:Initialize(ModelPaths, parentObject, resType, delayTime) end

---@param partName string
---@param subType EnumSubModelType
function m:AddSubModel(partName, subType) end

---@param subType EnumSubModelType
function m:RemoveSubModel(subType) end

---@param name EnumSubModelType
---@return SubModel
function m:GetSubModel(name) end

---@param widX number
---@param widZ number
function m:CreateShadow(widX, widZ) end

---@param type EnumFightObjType
---@param direct EnumFightDirect
---@return BasicHUD
function m:CreateBlood(type, direct) end

---@param type EnumFightObjType
---@return FiveElement
function m:CreateFiveEle(type) end

---@param visible boolean
function m:SetVisible(visible) end

---@param type EnumSubModelType
---@param visible boolean
function m:setHideSubModel(type, visible) end

---@param layer number
function m:ResetLayer(layer) end

---@param position UnityEngine.Vector3
function m:SetPosition(position) end

function m:ReSetAngle2d() end

---@param rotation UnityEngine.Quaternion
function m:SetRotation(rotation) end

---@return UnityEngine.Quaternion
function m:GetRotation() end

---@param scale UnityEngine.Vector3
function m:SetScale(scale) end

---@param faceway number
function m:SetDirect(faceway) end

---@return UnityEngine.Transform
function m:RootTransform() end

---@return UnityEngine.Vector3
function m:GetForward() end

---@param forward UnityEngine.Vector3
function m:SetForward(forward) end

---@param bp EnumBindPoint
---@param fromPoint UnityEngine.Vector3
---@return UnityEngine.Transform
function m:GetBindPointTransform(bp, fromPoint) end

---@param bp EnumBindPoint
---@return boolean
function m:HasBindPoint(bp) end

---@overload fun(animation:string, loop:boolean, horseSpeed:number, bodySpeed:number, fadeTime:number)
---@param animation string
---@param loop boolean
---@param horseSpeed number
---@param bodySpeed number
---@param fadeTime number
---@param isAfterPause boolean
function m:PlayAnimation(animation, loop, horseSpeed, bodySpeed, fadeTime, isAfterPause) end

---@param animation string
---@param speed number
function m:SetAnimationSpeed(animation, speed) end

---@param stopTime number
function m:StopAnimation(stopTime) end

---@param minusTime number
function m:ContinueAnimation(minusTime) end

---@param now number
function m:Update(now) end

function m:ResetMaterial() end

---@param _type BattleMatType
function m:ChangeMat(_type) end

function m:Release() end

SceneModel = m
return m
