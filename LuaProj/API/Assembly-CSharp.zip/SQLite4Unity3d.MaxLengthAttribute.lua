---@class SQLite4Unity3d.MaxLengthAttribute : System.Attribute
---@field public Value number
local m = {}

SQLite4Unity3d.MaxLengthAttribute = m
return m
