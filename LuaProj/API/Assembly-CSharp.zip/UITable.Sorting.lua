---@class UITable.Sorting : System.Enum
---@field public None UITable.Sorting @static
---@field public Numerical_A UITable.Sorting @static
---@field public Numerical_D UITable.Sorting @static
---@field public Alphabetic UITable.Sorting @static
---@field public Horizontal UITable.Sorting @static
---@field public Vertical UITable.Sorting @static
---@field public Custom UITable.Sorting @static
---@field public value__ number
local m = {}

UITable.Sorting = m
return m
