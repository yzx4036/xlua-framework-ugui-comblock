---@class LongTapMe : UnityEngine.MonoBehaviour
local m = {}

LongTapMe = m
return m
