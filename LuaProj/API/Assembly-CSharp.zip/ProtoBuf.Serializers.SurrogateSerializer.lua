---@class ProtoBuf.Serializers.SurrogateSerializer : System.Object
---@field public ReturnsValue boolean
---@field public RequiresOldValue boolean
---@field public ExpectedType System.Type
local m = {}

---@param model ProtoBuf.Meta.TypeModel
---@param toTail boolean
---@return System.Reflection.MethodInfo
function m:GetConversion(model, toTail) end

---@virtual
---@param value any
---@param writer ProtoBuf.ProtoWriter
function m:Write(value, writer) end

---@virtual
---@param value any
---@param source ProtoBuf.ProtoReader
---@return any
function m:Read(value, source) end

ProtoBuf.Serializers.SurrogateSerializer = m
return m
