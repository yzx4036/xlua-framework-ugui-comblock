---@class EnumSubModelType : System.Enum
---@field public none EnumSubModelType @static
---@field public horse EnumSubModelType @static
---@field public body EnumSubModelType @static
---@field public body2 EnumSubModelType @static
---@field public weapon EnumSubModelType @static
---@field public shadow EnumSubModelType @static
---@field public weaponEff EnumSubModelType @static
---@field public weaponEff2 EnumSubModelType @static
---@field public wing EnumSubModelType @static
---@field public value__ number
local m = {}

EnumSubModelType = m
return m
