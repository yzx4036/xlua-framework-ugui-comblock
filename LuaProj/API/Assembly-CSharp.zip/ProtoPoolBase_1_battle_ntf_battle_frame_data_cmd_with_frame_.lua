---@class ProtoPoolBase_1_battle_ntf_battle_frame_data_cmd_with_frame_ : System.Object
local m = {}

---@virtual
---@return any
function m:Get() end

---@virtual
---@param data any
function m:Recycle(data) end

---@virtual
---@param data any
function m:ClearData(data) end

---@overload fun(data:any):any @virtual
---@param data any
---@return any
function m:DeepCopy(data) end

---@virtual
function m:Dispose() end

ProtoPoolBase_1_battle_ntf_battle_frame_data_cmd_with_frame_ = m
return m
