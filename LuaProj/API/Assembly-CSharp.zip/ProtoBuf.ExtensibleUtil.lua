---@class ProtoBuf.ExtensibleUtil : System.Object
local m = {}

ProtoBuf.ExtensibleUtil = m
return m
