---@class PureSingleton_1_HpCountUtil_ : System.Object
---@field public Instance HpCountUtil @static
local m = {}

PureSingleton_1_HpCountUtil_ = m
return m
