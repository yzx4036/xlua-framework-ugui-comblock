---@class LoadLevelScript : UnityEngine.MonoBehaviour
local m = {}

function m:LoadMainMenu() end

function m:LoadJoystickEvent() end

function m:LoadJoysticParameter() end

function m:LoadDPadEvent() end

function m:LoadDPadClassicalTime() end

function m:LoadTouchPad() end

function m:LoadButton() end

function m:LoadFPS() end

function m:LoadThird() end

function m:LoadThirddungeon() end

LoadLevelScript = m
return m
