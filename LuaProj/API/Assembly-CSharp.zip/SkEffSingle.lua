---@class SkEffSingle : SkEffBase
local m = {}

SkEffSingle = m
return m
