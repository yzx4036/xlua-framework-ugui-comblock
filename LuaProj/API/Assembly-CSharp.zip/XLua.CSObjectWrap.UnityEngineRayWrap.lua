---@class XLua.CSObjectWrap.UnityEngineRayWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineRayWrap = m
return m
