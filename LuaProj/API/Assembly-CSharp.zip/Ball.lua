---@class Ball : UnityEngine.MonoBehaviour
local m = {}

Ball = m
return m
