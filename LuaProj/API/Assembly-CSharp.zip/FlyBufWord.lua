---@class FlyBufWord : FlyWordBase
local m = {}

---@param word string
---@param scale number
function m:InitWord(word, scale) end

---@virtual
---@param _targetPos UnityEngine.Vector3
function m:Play(_targetPos) end

---@virtual
---@param _id number
---@param _user any
function m:AutoRemove(_id, _user) end

FlyBufWord = m
return m
