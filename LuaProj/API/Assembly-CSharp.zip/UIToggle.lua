---@class UIToggle : UIWidgetContainer
---@field public list BetterList_1_UIToggle_ @static
---@field public current UIToggle @static
---@field public group number
---@field public activeSprite UIWidget
---@field public invertSpriteState boolean
---@field public activeAnimation UnityEngine.Animation
---@field public animator UnityEngine.Animator
---@field public tween UITweener
---@field public startsActive boolean
---@field public instantTween boolean
---@field public optionCanBeNone boolean
---@field public onChange EventDelegate[]
---@field public validator fun(choice:boolean):boolean
---@field public value boolean
---@field public isColliderEnabled boolean
---@field public isChecked boolean
local m = {}

---@static
---@param group number
---@return UIToggle
function m.GetActiveToggle(group) end

function m:Start() end

---@overload fun(state:boolean)
---@param state boolean
---@param notify boolean
function m:Set(state, notify) end

UIToggle = m
return m
