---@class UISprite : UIBasicSprite
---@field public material UnityEngine.Material
---@field public atlas UIAtlas
---@field public spriteName string
---@field public isValid boolean
---@field public fillCenter boolean
---@field public applyGradient boolean
---@field public gradientTop UnityEngine.Color
---@field public gradientBottom UnityEngine.Color
---@field public border UnityEngine.Vector4
---@field public pixelSize number
---@field public minWidth number
---@field public minHeight number
---@field public drawingDimensions UnityEngine.Vector4
---@field public premultipliedAlpha boolean
local m = {}

---@return UISpriteData
function m:GetAtlasSprite() end

---@virtual
function m:MakePixelPerfect() end

---@virtual
---@param verts BetterList_1_UnityEngine_Vector3_
---@param uvs BetterList_1_UnityEngine_Vector2_
---@param cols BetterList_1_UnityEngine_Color32_
function m:OnFill(verts, uvs, cols) end

UISprite = m
return m
