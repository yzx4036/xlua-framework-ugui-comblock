---@class EyeSoft.TouchLayerLua : System.Object
---@field public Layer EyeSoft.LayerInfo
---@field public TargetLua XLua.LuaTable
local m = {}

EyeSoft.TouchLayerLua = m
return m
