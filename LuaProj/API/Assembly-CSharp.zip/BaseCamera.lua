---@class BaseCamera : System.Object
---@field public mainCameraTransform UnityEngine.Transform
---@field public mainCamera UnityEngine.Camera
---@field public CanSlide boolean
---@field public FirstView number
---@field public RightPara number
---@field public UpPara number
local m = {}

---@param isSetZheng boolean
function m:InitCamera(isSetZheng) end

---@param status boolean
function m:Visible(status) end

---@virtual
---@param dtpos UnityEngine.Vector2
function m:MoveCamera(dtpos) end

---@virtual
---@param _rate number
function m:ScaleScene(_rate) end

---@virtual
function m:BottonDown() end

---@virtual
function m:BottonUp() end

---@virtual
function m:UpdatePosition() end

---@virtual
function m:Dispose() end

BaseCamera = m
return m
