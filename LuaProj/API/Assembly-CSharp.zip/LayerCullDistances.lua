---@class LayerCullDistances : UnityEngine.MonoBehaviour
---@field public FiefCull1Dis number
---@field public FiefCull2Dis number
---@field public FiefCull3Dis number
---@field public FiefCull4Dis number
---@field public FiefCull5Dis number
local m = {}

LayerCullDistances = m
return m
