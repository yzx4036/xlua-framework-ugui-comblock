---@class ActionInfo2d : System.Object
---@field public ActionName EnumAction
---@field public Way number
---@field public Time number
---@field public Frames UnityEngine.Sprite[]
local m = {}

ActionInfo2d = m
return m
