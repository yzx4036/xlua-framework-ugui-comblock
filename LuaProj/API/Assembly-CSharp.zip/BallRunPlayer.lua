---@class BallRunPlayer : UnityEngine.MonoBehaviour
---@field public ballModel UnityEngine.Transform
local m = {}

function m:StartGame() end

BallRunPlayer = m
return m
