---@class XCModJSON : System.Object
local m = {}

---@static
---@param json string
---@return any
function m.jsonDecode(json) end

---@static
---@param json any
---@return string
function m.jsonEncode(json) end

---@static
---@return boolean
function m.lastDecodeSuccessful() end

---@static
---@return number
function m.getLastErrorIndex() end

---@static
---@return string
function m.getLastErrorSnippet() end

XCModJSON = m
return m
