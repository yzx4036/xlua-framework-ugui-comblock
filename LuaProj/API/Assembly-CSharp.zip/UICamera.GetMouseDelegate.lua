---@class UICamera.GetMouseDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param button number
---@return UICamera.MouseOrTouch
function m:Invoke(button) end

---@virtual
---@param button number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(button, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return UICamera.MouseOrTouch
function m:EndInvoke(result) end

UICamera.GetMouseDelegate = m
return m
