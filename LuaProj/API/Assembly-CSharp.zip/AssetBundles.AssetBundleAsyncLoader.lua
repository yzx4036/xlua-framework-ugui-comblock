---@class AssetBundles.AssetBundleAsyncLoader : AssetBundles.BaseAssetBundleAsyncLoader
---@field public Sequence number
local m = {}

---@static
---@return AssetBundles.AssetBundleAsyncLoader
function m.Get() end

---@static
---@param loader AssetBundles.AssetBundleAsyncLoader
function m.Recycle(loader) end

---@param name string
---@param dependances string[]
function m:Init(name, dependances) end

---@virtual
---@return boolean
function m:IsDone() end

---@virtual
---@return number
function m:Progress() end

---@virtual
function m:Update() end

---@virtual
function m:Dispose() end

AssetBundles.AssetBundleAsyncLoader = m
return m
