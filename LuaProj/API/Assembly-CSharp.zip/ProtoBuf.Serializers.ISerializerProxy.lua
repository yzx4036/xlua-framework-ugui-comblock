---@class ProtoBuf.Serializers.ISerializerProxy : table
---@field public Serializer ProtoBuf.Serializers.IProtoSerializer
local m = {}

ProtoBuf.Serializers.ISerializerProxy = m
return m
