---@class ProtoBuf.Serializers.CustomDecoratorBase : System.Object
---@field public ExpectedType System.Type
---@field public ReturnsValue boolean
---@field public RequiresOldValue boolean
local m = {}

---@abstract
---@param value any
---@param dest ProtoBuf.ProtoWriter
function m:Write(value, dest) end

---@abstract
---@param value any
---@param source ProtoBuf.ProtoReader
---@return any
function m:Read(value, source) end

ProtoBuf.Serializers.CustomDecoratorBase = m
return m
