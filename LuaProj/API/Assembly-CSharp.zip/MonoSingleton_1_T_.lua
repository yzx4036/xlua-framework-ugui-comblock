---@class MonoSingleton_1_T_ : UnityEngine.MonoBehaviour
---@field public Instance MonoSingleton_1_T_ @static
local m = {}

function m:Startup() end

function m:DestroySelf() end

---@virtual
function m:Dispose() end

MonoSingleton_1_T_ = m
return m
