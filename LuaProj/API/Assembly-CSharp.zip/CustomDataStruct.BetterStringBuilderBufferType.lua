---@class CustomDataStruct.BetterStringBuilderBufferType : System.Enum
---@field public None CustomDataStruct.BetterStringBuilderBufferType @static
---@field public GlobalOnly CustomDataStruct.BetterStringBuilderBufferType @static
---@field public LocalOnly CustomDataStruct.BetterStringBuilderBufferType @static
---@field public Both CustomDataStruct.BetterStringBuilderBufferType @static
---@field public value__ number
local m = {}

CustomDataStruct.BetterStringBuilderBufferType = m
return m
