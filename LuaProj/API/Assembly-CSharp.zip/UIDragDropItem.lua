---@class UIDragDropItem : UnityEngine.MonoBehaviour
---@field public draggedItems UIDragDropItem[] @static
---@field public restriction UIDragDropItem.Restriction
---@field public cloneOnDrag boolean
---@field public pressAndHoldDelay number
---@field public interactable boolean
local m = {}

---@virtual
function m:StartDragging() end

---@param go UnityEngine.GameObject
function m:StopDragging(go) end

UIDragDropItem = m
return m
