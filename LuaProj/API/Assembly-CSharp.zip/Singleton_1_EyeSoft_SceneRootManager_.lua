---@class Singleton_1_EyeSoft_SceneRootManager_ : System.Object
---@field public instance EyeSoft.SceneRootManager @static
local m = {}

---@static
function m.Release() end

---@virtual
function m:Init() end

---@abstract
function m:Dispose() end

Singleton_1_EyeSoft_SceneRootManager_ = m
return m
