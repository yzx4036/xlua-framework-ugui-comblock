---@class XLua.CSObjectWrap.UnityEngineRectTransformWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineRectTransformWrap = m
return m
