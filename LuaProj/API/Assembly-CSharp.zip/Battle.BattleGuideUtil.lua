---@class Battle.BattleGuideUtil : System.Object
---@field public loadCompCall fun() @static
local m = {}

---@static
---@param pContent string
function m.OnShowNpcContent(pContent) end

---@static
function m.OnCloseNpcContent() end

---@static
function m.OnShowNpcContentFinish() end

---@static
---@param pContent string
---@param pIsLeft boolean
---@param pGameObject UnityEngine.GameObject
---@param pDelay number
function m.OnAddOneMiniContent(pContent, pIsLeft, pGameObject, pDelay) end

---@static
function m.OnOpenHelpPanel() end

---@static
---@param guideId number
function m.OnPlayGuide(guideId) end

---@static
---@param guideId number
function m.OnPlayGuideFinish(guideId) end

---@static
function m.OnClickGotoHelpBtn() end

---@static
function m.OnClickNoHelpBtn() end

---@static
function m.OnStartBattlePlot() end

---@static
---@param sceneName string
function m.OnStateEnter(sceneName) end

---@static
function m.OnStateExit() end

---@static
function m.OnLevelWasLoaded() end

Battle.BattleGuideUtil = m
return m
