---@class MiniMapDrawAssist : System.Object
local m = {}

---@static
---@param texture UnityEngine.Texture2D
---@param cityInfos MiniMapCityInfo[]
function m.Draw(texture, cityInfos) end

---@static
function m.Destroy() end

MiniMapDrawAssist = m
return m
