---@class UIInput : UnityEngine.MonoBehaviour
---@field public current UIInput @static
---@field public selection UIInput @static
---@field public label UILabel
---@field public inputType UIInput.InputType
---@field public onReturnKey UIInput.OnReturnKey
---@field public keyboardType UIInput.KeyboardType
---@field public hideInput boolean
---@field public selectAllTextOnFocus boolean
---@field public validation UIInput.Validation
---@field public characterLimit number
---@field public savedAs string
---@field public activeTextColor UnityEngine.Color
---@field public caretColor UnityEngine.Color
---@field public selectionColor UnityEngine.Color
---@field public onSubmit EventDelegate[]
---@field public onChange EventDelegate[]
---@field public onValidate fun(text:string, charIndex:number, addedChar:number):number
---@field public defaultText string
---@field public defaultColor UnityEngine.Color
---@field public inputShouldBeHidden boolean
---@field public text string
---@field public value string
---@field public selected boolean
---@field public isSelected boolean
---@field public cursorPosition number
---@field public selectionStart number
---@field public selectionEnd number
---@field public caret UITexture
local m = {}

---@overload fun(value:string)
---@param value string
---@param notify boolean
function m:Set(value, notify) end

---@param val string
---@return string
function m:Validate(val) end

function m:Start() end

---@virtual
---@param ev UnityEngine.Event
---@return boolean
function m:ProcessEvent(ev) end

function m:Submit() end

function m:UpdateLabel() end

function m:RemoveFocus() end

function m:SaveValue() end

function m:LoadValue() end

UIInput = m
return m
