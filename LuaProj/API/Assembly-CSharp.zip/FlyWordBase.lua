---@class FlyWordBase : System.Object
---@field public gameObject UnityEngine.GameObject
---@field public transform UnityEngine.Transform
---@field public animation UnityEngine.Animation
local m = {}

---@virtual
---@param res string
---@param num number
function m:Init(res, num) end

---@virtual
---@param _targetPos UnityEngine.Vector3
function m:Play(_targetPos) end

---@virtual
---@param _id number
---@param _user any
function m:AutoRemove(_id, _user) end

function m:Dispose() end

FlyWordBase = m
return m
