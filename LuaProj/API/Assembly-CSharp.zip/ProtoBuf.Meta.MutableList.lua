---@class ProtoBuf.Meta.MutableList : ProtoBuf.Meta.BasicList
---@field public Item any
local m = {}

function m:RemoveLast() end

function m:Clear() end

ProtoBuf.Meta.MutableList = m
return m
