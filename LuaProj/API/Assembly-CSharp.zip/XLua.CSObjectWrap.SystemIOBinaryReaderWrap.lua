---@class XLua.CSObjectWrap.SystemIOBinaryReaderWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.SystemIOBinaryReaderWrap = m
return m
