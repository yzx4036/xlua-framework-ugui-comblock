---@class CS.GameObjectPool : System.Object
local m = {}

---@overload fun(path:string, parentGo:UnityEngine.GameObject):UnityEngine.GameObject @static
---@overload fun(path:string):UnityEngine.GameObject @static
---@static
---@param path string
---@param parentGo UnityEngine.GameObject
---@param preloaded boolean
---@return UnityEngine.GameObject
function m.Get(path, parentGo, preloaded) end

---@overload fun(path:string, callback:(fun(name:string, asset:UnityEngine.Object)), callJudge:(fun(path:string):boolean)) @static
---@static
---@param path string
---@param callback fun(name:string, asset:UnityEngine.Object)
---@param callJudge fun(path:string):boolean
---@param parentGo UnityEngine.GameObject
function m.GetAsync(path, callback, callJudge, parentGo) end

---@static
---@param path string
---@param go UnityEngine.GameObject
---@param useAgain boolean
function m.Put(path, go, useAgain) end

---@static
---@param mDisponseDelay number
function m.DisponseDelay(mDisponseDelay) end

CS.GameObjectPool = m
return m
