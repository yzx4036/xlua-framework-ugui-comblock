---@class PureSingleton_1_DeadUtil_ : System.Object
---@field public Instance DeadUtil @static
local m = {}

PureSingleton_1_DeadUtil_ = m
return m
