---@class RunUtil : PureSingleton_1_RunUtil_
local m = {}

---@param data number[]
function m:doRun(data) end

---@param elementId number
---@param path number[]
function m:DrawPath(elementId, path) end

RunUtil = m
return m
