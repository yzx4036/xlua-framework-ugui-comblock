---@class XLua.CSObjectWrap.UnityEngineUIButtonButtonClickedEventWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineUIButtonButtonClickedEventWrap = m
return m
