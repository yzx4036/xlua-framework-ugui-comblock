---@class Networks.HjTcpNetwork : Networks.HjNetworkBase
local m = {}

---@virtual
function m:Dispose() end

---@virtual
function m:StartAllThread() end

---@virtual
function m:StopAllThread() end

---@virtual
---@param msgObj string
function m:SendMessage(msgObj) end

Networks.HjTcpNetwork = m
return m
