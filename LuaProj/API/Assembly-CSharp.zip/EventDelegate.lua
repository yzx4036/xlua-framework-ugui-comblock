---@class EventDelegate : System.Object
---@field public oneShot boolean
---@field public target UnityEngine.MonoBehaviour
---@field public methodName string
---@field public parameters EventDelegate.Parameter[]
---@field public isValid boolean
---@field public isEnabled boolean
local m = {}

---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@overload fun(list:EventDelegate[], callback:(fun())):EventDelegate @static
---@overload fun(list:EventDelegate[], del:EventDelegate) @static
---@param target UnityEngine.MonoBehaviour
---@param methodName string
function m:Set(target, methodName) end

---@overload fun(list:EventDelegate[]) @static
---@return boolean
function m:Execute() end

function m:Clear() end

---@virtual
---@return string
function m:ToString() end

---@static
---@param list EventDelegate[]
---@return boolean
function m.IsValid(list) end

---@overload fun(list:EventDelegate[], callback:(fun()), oneShot:boolean):EventDelegate @static
---@overload fun(list:EventDelegate[], ev:EventDelegate) @static
---@overload fun(list:EventDelegate[], ev:EventDelegate, oneShot:boolean) @static
---@static
---@param list EventDelegate[]
---@param callback fun()
---@return EventDelegate
function m.Add(list, callback) end

---@overload fun(list:EventDelegate[], ev:EventDelegate):boolean @static
---@static
---@param list EventDelegate[]
---@param callback fun()
---@return boolean
function m.Remove(list, callback) end

EventDelegate = m
return m
