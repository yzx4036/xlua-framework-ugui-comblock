---@class ProtoBuf.IExtension : table
local m = {}

---@abstract
---@return System.IO.Stream
function m:BeginAppend() end

---@abstract
---@param stream System.IO.Stream
---@param commit boolean
function m:EndAppend(stream, commit) end

---@abstract
---@return System.IO.Stream
function m:BeginQuery() end

---@abstract
---@param stream System.IO.Stream
function m:EndQuery(stream) end

---@abstract
---@return number
function m:GetLength() end

ProtoBuf.IExtension = m
return m
