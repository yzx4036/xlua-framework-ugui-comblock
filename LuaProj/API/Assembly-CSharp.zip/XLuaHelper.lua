---@class XLuaHelper : System.Object
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param cmpType System.Type
---@return UnityEngine.Component
function m.AddMissingComponent(go, cmpType) end

---@static
---@param itemType System.Type
---@param itemCount number
---@return System.Array
function m.CreateArrayInstance(itemType, itemCount) end

---@static
---@param itemType System.Type
---@return System.Collections.IList
function m.CreateListInstance(itemType) end

---@static
---@param keyType System.Type
---@param valueType System.Type
---@return System.Collections.IDictionary
function m.CreateDictionaryInstance(keyType, valueType) end

---@overload fun(type:System.Type, methodName:string):(fun(args:any[]):any) @static
---@overload fun(target:any, methodName:string, paramTypes:System.Type[]|System.Type):(fun(args:any[]):any) @static
---@overload fun(target:any, methodName:string):(fun(args:any[]):any) @static
---@static
---@param type System.Type
---@param methodName string
---@param paramTypes System.Type[]|System.Type
---@return fun(args:any[]):any
function m.CreateActionDelegate(type, methodName, paramTypes) end

---@overload fun(type:System.Type, methodName:string):(fun(args:any[]):any) @static
---@overload fun(target:any, methodName:string, paramTypes:System.Type[]|System.Type):(fun(args:any[]):any) @static
---@overload fun(target:any, methodName:string):(fun(args:any[]):any) @static
---@static
---@param type System.Type
---@param methodName string
---@param paramTypes System.Type[]|System.Type
---@return fun(args:any[]):any
function m.CreateCallbackDelegate(type, methodName, paramTypes) end

---@static
---@param itemType System.Type
---@return System.Type
function m.MakeGenericListType(itemType) end

---@static
---@param keyType System.Type
---@param valueType System.Type
---@return System.Type
function m.MakeGenericDictionaryType(keyType, valueType) end

---@overload fun():System.Type @static
---@static
---@param paramTypes System.Type[]|System.Type
---@return System.Type
function m.MakeGenericActionType(paramTypes) end

---@overload fun():System.Type @static
---@static
---@param paramTypes System.Type[]|System.Type
---@return System.Type
function m.MakeGenericCallbackType(paramTypes) end

XLuaHelper = m
return m
