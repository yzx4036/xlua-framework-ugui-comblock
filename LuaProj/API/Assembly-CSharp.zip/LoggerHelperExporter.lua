---@class LoggerHelperExporter : System.Object
---@field public LuaCallCSharp System.Type[] @static
local m = {}

LoggerHelperExporter = m
return m
