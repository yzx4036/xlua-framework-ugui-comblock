---@class BinaryWriterExtentions : System.Object
local m = {}

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value number
function m.WriteDouble(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value number
function m.WriteULong(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value number
function m.WriteUInt(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value number
function m.WriteUShort(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value string
function m.WriteString(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value number
function m.WriteFloat(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value number
function m.WriteSbyte(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value number
function m.WriteLong(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value number
function m.WriteInt(binaryWriter, value) end

---@overload fun(binaryWriter:System.IO.BinaryWriter, chars:number[], index:number, count:number) @static
---@static
---@param binaryWriter System.IO.BinaryWriter
---@param chars number[]
function m.WriteChars(binaryWriter, chars) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value System.Decimal
function m.WriteDecimal(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param ch number
function m.WriteChar(binaryWriter, ch) end

---@overload fun(binaryWriter:System.IO.BinaryWriter, buffer:string, index:number, count:number) @static
---@static
---@param binaryWriter System.IO.BinaryWriter
---@param buffer string
function m.WriteBuffer(binaryWriter, buffer) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value number
function m.WriteByte(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value boolean
function m.WriteBool(binaryWriter, value) end

---@static
---@param binaryWriter System.IO.BinaryWriter
---@param value number
function m.WriteShort(binaryWriter, value) end

BinaryWriterExtentions = m
return m
