---@class AnimationOrTween.EnableCondition : System.Enum
---@field public DoNothing AnimationOrTween.EnableCondition @static
---@field public EnableThenPlay AnimationOrTween.EnableCondition @static
---@field public IgnoreDisabledState AnimationOrTween.EnableCondition @static
---@field public value__ number
local m = {}

AnimationOrTween.EnableCondition = m
return m
