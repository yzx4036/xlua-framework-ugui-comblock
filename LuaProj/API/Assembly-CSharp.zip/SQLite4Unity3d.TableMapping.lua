---@class SQLite4Unity3d.TableMapping : System.Object
---@field public MappedType System.Type
---@field public TableName string
---@field public Columns SQLite4Unity3d.TableMapping.Column[]
---@field public PK SQLite4Unity3d.TableMapping.Column
---@field public GetByPrimaryKeySql string
---@field public HasAutoIncPK boolean
---@field public InsertColumns SQLite4Unity3d.TableMapping.Column[]
---@field public InsertOrReplaceColumns SQLite4Unity3d.TableMapping.Column[]
local m = {}

---@param obj any
---@param id number
function m:SetAutoIncPK(obj, id) end

---@param propertyName string
---@return SQLite4Unity3d.TableMapping.Column
function m:FindColumnWithPropertyName(propertyName) end

---@param columnName string
---@return SQLite4Unity3d.TableMapping.Column
function m:FindColumn(columnName) end

---@param conn SQLite4Unity3d.SQLiteConnection
---@param extra string
---@return SQLite4Unity3d.PreparedSqlLiteInsertCommand
function m:GetInsertCommand(conn, extra) end

SQLite4Unity3d.TableMapping = m
return m
