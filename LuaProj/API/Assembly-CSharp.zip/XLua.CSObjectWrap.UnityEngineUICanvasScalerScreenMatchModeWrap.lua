---@class XLua.CSObjectWrap.UnityEngineUICanvasScalerScreenMatchModeWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineUICanvasScalerScreenMatchModeWrap = m
return m
