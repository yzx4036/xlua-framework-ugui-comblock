---@class ReporterGUI : UnityEngine.MonoBehaviour
local m = {}

ReporterGUI = m
return m
