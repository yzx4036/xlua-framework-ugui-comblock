---@class UIScrollView.Movement : System.Enum
---@field public Horizontal UIScrollView.Movement @static
---@field public Vertical UIScrollView.Movement @static
---@field public Unrestricted UIScrollView.Movement @static
---@field public Custom UIScrollView.Movement @static
---@field public value__ number
local m = {}

UIScrollView.Movement = m
return m
