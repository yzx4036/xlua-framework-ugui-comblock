---@class WallHUD : BasicHUD
local m = {}

---@virtual
---@param fightObjType EnumFightObjType
function m:Init(fightObjType) end

WallHUD = m
return m
