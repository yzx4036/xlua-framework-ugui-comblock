---@class EnumFightObjType : System.Enum
---@field public ZHU_JIANG EnumFightObjType @static
---@field public SOLDIER EnumFightObjType @static
---@field public WALL EnumFightObjType @static
---@field public JIAN_TA EnumFightObjType @static
---@field public ZHAO_HUAN_WU EnumFightObjType @static
---@field public DEAD_UNIT EnumFightObjType @static
---@field public value__ number
local m = {}

EnumFightObjType = m
return m
