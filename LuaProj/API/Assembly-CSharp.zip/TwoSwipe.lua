---@class TwoSwipe : UnityEngine.MonoBehaviour
---@field public trail UnityEngine.GameObject
---@field public swipeData UnityEngine.UI.Text
local m = {}

TwoSwipe = m
return m
