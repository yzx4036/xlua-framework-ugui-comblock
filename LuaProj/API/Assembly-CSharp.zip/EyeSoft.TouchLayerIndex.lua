---@class EyeSoft.TouchLayerIndex : System.Object
---@field public None number @static
---@field public Guide number @static
---@field public TowerRange number @static
---@field public Attacker number @static
---@field public HeroSkillCast number @static
---@field public PVPEdit number @static
---@field public Camera number @static
---@field public EditorGuideUtil number @static
local m = {}

EyeSoft.TouchLayerIndex = m
return m
