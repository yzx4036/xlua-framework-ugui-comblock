---@class Reporter : UnityEngine.MonoBehaviour
---@field public show boolean
---@field public UserData string
---@field public fps number
---@field public fpsText string
---@field public images Images
---@field public size UnityEngine.Vector2
---@field public maxSize number
---@field public numOfCircleToShow number
---@field public Initialized boolean
---@field public TotalMemUsage number
local m = {}

function m:Initialize() end

function m:OnGUIDraw() end

Reporter = m
return m
