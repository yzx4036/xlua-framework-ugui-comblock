---@class EyeSoft.SceneRootManager : Singleton_1_EyeSoft_SceneRootManager_
local m = {}

---@param tag EyeSoft.SceneRootManager.RootTag
---@return UnityEngine.GameObject
function m:GetRoot(tag) end

---@param tag EyeSoft.SceneRootManager.RootTag
function m:Remove(tag) end

---@param tag EyeSoft.SceneRootManager.RootTag
---@param child UnityEngine.GameObject
---@return UnityEngine.GameObject
function m:AddTo(tag, child) end

---@overload fun():UnityEngine.Component
---@overload fun(type:System.Type):UnityEngine.Component
---@param tag EyeSoft.SceneRootManager.RootTag
---@return UnityEngine.MonoBehaviour
function m:AddComp(tag) end

---@virtual
function m:Init() end

---@virtual
function m:Dispose() end

EyeSoft.SceneRootManager = m
return m
