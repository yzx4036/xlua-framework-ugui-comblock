---@class CharacterAnimation : UnityEngine.MonoBehaviour
local m = {}

CharacterAnimation = m
return m
