---@class TwoDoubleTapMe : UnityEngine.MonoBehaviour
local m = {}

TwoDoubleTapMe = m
return m
