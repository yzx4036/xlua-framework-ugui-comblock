---@class RTS_NewSyntaxe : UnityEngine.MonoBehaviour
local m = {}

RTS_NewSyntaxe = m
return m
