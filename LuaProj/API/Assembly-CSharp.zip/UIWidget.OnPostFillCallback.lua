---@class UIWidget.OnPostFillCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param widget UIWidget
---@param bufferOffset number
---@param verts BetterList_1_UnityEngine_Vector3_
---@param uvs BetterList_1_UnityEngine_Vector2_
---@param cols BetterList_1_UnityEngine_Color32_
function m:Invoke(widget, bufferOffset, verts, uvs, cols) end

---@virtual
---@param widget UIWidget
---@param bufferOffset number
---@param verts BetterList_1_UnityEngine_Vector3_
---@param uvs BetterList_1_UnityEngine_Vector2_
---@param cols BetterList_1_UnityEngine_Color32_
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(widget, bufferOffset, verts, uvs, cols, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UIWidget.OnPostFillCallback = m
return m
