---@class UITable.Direction : System.Enum
---@field public Down UITable.Direction @static
---@field public Up UITable.Direction @static
---@field public value__ number
local m = {}

UITable.Direction = m
return m
