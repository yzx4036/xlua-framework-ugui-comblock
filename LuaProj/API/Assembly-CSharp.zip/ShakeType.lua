---@class ShakeType : System.Enum
---@field public updown ShakeType @static
---@field public left ShakeType @static
---@field public right ShakeType @static
---@field public value__ number
local m = {}

ShakeType = m
return m
