---@class BetterList_1.CompareFunc_T_ : System.MulticastDelegate
local m = {}

---@virtual
---@param left any
---@param right any
---@return number
function m:Invoke(left, right) end

---@virtual
---@param left any
---@param right any
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(left, right, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return number
function m:EndInvoke(result) end

BetterList_1.CompareFunc_T_ = m
return m
