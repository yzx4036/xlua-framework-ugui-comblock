---@class UIEditorHelper : UnityEngine.MonoBehaviour
---@field public UIDefaultMat UnityEngine.Material
local m = {}

function m:SetDefautMat() end

UIEditorHelper = m
return m
