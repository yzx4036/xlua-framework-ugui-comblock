---@class ProtoBuf.Serializers.ArrayDecorator : ProtoBuf.Serializers.ProtoDecoratorBase
---@field public ExpectedType System.Type
---@field public RequiresOldValue boolean
---@field public ReturnsValue boolean
local m = {}

---@virtual
---@param value any
---@param dest ProtoBuf.ProtoWriter
function m:Write(value, dest) end

---@virtual
---@param value any
---@param source ProtoBuf.ProtoReader
---@return any
function m:Read(value, source) end

ProtoBuf.Serializers.ArrayDecorator = m
return m
