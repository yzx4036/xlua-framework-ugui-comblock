---@class TestStar : UnityEngine.MonoBehaviour
local m = {}

TestStar = m
return m
