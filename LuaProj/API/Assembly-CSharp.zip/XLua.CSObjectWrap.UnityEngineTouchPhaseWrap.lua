---@class XLua.CSObjectWrap.UnityEngineTouchPhaseWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineTouchPhaseWrap = m
return m
