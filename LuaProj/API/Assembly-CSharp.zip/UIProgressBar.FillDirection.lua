---@class UIProgressBar.FillDirection : System.Enum
---@field public LeftToRight UIProgressBar.FillDirection @static
---@field public RightToLeft UIProgressBar.FillDirection @static
---@field public BottomToTop UIProgressBar.FillDirection @static
---@field public TopToBottom UIProgressBar.FillDirection @static
---@field public value__ number
local m = {}

UIProgressBar.FillDirection = m
return m
