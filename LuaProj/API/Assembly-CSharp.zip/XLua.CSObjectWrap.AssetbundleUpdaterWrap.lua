---@class XLua.CSObjectWrap.AssetbundleUpdaterWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.AssetbundleUpdaterWrap = m
return m
