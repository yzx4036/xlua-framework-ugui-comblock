---@class BMFont : System.Object
---@field public isValid boolean
---@field public charSize number
---@field public baseOffset number
---@field public texWidth number
---@field public texHeight number
---@field public glyphCount number
---@field public spriteName string
---@field public glyphs BMGlyph[]
local m = {}

---@overload fun(index:number):BMGlyph
---@param index number
---@param createIfMissing boolean
---@return BMGlyph
function m:GetGlyph(index, createIfMissing) end

function m:Clear() end

---@param xMin number
---@param yMin number
---@param xMax number
---@param yMax number
function m:Trim(xMin, yMin, xMax, yMax) end

BMFont = m
return m
