---@class UIImageButton : UnityEngine.MonoBehaviour
---@field public target UISprite
---@field public normalSprite string
---@field public hoverSprite string
---@field public pressedSprite string
---@field public disabledSprite string
---@field public pixelSnap boolean
---@field public isEnabled boolean
local m = {}

UIImageButton = m
return m
