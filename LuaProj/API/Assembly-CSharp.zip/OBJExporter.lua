---@class OBJExporter : UnityEditor.ScriptableWizard
---@field public onlySelectedObjects boolean
---@field public applyPosition boolean
---@field public applyRotation boolean
---@field public applyScale boolean
---@field public generateMaterials boolean
---@field public exportTextures boolean
---@field public splitObjects boolean
---@field public autoMarkTexReadable boolean
---@field public objNameAddIdNum boolean
local m = {}

OBJExporter = m
return m
