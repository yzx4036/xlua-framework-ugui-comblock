---@class FlySprite : FlyWordBase
local m = {}

FlySprite = m
return m
