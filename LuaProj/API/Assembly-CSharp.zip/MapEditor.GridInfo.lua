---@class MapEditor.GridInfo : System.Object
---@field public x number
---@field public y number
local m = {}

---@return string
function m:GetKey() end

MapEditor.GridInfo = m
return m
