---@class BattleUnit : ActionUnit
---@field public GridX number
---@field public GridZ number
---@field public GridChildIndex number
---@field public fightObjVo VoFightObj
---@field public buffManager BuffManager
---@field public fiveElemanager FiveEleManager
---@field public isDie boolean
---@field public Layer number
---@field public faceWay number
---@field public route number[]
---@field public hurtCount number
---@field public isEntrance boolean
local m = {}

---@param fightObjVo VoFightObj
---@param delayTime number
function m:initData(fightObjVo, delayTime) end

function m:StopAnimation() end

function m:showHpBar() end

---@overload fun(id:number)
---@overload fun()
---@param id number
---@param obj any
function m:hideHPBar(id, obj) end

---@param hp number
function m:updateHpBar(hp) end

---@param _x number
---@param _y number
function m:setXY(_x, _y) end

---@virtual
---@param _dt number
function m:Update(_dt) end

---@param veclist UnityEngine.Vector2[]
function m:drawPath(veclist) end

function m:clearPath() end

function m:clearRoute() end

function m:setToRouteEnd() end

---@overload fun(time:number, pos:UnityEngine.Vector3, tweenPosType:number)
---@param time number
---@param pos UnityEngine.Vector3
---@param tweenPosType number
---@param isTweenOverStand boolean
function m:SetTweenPosition(time, pos, tweenPosType, isTweenOverStand) end

function m:KillTweenPosition() end

---@param type number
---@return boolean
function m:IsDoTweenPos(type) end

---@param actionEff string
---@param actionEffBindP EnumBindPoint
function m:setAttackEff(actionEff, actionEffBindP) end

---@param actionEff string
---@param actionEffBindP EnumBindPoint
function m:setAttackEff2(actionEff, actionEffBindP) end

---@param id number
---@param isZhongDuan boolean
function m:removeAttackEff(id, isZhongDuan) end

---@param magic MagicInBattle
function m:addLinkMagic(magic) end

---@return number
function m:getLinkMagicNum() end

function m:removeLinkMagic() end

---@overload fun(action:string, loop:boolean, horseSpeed:number, bodySpeed:number) @virtual
---@overload fun(action:string, loop:boolean, horseSpeed:number) @virtual
---@overload fun(action:string, loop:boolean) @virtual
---@virtual
---@param action string
---@param loop boolean
---@param horseSpeed number
---@param bodySpeed number
---@param fadeTime number
function m:SetAction(action, loop, horseSpeed, bodySpeed, fadeTime) end

function m:addHurtCount() end

---@param type EnumFightDeathType
---@param way number
function m:minusHurtCount(type, way) end

---@overload fun(type:EnumFightDeathType)
---@overload fun()
---@param type EnumFightDeathType
---@param way number
function m:dealDie(type, way) end

---@virtual
function m:Release() end

BattleUnit = m
return m
