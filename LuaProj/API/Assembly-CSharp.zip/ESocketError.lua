---@class ESocketError : System.ValueType
---@field public NORMAL number @static
---@field public ERROR_1 number @static
---@field public ERROR_2 number @static
---@field public ERROR_3 number @static
---@field public ERROR_4 number @static
---@field public ERROR_5 number @static
local m = {}

ESocketError = m
return m
