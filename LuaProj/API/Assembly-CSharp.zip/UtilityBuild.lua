---@class UtilityBuild : System.Object
---@field public ManifestBundleName string @static
---@field public ChannelNameFileName string @static
---@field public AppVersionFileName string @static
---@field public ResVersionFileName string @static
---@field public NoticeVersionFileName string @static
---@field public AssetBundlesSizeFileName string @static
---@field public UpdateNoticeFileName string @static
local m = {}

---@static
---@param sourceVersion string
---@param targetVersion string
---@return boolean
function m.CheckIsNewVersion(sourceVersion, targetVersion) end

UtilityBuild = m
return m
