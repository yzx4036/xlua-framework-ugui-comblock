---@class MeshCombineUtility : System.Object
local m = {}

---@static
---@param combines MeshCombineUtility.MeshInstance[]
---@param generateStrips boolean
---@return UnityEngine.Mesh
function m.Combine(combines, generateStrips) end

---@overload fun(gameObject:UnityEngine.GameObject, mMfList:UnityEngine.MeshFilter[]) @static
---@static
---@param gameObject UnityEngine.GameObject
---@param goList UnityEngine.GameObject[]
function m.CombineMesh(gameObject, goList) end

MeshCombineUtility = m
return m
