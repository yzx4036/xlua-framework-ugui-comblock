---@class UIProgressBar : UIWidgetContainer
---@field public current UIProgressBar @static
---@field public onDragFinished fun()
---@field public thumb UnityEngine.Transform
---@field public numberOfSteps number
---@field public onChange EventDelegate[]
---@field public cachedTransform UnityEngine.Transform
---@field public cachedCamera UnityEngine.Camera
---@field public foregroundWidget UIWidget
---@field public backgroundWidget UIWidget
---@field public fillDirection UIProgressBar.FillDirection
---@field public value number
---@field public alpha number
local m = {}

---@overload fun(val:number)
---@param val number
---@param notify boolean
function m:Set(val, notify) end

function m:Start() end

---@virtual
function m:ForceUpdate() end

---@virtual
---@param delta UnityEngine.Vector2
function m:OnPan(delta) end

UIProgressBar = m
return m
