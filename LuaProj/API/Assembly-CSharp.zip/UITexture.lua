---@class UITexture : UIBasicSprite
---@field public mainTexture UnityEngine.Texture
---@field public material UnityEngine.Material
---@field public shader UnityEngine.Shader
---@field public premultipliedAlpha boolean
---@field public border UnityEngine.Vector4
---@field public uvRect UnityEngine.Rect
---@field public drawingDimensions UnityEngine.Vector4
---@field public fixedAspect boolean
local m = {}

---@virtual
function m:MakePixelPerfect() end

---@virtual
---@param verts BetterList_1_UnityEngine_Vector3_
---@param uvs BetterList_1_UnityEngine_Vector2_
---@param cols BetterList_1_UnityEngine_Color32_
function m:OnFill(verts, uvs, cols) end

UITexture = m
return m
