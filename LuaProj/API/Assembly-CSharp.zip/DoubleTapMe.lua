---@class DoubleTapMe : UnityEngine.MonoBehaviour
local m = {}

DoubleTapMe = m
return m
