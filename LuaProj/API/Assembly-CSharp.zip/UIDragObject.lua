---@class UIDragObject : UnityEngine.MonoBehaviour
---@field public target UnityEngine.Transform
---@field public panelRegion UIPanel
---@field public scrollMomentum UnityEngine.Vector3
---@field public restrictWithinPanel boolean
---@field public contentRect UIRect
---@field public dragEffect UIDragObject.DragEffect
---@field public momentumAmount number
---@field public dragMovement UnityEngine.Vector3
local m = {}

function m:CancelMovement() end

function m:CancelSpring() end

UIDragObject = m
return m
