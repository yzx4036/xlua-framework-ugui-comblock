---@class ProtoBuf.ProtoWriter : System.Object
---@field public Context ProtoBuf.SerializationContext
---@field public Model ProtoBuf.Meta.TypeModel
local m = {}

---@static
---@param value any
---@param key number
---@param writer ProtoBuf.ProtoWriter
function m.WriteObject(value, key, writer) end

---@static
---@param value any
---@param key number
---@param writer ProtoBuf.ProtoWriter
function m.WriteRecursionSafeObject(value, key, writer) end

---@static
---@param fieldNumber number
---@param wireType ProtoBuf.WireType
---@param writer ProtoBuf.ProtoWriter
function m.WriteFieldHeader(fieldNumber, wireType, writer) end

---@overload fun(data:string, offset:number, length:number, writer:ProtoBuf.ProtoWriter) @static
---@static
---@param data string
---@param writer ProtoBuf.ProtoWriter
function m.WriteBytes(data, writer) end

---@static
---@param instance any
---@param writer ProtoBuf.ProtoWriter
---@return ProtoBuf.SubItemToken
function m.StartSubItem(instance, writer) end

---@static
---@param token ProtoBuf.SubItemToken
---@param writer ProtoBuf.ProtoWriter
function m.EndSubItem(token, writer) end

function m:Close() end

---@static
---@param value string
---@param writer ProtoBuf.ProtoWriter
function m.WriteString(value, writer) end

---@static
---@param value number
---@param writer ProtoBuf.ProtoWriter
function m.WriteUInt64(value, writer) end

---@static
---@param value number
---@param writer ProtoBuf.ProtoWriter
function m.WriteInt64(value, writer) end

---@static
---@param value number
---@param writer ProtoBuf.ProtoWriter
function m.WriteUInt32(value, writer) end

---@static
---@param value number
---@param writer ProtoBuf.ProtoWriter
function m.WriteInt16(value, writer) end

---@static
---@param value number
---@param writer ProtoBuf.ProtoWriter
function m.WriteUInt16(value, writer) end

---@static
---@param value number
---@param writer ProtoBuf.ProtoWriter
function m.WriteByte(value, writer) end

---@static
---@param value number
---@param writer ProtoBuf.ProtoWriter
function m.WriteSByte(value, writer) end

---@static
---@param value number
---@param writer ProtoBuf.ProtoWriter
function m.WriteInt32(value, writer) end

---@static
---@param value number
---@param writer ProtoBuf.ProtoWriter
function m.WriteDouble(value, writer) end

---@static
---@param value number
---@param writer ProtoBuf.ProtoWriter
function m.WriteSingle(value, writer) end

---@static
---@param writer ProtoBuf.ProtoWriter
---@param enumValue any
function m.ThrowEnumException(writer, enumValue) end

---@static
---@param value boolean
---@param writer ProtoBuf.ProtoWriter
function m.WriteBoolean(value, writer) end

---@static
---@param instance ProtoBuf.IExtensible
---@param writer ProtoBuf.ProtoWriter
function m.AppendExtensionData(instance, writer) end

---@static
---@param fieldNumber number
---@param writer ProtoBuf.ProtoWriter
function m.SetPackedField(fieldNumber, writer) end

---@param value any
function m:SetRootObject(value) end

---@static
---@param value System.Type
---@param writer ProtoBuf.ProtoWriter
function m.WriteType(value, writer) end

ProtoBuf.ProtoWriter = m
return m
