---@class TwistMe : UnityEngine.MonoBehaviour
local m = {}

TwistMe = m
return m
