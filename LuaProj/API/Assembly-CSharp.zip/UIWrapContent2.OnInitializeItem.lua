---@class UIWrapContent2.OnInitializeItem : System.MulticastDelegate
local m = {}

---@virtual
---@param go UnityEngine.GameObject
---@param index number
function m:Invoke(go, index) end

---@virtual
---@param go UnityEngine.GameObject
---@param index number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(go, index, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UIWrapContent2.OnInitializeItem = m
return m
