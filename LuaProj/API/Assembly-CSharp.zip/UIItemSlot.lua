---@class UIItemSlot : UnityEngine.MonoBehaviour
---@field public icon UISprite
---@field public background UIWidget
---@field public label UILabel
---@field public grabSound UnityEngine.AudioClip
---@field public placeSound UnityEngine.AudioClip
---@field public errorSound UnityEngine.AudioClip
local m = {}

UIItemSlot = m
return m
