---@class Networks.SOCKSTAT : System.Enum
---@field public CLOSED Networks.SOCKSTAT @static
---@field public CONNECTING Networks.SOCKSTAT @static
---@field public CONNECTED Networks.SOCKSTAT @static
---@field public value__ number
local m = {}

Networks.SOCKSTAT = m
return m
