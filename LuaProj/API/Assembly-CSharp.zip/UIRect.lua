---@class UIRect : UnityEngine.MonoBehaviour
---@field public leftAnchor UIRect.AnchorPoint
---@field public rightAnchor UIRect.AnchorPoint
---@field public bottomAnchor UIRect.AnchorPoint
---@field public topAnchor UIRect.AnchorPoint
---@field public updateAnchors UIRect.AnchorUpdate
---@field public finalAlpha number
---@field public cachedGameObject UnityEngine.GameObject
---@field public cachedTransform UnityEngine.Transform
---@field public anchorCamera UnityEngine.Camera
---@field public isFullyAnchored boolean
---@field public isAnchoredHorizontally boolean
---@field public isAnchoredVertically boolean
---@field public canBeAnchored boolean
---@field public parent UIRect
---@field public root UIRoot
---@field public isAnchored boolean
---@field public alpha number
---@field public localCorners UnityEngine.Vector3[]
---@field public worldCorners UnityEngine.Vector3[]
local m = {}

---@abstract
---@param frameID number
---@return number
function m:CalculateFinalAlpha(frameID) end

---@virtual
---@param includeChildren boolean
function m:Invalidate(includeChildren) end

---@virtual
---@param relativeTo UnityEngine.Transform
---@return UnityEngine.Vector3[]
function m:GetSides(relativeTo) end

function m:Update() end

function m:UpdateAnchors() end

---@overload fun(go:UnityEngine.GameObject)
---@overload fun(go:UnityEngine.GameObject, left:number, bottom:number, right:number, top:number)
---@overload fun(go:UnityEngine.GameObject, left:number, bottom:number, right:number, top:number)
---@overload fun(go:UnityEngine.GameObject, left:number, leftOffset:number, bottom:number, bottomOffset:number, right:number, rightOffset:number, top:number, topOffset:number)
---@overload fun(left:number, leftOffset:number, bottom:number, bottomOffset:number, right:number, rightOffset:number, top:number, topOffset:number)
---@param t UnityEngine.Transform
function m:SetAnchor(t) end

---@param left number
---@param top number
---@param width number
---@param height number
function m:SetScreenRect(left, top, width, height) end

function m:ResetAnchors() end

function m:ResetAndUpdateAnchors() end

---@abstract
---@param x number
---@param y number
---@param width number
---@param height number
function m:SetRect(x, y, width, height) end

---@virtual
function m:ParentHasChanged() end

UIRect = m
return m
