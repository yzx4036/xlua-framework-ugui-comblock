---@class SceneEffLod : UnityEngine.MonoBehaviour
---@field public DelayTime number
---@field public SceneEffLodList SceneEffLodData[]
---@field public CurLodIndex number
---@field public timerId number
---@field public CurDistance number
local m = {}

SceneEffLod = m
return m
