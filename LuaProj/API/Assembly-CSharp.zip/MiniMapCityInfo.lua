---@class MiniMapCityInfo : System.Object
---@field public cityId number
---@field public influenceId number
local m = {}

MiniMapCityInfo = m
return m
