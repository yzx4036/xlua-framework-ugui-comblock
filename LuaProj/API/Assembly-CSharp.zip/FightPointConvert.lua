---@class FightPointConvert : System.Object
local m = {}

---@static
---@param serverPos number
---@return number
function m.converDataGridX(serverPos) end

---@static
---@param serverPos number
---@return number
function m.convertDataGridY(serverPos) end

---@overload fun(gridX:number, gridY:number, childIndex:number):UnityEngine.Vector2 @static
---@static
---@param serverPos number
---@param childIndex number
---@return UnityEngine.Vector2
function m.convertServerData(serverPos, childIndex) end

---@static
---@param gridX number
---@param gridY number
---@param xOff number
---@param yOff number
---@return UnityEngine.Vector2
function m.convertServerDataMinus2(gridX, gridY, xOff, yOff) end

---@static
---@param gridX number
---@param childIndex number
---@return number
function m.ConverGridToPosX(gridX, childIndex) end

---@static
---@param gridY number
---@param childIndex number
---@return number
function m.ConverGridToPosY(gridY, childIndex) end

FightPointConvert = m
return m
