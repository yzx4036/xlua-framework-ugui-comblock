---@class ProtoBuf.ProtoIncludeAttribute : System.Attribute
---@field public Tag number
---@field public KnownTypeName string
---@field public KnownType System.Type
---@field public DataFormat ProtoBuf.DataFormat
local m = {}

ProtoBuf.ProtoIncludeAttribute = m
return m
