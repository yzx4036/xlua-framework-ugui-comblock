---@class CustomDataStruct.BetterLinkedListNodeData_1_T_ : System.Object
---@field public Value any
---@field public Holder any
local m = {}

CustomDataStruct.BetterLinkedListNodeData_1_T_ = m
return m
