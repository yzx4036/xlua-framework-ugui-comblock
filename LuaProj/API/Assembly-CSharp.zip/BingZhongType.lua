---@class BingZhongType : System.Enum
---@field public DUN BingZhongType @static
---@field public GONG BingZhongType @static
---@field public QIANG BingZhongType @static
---@field public NU BingZhongType @static
---@field public value__ number
local m = {}

BingZhongType = m
return m
