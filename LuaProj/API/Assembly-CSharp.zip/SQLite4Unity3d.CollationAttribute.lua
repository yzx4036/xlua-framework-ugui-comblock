---@class SQLite4Unity3d.CollationAttribute : System.Attribute
---@field public Value string
local m = {}

SQLite4Unity3d.CollationAttribute = m
return m
