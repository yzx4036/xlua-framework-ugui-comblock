---@class CameraBlurBg : UnityEngine.MonoBehaviour
---@field public SampleDist number
---@field public SampleStrength number
local m = {}

CameraBlurBg = m
return m
