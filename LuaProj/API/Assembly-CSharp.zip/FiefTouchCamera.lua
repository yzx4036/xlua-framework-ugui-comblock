---@class FiefTouchCamera : UnityEngine.MonoBehaviour
---@field public SCALE_MIN number
---@field public SCALE_MAX number
---@field public cameraAngle_min number
---@field public cameraAngle_max number
---@field public moveSpeed number
---@field public scaleSpeed number
---@field public orgin UnityEngine.Transform
---@field public rotateDis number
---@field public angle number
---@field public LockBool boolean
---@field public maxAngle number
---@field public FieldOfViewMax number
---@field public FieldOfViewMin number
---@field public curAngle number
---@field public fieldOfView number
local m = {}

FiefTouchCamera = m
return m
