---@class ProtoBuf.ProtoBeforeDeserializationAttribute : System.Attribute
local m = {}

ProtoBuf.ProtoBeforeDeserializationAttribute = m
return m
