---@class Swipe : UnityEngine.MonoBehaviour
---@field public trail UnityEngine.GameObject
---@field public swipeText UnityEngine.UI.Text
local m = {}

Swipe = m
return m
