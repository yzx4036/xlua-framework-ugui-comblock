---@class VoSingleEffPlay : System.Object
---@field public bu BattleUnit
---@field public way number
---@field public isDealHurtEff boolean
---@field public isLast boolean
---@field public hurtValue number
---@field public hurtStyle number
---@field public hpIndex number
---@field public moveData VoTargetMoveData
---@field public reboundDamage number
---@field public xisouHp number
local m = {}

VoSingleEffPlay = m
return m
