---@class BezierPath : System.Object
local m = {}

---@param cp UnityEngine.Vector3[]
---@return UnityEngine.Vector3[]
function m:CreateCurve(cp) end

---@param cp System.Collections.Generic.List_1_UnityEngine_Vector3_
---@param curve System.Collections.Generic.List_1_UnityEngine_Vector3_
---@return System.Collections.Generic.List_1_UnityEngine_Vector3_, System.Collections.Generic.List_1_UnityEngine_Vector3_
function m:ComputeBezier(cp, curve) end

---@param cp System.Collections.Generic.List_1_UnityEngine_Vector3_
---@param t number
---@return UnityEngine.Vector3, System.Collections.Generic.List_1_UnityEngine_Vector3_
function m:PointOnCubicBezier(cp, t) end

BezierPath = m
return m
