---@class ProtoBuf.MemberSerializationOptions : System.Enum
---@field public None ProtoBuf.MemberSerializationOptions @static
---@field public Packed ProtoBuf.MemberSerializationOptions @static
---@field public Required ProtoBuf.MemberSerializationOptions @static
---@field public AsReference ProtoBuf.MemberSerializationOptions @static
---@field public DynamicType ProtoBuf.MemberSerializationOptions @static
---@field public OverwriteList ProtoBuf.MemberSerializationOptions @static
---@field public AsReferenceHasValue ProtoBuf.MemberSerializationOptions @static
---@field public value__ number
local m = {}

ProtoBuf.MemberSerializationOptions = m
return m
