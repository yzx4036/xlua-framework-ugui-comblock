---@class BattleSmallMap : UnityEngine.MonoBehaviour
local m = {}

BattleSmallMap = m
return m
