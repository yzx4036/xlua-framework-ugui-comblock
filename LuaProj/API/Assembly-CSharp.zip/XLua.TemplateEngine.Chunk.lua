---@class XLua.TemplateEngine.Chunk : System.Object
---@field public Type XLua.TemplateEngine.TokenType
---@field public Text string
local m = {}

XLua.TemplateEngine.Chunk = m
return m
