---@class TestStar.TestNode : System.Object
---@field public cityId number
---@field public x number
---@field public y number
---@field public near number[]
local m = {}

TestStar.TestNode = m
return m
