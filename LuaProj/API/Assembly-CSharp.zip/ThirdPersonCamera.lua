---@class ThirdPersonCamera : UnityEngine.MonoBehaviour
---@field public distanceAway number
---@field public distanceUp number
---@field public smooth number
local m = {}

ThirdPersonCamera = m
return m
