---@class MapEditor.CreateCityJson : System.Object
local m = {}

---@static
---@param infoList MapEditor.CityInfo[]
---@param fileName string
function m.CreateJsonFile(infoList, fileName) end

MapEditor.CreateCityJson = m
return m
