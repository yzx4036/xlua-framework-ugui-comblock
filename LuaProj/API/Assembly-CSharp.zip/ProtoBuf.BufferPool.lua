---@class ProtoBuf.BufferPool : System.Object
local m = {}

ProtoBuf.BufferPool = m
return m
