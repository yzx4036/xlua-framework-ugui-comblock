---@class GameUtilityExporter : System.Object
---@field public LuaCallCSharp System.Type[] @static
local m = {}

GameUtilityExporter = m
return m
