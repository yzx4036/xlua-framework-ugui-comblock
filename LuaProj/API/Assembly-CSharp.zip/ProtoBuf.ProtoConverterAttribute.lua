---@class ProtoBuf.ProtoConverterAttribute : System.Attribute
local m = {}

ProtoBuf.ProtoConverterAttribute = m
return m
