---@class Person : EyeSoft.Data.DataModelBase
---@field public Id number
---@field public Name string
---@field public Surname string
---@field public Age number
---@field public numberList System.Collections.IList
local m = {}

---@virtual
---@return string
function m:ToString() end

Person = m
return m
