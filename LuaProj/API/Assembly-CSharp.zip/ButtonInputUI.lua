---@class ButtonInputUI : UnityEngine.MonoBehaviour
---@field public getButtonDownText UnityEngine.UI.Text
---@field public getButtonText UnityEngine.UI.Text
---@field public getButtonTimeText UnityEngine.UI.Text
---@field public getButtonUpText UnityEngine.UI.Text
local m = {}

---@param value boolean
function m:SetSwipeIn(value) end

---@param value boolean
function m:SetSwipeOut(value) end

---@param value boolean
function m:setTimePush(value) end

ButtonInputUI = m
return m
