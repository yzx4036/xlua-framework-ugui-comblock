---@class MagicBindTarget : System.Object
---@field public bindTarget Entity
---@field public bindHurtData VoTargetData
local m = {}

MagicBindTarget = m
return m
