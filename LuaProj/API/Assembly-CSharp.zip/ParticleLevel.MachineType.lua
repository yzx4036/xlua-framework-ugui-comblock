---@class ParticleLevel.MachineType : System.Enum
---@field public Low ParticleLevel.MachineType @static
---@field public Mid ParticleLevel.MachineType @static
---@field public High ParticleLevel.MachineType @static
---@field public value__ number
local m = {}

ParticleLevel.MachineType = m
return m
