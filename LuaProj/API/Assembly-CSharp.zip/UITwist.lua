---@class UITwist : UnityEngine.MonoBehaviour
local m = {}

function m:OnEnable() end

function m:OnDestroy() end

UITwist = m
return m
