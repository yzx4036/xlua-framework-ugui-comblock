---@class UIDragDropRoot : UnityEngine.MonoBehaviour
---@field public root UnityEngine.Transform @static
local m = {}

UIDragDropRoot = m
return m
