---@class EyeSoft.UnityFunction : System.Object
---@field public WWWStreamingAssetPath fun():string @static
---@field public GetPlatform fun():string @static
---@field public LoadEditor fun(obj:string):UnityEngine.Object @static
---@field public DestroySelf fun(obj:UnityEngine.GameObject) @static
---@field public DestoryObject fun(obj:UnityEngine.Object) @static
---@field public RunPlatform fun():EyeSoft.GamePlatform @static
---@field public Compress fun():string @static
local m = {}

---@static
---@param initiator UnityEngine.MonoBehaviour
---@param routine System.Collections.IEnumerator
---@return UnityEngine.Coroutine
function m.InvokeStart(initiator, routine) end

EyeSoft.UnityFunction = m
return m
