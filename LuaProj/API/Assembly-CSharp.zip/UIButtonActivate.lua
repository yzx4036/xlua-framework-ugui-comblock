---@class UIButtonActivate : UnityEngine.MonoBehaviour
---@field public target UnityEngine.GameObject
---@field public state boolean
local m = {}

UIButtonActivate = m
return m
