---@class XLuaManager : MonoSingleton_1_XLuaManager_
---@field public luaAssetbundleAssetName string @static
---@field public luaScriptsFolder string @static
---@field public HasGameStart boolean
---@field public AssetbundleName string
local m = {}

---@return XLua.LuaEnv
function m:GetLuaEnv() end

function m:OnInit() end

function m:Restart() end

---@param scriptContent string
---@return any[]
function m:SafeDoString(scriptContent) end

---@overload fun()
---@param restart boolean
function m:StartHotfix(restart) end

function m:StopHotfix() end

function m:StartGame() end

---@param scriptName string
function m:ReloadScript(scriptName) end

---@static
---@param filepath System.String
---@return string, System.String
function m.CustomLoader(filepath) end

---@overload fun(module:string, function:string):any[]
---@param module string
---@param function string
---@param args any[]|any
---@return any[]
function m:CallLuaFunction(module, function, args) end

---@virtual
function m:Dispose() end

XLuaManager = m
return m
