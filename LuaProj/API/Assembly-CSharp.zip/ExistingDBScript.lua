---@class ExistingDBScript : UnityEngine.MonoBehaviour
---@field public DebugText UnityEngine.UI.Text
local m = {}

ExistingDBScript = m
return m
