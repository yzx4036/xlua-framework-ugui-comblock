---@class ReadOnlyAttribute : UnityEngine.PropertyAttribute
local m = {}

ReadOnlyAttribute = m
return m
