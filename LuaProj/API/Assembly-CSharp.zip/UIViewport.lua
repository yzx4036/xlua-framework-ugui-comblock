---@class UIViewport : UnityEngine.MonoBehaviour
---@field public sourceCamera UnityEngine.Camera
---@field public topLeft UnityEngine.Transform
---@field public bottomRight UnityEngine.Transform
---@field public fullSize number
local m = {}

UIViewport = m
return m
