---@class NtfBattleFrameDataPool : ProtoPoolBase_1_battle_ntf_battle_frame_data_
local m = {}

NtfBattleFrameDataPool = m
return m
