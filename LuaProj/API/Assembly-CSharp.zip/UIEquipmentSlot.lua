---@class UIEquipmentSlot : UIItemSlot
---@field public equipment InvEquipment
---@field public slot InvBaseItem.Slot
local m = {}

UIEquipmentSlot = m
return m
