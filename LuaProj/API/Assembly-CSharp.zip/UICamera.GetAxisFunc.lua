---@class UICamera.GetAxisFunc : System.MulticastDelegate
local m = {}

---@virtual
---@param name string
---@return number
function m:Invoke(name) end

---@virtual
---@param name string
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(name, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return number
function m:EndInvoke(result) end

UICamera.GetAxisFunc = m
return m
