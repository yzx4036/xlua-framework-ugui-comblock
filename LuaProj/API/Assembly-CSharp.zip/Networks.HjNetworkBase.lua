---@class Networks.HjNetworkBase : System.Object
---@field public OnConnect fun(arg1:any, arg2:number, arg3:string)
---@field public OnClosed fun(arg1:any, arg2:number, arg3:string)
---@field public ReceivePkgHandle fun(obj:string)
---@field public ClientSocket System.Net.Sockets.Socket
local m = {}

---@virtual
function m:Dispose() end

---@param ip string
---@param port number
function m:SetHostPort(ip, port) end

function m:Connect() end

---@virtual
function m:StartAllThread() end

---@virtual
function m:StopAllThread() end

---@virtual
function m:Close() end

---@virtual
function m:UpdateNetwork() end

---@virtual
---@param msgObj string
function m:SendMessage(msgObj) end

---@return boolean
function m:IsConnect() end

Networks.HjNetworkBase = m
return m
