---@class CombineChildren : UnityEngine.MonoBehaviour
---@field public generateTriangleStrips boolean
local m = {}

CombineChildren = m
return m
