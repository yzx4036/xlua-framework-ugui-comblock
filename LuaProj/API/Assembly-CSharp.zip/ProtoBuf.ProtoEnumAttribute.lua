---@class ProtoBuf.ProtoEnumAttribute : System.Attribute
---@field public Value number
---@field public Name string
local m = {}

---@return boolean
function m:HasValue() end

ProtoBuf.ProtoEnumAttribute = m
return m
