---@class EffectBaseInfo : System.Object
---@field public path string
---@field public bindPoint EnumBindPoint
---@field public totalTime number
---@field public xOff number
---@field public yOff number
---@field public effJinxiang boolean
---@field public resetRotation boolean
---@field public localScale number
---@field public parentScale number
local m = {}

---@overload fun(path:string, _bindpoint:EnumBindPoint, totalTime:number, effJinxiang:boolean, xOff:number, yOff:number, resetRotation:boolean, parentScale:number):EffectBaseInfo @static
---@overload fun(path:string, _bindpoint:EnumBindPoint, totalTime:number, effJinxiang:boolean, xOff:number, yOff:number, resetRotation:boolean):EffectBaseInfo @static
---@overload fun(path:string, _bindpoint:EnumBindPoint, totalTime:number, effJinxiang:boolean, xOff:number, yOff:number):EffectBaseInfo @static
---@overload fun(path:string, _bindpoint:EnumBindPoint, totalTime:number, effJinxiang:boolean, xOff:number):EffectBaseInfo @static
---@overload fun(path:string, _bindpoint:EnumBindPoint, totalTime:number, effJinxiang:boolean):EffectBaseInfo @static
---@static
---@param path string
---@param _bindpoint EnumBindPoint
---@param totalTime number
---@param effJinxiang boolean
---@param xOff number
---@param yOff number
---@param resetRotation boolean
---@param parentScale number
---@param localScale number
---@return EffectBaseInfo
function m.CreateEffInfo(path, _bindpoint, totalTime, effJinxiang, xOff, yOff, resetRotation, parentScale, localScale) end

EffectBaseInfo = m
return m
