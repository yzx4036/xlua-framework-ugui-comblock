---@class TwoTapMe : UnityEngine.MonoBehaviour
local m = {}

TwoTapMe = m
return m
