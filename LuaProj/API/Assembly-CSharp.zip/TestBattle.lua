---@class TestBattle : UnityEngine.MonoBehaviour
local m = {}

function m:OnRenderObject() end

TestBattle = m
return m
