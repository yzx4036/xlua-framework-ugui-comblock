---@class ProtoBuf.Serializers.SubItemSerializer : System.Object
local m = {}

ProtoBuf.Serializers.SubItemSerializer = m
return m
