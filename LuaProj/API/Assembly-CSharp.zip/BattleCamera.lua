---@class BattleCamera : BaseCamera
---@field public midRate number @static
---@field public CameraAngleX number @static
---@field public CameraAngleY number @static
---@field public IsSetZheng boolean @static
---@field public CurScaleRate number
---@field public RotateY number
---@field public CantainerRotateX number
---@field public shakeDis number
---@field public CameraContainerPosX number
---@field public CameraContainerPosY number
---@field public CameraContainerPosZ number
---@field public FieldOfView number
local m = {}

---@param isactive boolean
function m:setBlackTranformActive(isactive) end

---@virtual
---@param dtpos UnityEngine.Vector2
function m:MoveCamera(dtpos) end

---@virtual
---@param _rate number
function m:ScaleScene(_rate) end

function m:MoveToTargetPos() end

---@virtual
function m:BottonUp() end

---@virtual
function m:BottonDown() end

function m:Update() end

---@virtual
function m:UpdatePosition() end

---@virtual
function m:Dispose() end

BattleCamera = m
return m
