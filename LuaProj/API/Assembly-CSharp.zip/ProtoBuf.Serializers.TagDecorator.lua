---@class ProtoBuf.Serializers.TagDecorator : ProtoBuf.Serializers.ProtoDecoratorBase
---@field public ExpectedType System.Type
---@field public RequiresOldValue boolean
---@field public ReturnsValue boolean
local m = {}

---@virtual
---@param callbackType ProtoBuf.Meta.TypeModel.CallbackType
---@return boolean
function m:HasCallbacks(callbackType) end

---@virtual
---@return boolean
function m:CanCreateInstance() end

---@virtual
---@param source ProtoBuf.ProtoReader
---@return any
function m:CreateInstance(source) end

---@virtual
---@param value any
---@param callbackType ProtoBuf.Meta.TypeModel.CallbackType
---@param context ProtoBuf.SerializationContext
function m:Callback(value, callbackType, context) end

---@virtual
---@param value any
---@param source ProtoBuf.ProtoReader
---@return any
function m:Read(value, source) end

---@virtual
---@param value any
---@param dest ProtoBuf.ProtoWriter
function m:Write(value, dest) end

ProtoBuf.Serializers.TagDecorator = m
return m
