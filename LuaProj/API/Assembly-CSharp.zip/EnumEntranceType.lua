---@class EnumEntranceType : System.Enum
---@field public FROM_FLOOR EnumEntranceType @static
---@field public FEN_SHEN EnumEntranceType @static
---@field public FAST_RUN_IN EnumEntranceType @static
---@field public value__ number
local m = {}

EnumEntranceType = m
return m
