---@class UIRect.AnchorPoint : System.Object
---@field public target UnityEngine.Transform
---@field public relative number
---@field public absolute number
---@field public rect UIRect
---@field public targetCam UnityEngine.Camera
local m = {}

---@overload fun(target:UnityEngine.Transform, relative:number, absolute:number)
---@param relative number
---@param absolute number
function m:Set(relative, absolute) end

---@overload fun(rel0:number, rel1:number, rel2:number, abs0:number, abs1:number, abs2:number)
---@param abs0 number
---@param abs1 number
---@param abs2 number
function m:SetToNearest(abs0, abs1, abs2) end

---@param parent UnityEngine.Transform
---@param localPos number
function m:SetHorizontal(parent, localPos) end

---@param parent UnityEngine.Transform
---@param localPos number
function m:SetVertical(parent, localPos) end

---@param relativeTo UnityEngine.Transform
---@return UnityEngine.Vector3[]
function m:GetSides(relativeTo) end

UIRect.AnchorPoint = m
return m
