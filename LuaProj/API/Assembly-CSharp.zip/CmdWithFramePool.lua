---@class CmdWithFramePool : ProtoPoolBase_1_battle_ntf_battle_frame_data_cmd_with_frame_
local m = {}

CmdWithFramePool = m
return m
