---@class SkEffRow : SkEffBase
local m = {}

SkEffRow = m
return m
