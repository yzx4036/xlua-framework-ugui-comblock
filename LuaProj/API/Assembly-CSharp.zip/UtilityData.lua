---@class UtilityData : System.Object
local m = {}

---@static
---@param copyTo string
---@param offsetTo number
---@param copyFrom string
---@param offsetFrom number
---@param count number
function m.CopyBytes(copyTo, offsetTo, copyFrom, offsetFrom, count) end

---@static
---@param str string
---@return string
function m.StringToBytes(str) end

---@static
---@param str string
---@return string
function m.StringToUTFBytes(str) end

---@static
---@param bytes string
---@return string
function m.BytesToString(bytes) end

---@static
---@param info string
---@return System.Collections.Hashtable
function m.HttpGetInfo(info) end

UtilityData = m
return m
