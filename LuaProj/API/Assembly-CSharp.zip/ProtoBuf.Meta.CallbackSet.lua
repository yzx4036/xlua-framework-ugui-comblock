---@class ProtoBuf.Meta.CallbackSet : System.Object
---@field public BeforeSerialize System.Reflection.MethodInfo
---@field public BeforeDeserialize System.Reflection.MethodInfo
---@field public AfterSerialize System.Reflection.MethodInfo
---@field public AfterDeserialize System.Reflection.MethodInfo
---@field public NonTrivial boolean
local m = {}

ProtoBuf.Meta.CallbackSet = m
return m
