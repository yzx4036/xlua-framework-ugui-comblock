---@class MagicInBattle : Entity
---@field public relateBuId number
---@field public isPause boolean
---@field public bindTargets MagicBindTarget[]
---@field public lastX number
---@field public lastY number
---@field public faceWay number
local m = {}

---@virtual
function m:Release() end

MagicInBattle = m
return m
