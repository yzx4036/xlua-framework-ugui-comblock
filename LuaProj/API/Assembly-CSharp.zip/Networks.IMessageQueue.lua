---@class Networks.IMessageQueue : table
local m = {}

---@abstract
---@param o string
function m:Add(o) end

---@abstract
---@param bytesList string[]
function m:MoveTo(bytesList) end

---@abstract
---@return boolean
function m:Empty() end

Networks.IMessageQueue = m
return m
