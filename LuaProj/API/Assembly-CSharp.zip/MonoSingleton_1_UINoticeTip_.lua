---@class MonoSingleton_1_UINoticeTip_ : UnityEngine.MonoBehaviour
---@field public Instance UINoticeTip @static
local m = {}

function m:Startup() end

function m:DestroySelf() end

---@virtual
function m:Dispose() end

MonoSingleton_1_UINoticeTip_ = m
return m
