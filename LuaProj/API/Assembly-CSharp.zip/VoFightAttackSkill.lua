---@class VoFightAttackSkill : System.Object
---@field public skillVo VoSkill
---@field public attackData VoAttackData
---@field public attIndexChild number
---@field public targetDataArr VoTargetData[]
---@field public zhaoHuanWuDataArr com.proto.SceneCombatUnit[]
---@field public effPosArr UnityEngine.Vector2[]
---@field public attUnit BattleUnit
---@field public tarBus BattleUnit[]
---@field public delayArr string[]
---@field public singleDelayArr string[]
---@field public zhaoHunWuBuArr BattleUnit[]
---@field public sceneBuffMagicArr MagicInBattle[]
---@field public attUnitType EnumFightObjType
---@field public attUnitDirect EnumFightDirect
---@field public attUnitX number
---@field public attUnitY number
---@field public attUnitZ number
local m = {}

---@param id number
---@param fightaddeff VoFightAddEff
function m:dealAddEff(id, fightaddeff) end

---@param hasEffMagic boolean
function m:dealHurt(hasEffMagic) end

---@param id number
---@param bu BattleUnit
function m:doZhaoHunSingle(id, bu) end

---@param id number
---@param magic MagicInBattle
function m:doSceneMagicSingle(id, magic) end

---@param id number
---@param hurtSingleVo VoHurtSingle
function m:doHurtSingle(id, hurtSingleVo) end

---@param target BattleUnit
---@param type number
---@return number
function m:getNearMagic(target, type) end

---@overload fun(id:number)
---@overload fun()
---@param id number
---@param obj any
function m:dealBufAfter(id, obj) end

VoFightAttackSkill = m
return m
