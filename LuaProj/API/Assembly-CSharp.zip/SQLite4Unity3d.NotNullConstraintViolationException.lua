---@class SQLite4Unity3d.NotNullConstraintViolationException : SQLite4Unity3d.SQLiteException
---@field public Columns System.Collections.Generic.IEnumerable_1_SQLite4Unity3d_TableMapping_Column_
local m = {}

---@overload fun(r:SQLite4Unity3d.SQLite3.Result, message:string, mapping:SQLite4Unity3d.TableMapping, obj:any):SQLite4Unity3d.NotNullConstraintViolationException @static
---@overload fun(exception:SQLite4Unity3d.SQLiteException, mapping:SQLite4Unity3d.TableMapping, obj:any):SQLite4Unity3d.NotNullConstraintViolationException @static
---@static
---@param r SQLite4Unity3d.SQLite3.Result
---@param message string
---@return SQLite4Unity3d.NotNullConstraintViolationException
function m.New(r, message) end

SQLite4Unity3d.NotNullConstraintViolationException = m
return m
