---@class IProtoPool : table
local m = {}

---@abstract
---@return any
function m:Get() end

---@abstract
---@param data any
function m:Recycle(data) end

---@abstract
---@param data any
function m:ClearData(data) end

---@abstract
---@param data any
---@return any
function m:DeepCopy(data) end

---@abstract
function m:Dispose() end

IProtoPool = m
return m
