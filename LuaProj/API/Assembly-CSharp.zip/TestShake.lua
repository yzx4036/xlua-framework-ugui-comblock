---@class TestShake : UnityEngine.MonoBehaviour
---@field public shakeInfo string
local m = {}

function m:InitData() end

TestShake = m
return m
