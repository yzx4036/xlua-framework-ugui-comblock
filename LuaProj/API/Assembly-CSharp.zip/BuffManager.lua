---@class BuffManager : System.Object
local m = {}

---@param unit BattleUnit
function m:Initalize(unit) end

---@param id number
function m:addBufEffFromWait(id) end

---@param id number
---@param sysId number
---@param bl number
---@param isAddEffDelay boolean
function m:addBuf(id, sysId, bl, isAddEffDelay) end

---@param type EnumBuffAttribute
---@return boolean
function m:isBuffAttrbute(type) end

---@param id number
---@return EnumBuffAttribute
function m:GetBuffAttrbute(id) end

---@return boolean
function m:IsBuffPauseAction() end

---@param id number
---@param isDelay boolean
function m:removeBuf(id, isDelay) end

function m:clearBuf() end

---@return number
function m:getBufBl() end

BuffManager = m
return m
