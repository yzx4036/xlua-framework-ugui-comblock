---@class UITweener.Method : System.Enum
---@field public Linear UITweener.Method @static
---@field public EaseIn UITweener.Method @static
---@field public EaseOut UITweener.Method @static
---@field public EaseInOut UITweener.Method @static
---@field public BounceIn UITweener.Method @static
---@field public BounceOut UITweener.Method @static
---@field public value__ number
local m = {}

UITweener.Method = m
return m
