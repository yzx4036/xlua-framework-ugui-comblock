---@class FPSPlayerControl : UnityEngine.MonoBehaviour
---@field public gunSound UnityEngine.AudioClip
---@field public reload UnityEngine.AudioClip
---@field public needReload UnityEngine.AudioClip
---@field public shellParticle UnityEngine.ParticleSystem
---@field public muzzleEffect UnityEngine.GameObject
---@field public impactEffect UnityEngine.GameObject
---@field public armoText UnityEngine.UI.Text
local m = {}

function m:MoveStart() end

function m:MoveStop() end

function m:GunFire() end

---@param value boolean
function m:TouchPadSwipe(value) end

FPSPlayerControl = m
return m
