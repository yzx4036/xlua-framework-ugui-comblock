---@class ProtoBuf.Serializers.CustomSetting : System.Object
local m = {}

---@static
---@param type System.Type
---@param customSerializer ProtoBuf.Serializers.ICustomProtoSerializer
function m.AddCustomSerializer(type, customSerializer) end

---@static
---@param type System.Type
function m.RemoveCustomSerializer(type) end

---@static
function m.CrearCustomSerializer() end

---@static
---@param targetType System.Type
---@return ProtoBuf.Serializers.ICustomProtoSerializer
function m.TryGetCustomSerializer(targetType) end

ProtoBuf.Serializers.CustomSetting = m
return m
