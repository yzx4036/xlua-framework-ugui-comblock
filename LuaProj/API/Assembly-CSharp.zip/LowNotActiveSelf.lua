---@class LowNotActiveSelf : UnityEngine.MonoBehaviour
---@field public IsLow boolean
local m = {}

LowNotActiveSelf = m
return m
