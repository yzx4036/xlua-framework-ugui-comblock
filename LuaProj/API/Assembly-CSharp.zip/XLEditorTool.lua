---@class XLEditorTool : UnityEngine.MonoBehaviour
local m = {}

XLEditorTool = m
return m
