---@class CustomDataStruct.IDelegateAction : table
local m = {}

---@overload fun(arg1:any) @abstract
---@overload fun(arg1:any, arg2:any) @abstract
---@overload fun(arg1:any, arg2:any, arg3:any) @abstract
---@abstract
function m:Invoke() end

CustomDataStruct.IDelegateAction = m
return m
