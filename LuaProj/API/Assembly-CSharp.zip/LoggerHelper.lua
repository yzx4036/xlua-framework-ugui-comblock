---@class LoggerHelper : MonoSingleton_1_LoggerHelper_
local m = {}

---@virtual
function m:Dispose() end

---@param type LoggerHelper.LOG_TYPE
---@param msg string
function m:LogToMainThread(type, msg) end

LoggerHelper = m
return m
