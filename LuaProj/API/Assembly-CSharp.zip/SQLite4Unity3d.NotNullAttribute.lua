---@class SQLite4Unity3d.NotNullAttribute : System.Attribute
local m = {}

SQLite4Unity3d.NotNullAttribute = m
return m
