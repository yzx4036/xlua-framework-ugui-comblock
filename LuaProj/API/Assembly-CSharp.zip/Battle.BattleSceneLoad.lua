---@class Battle.BattleSceneLoad : System.Object
---@field public LoadCompCall fun() @static
local m = {}

---@static
---@param sceneName string
function m.OnStateEnter(sceneName) end

---@static
function m.OnStateExit() end

---@overload fun(warType:number, cityId:number, terrainId:number) @static
---@static
---@param warType number
---@param cityId number
---@param terrainId number
---@param isBeginOfBattle boolean
function m.OnReadyToGo(warType, cityId, terrainId, isBeginOfBattle) end

---@static
---@param isAttack boolean
---@param orderId number
---@param value number
function m.OnChangeRage(isAttack, orderId, value) end

---@static
---@param isAttack boolean
---@param orderId number
---@param heroTroops number
---@param soldierTroops number
function m.OnChangeHp(isAttack, orderId, heroTroops, soldierTroops) end

---@static
function m.OnBattleOver() end

---@static
function m.OnLeaveBattleScene() end

---@static
function m.OnLevelWasLoaded() end

---@static
---@param isAttack boolean
---@param orderId number
function m.ReleasSkill(isAttack, orderId) end

---@static
---@param state number
function m.SkillsReleaseFailure(state) end

---@static
function m.RecyclingBattleEmbattle() end

---@static
---@return string[]
function m.PreloadedPaths() end

---@static
---@param data string[]
function m.SetPreLoadData(data) end

---@static
---@return number
function m.GetCountry() end

Battle.BattleSceneLoad = m
return m
