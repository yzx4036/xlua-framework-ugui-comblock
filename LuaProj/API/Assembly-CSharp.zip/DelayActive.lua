---@class DelayActive : UnityEngine.MonoBehaviour
---@field public delayTime number
---@field public animationTime number
---@field public randomMinTime number
---@field public randomMaxTime number
local m = {}

DelayActive = m
return m
