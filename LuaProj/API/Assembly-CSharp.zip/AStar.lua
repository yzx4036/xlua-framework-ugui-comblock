---@class AStar : System.Object
---@field public BAR number @static
---@field public PATH number @static
---@field public DIRECT_VALUE number @static
---@field public OBLIQUE_VALUE number @static
local m = {}

---@param mapInfo MapInfo
---@param sceneMapGrid SceneMapGrid
---@param resultNodes System.Collections.Generic.List_1_System_Int32_
---@return System.Collections.Generic.List_1_System_Int32_
function m:search(mapInfo, sceneMapGrid, resultNodes) end

AStar = m
return m
