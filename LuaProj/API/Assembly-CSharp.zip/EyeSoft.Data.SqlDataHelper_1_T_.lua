---@class EyeSoft.Data.SqlDataHelper_1_T_ : System.Object
local m = {}

---@static
---@return number
function m.CreateTable() end

---@static
---@return number
function m.DropTable() end

---@static
---@param target EyeSoft.Data.DataModelBase
---@param isReplace boolean
---@return number
function m.InsertOneData(target, isReplace) end

---@static
---@param key any
---@return number
function m.DeleteOneData(key) end

---@static
---@param target EyeSoft.Data.DataModelBase
---@return number
function m.UpdateOneRowData(target) end

---@static
---@return EyeSoft.Data.DataModelBase[]
function m.GetAllData() end

---@static
---@param key any
---@return EyeSoft.Data.DataModelBase
function m.GetOneDataByKey(key) end

EyeSoft.Data.SqlDataHelper_1_T_ = m
return m
