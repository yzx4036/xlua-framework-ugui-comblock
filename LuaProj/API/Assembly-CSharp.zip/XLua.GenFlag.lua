---@class XLua.GenFlag : System.Enum
---@field public No XLua.GenFlag @static
---@field public GCOptimize XLua.GenFlag @static
---@field public value__ number
local m = {}

XLua.GenFlag = m
return m
