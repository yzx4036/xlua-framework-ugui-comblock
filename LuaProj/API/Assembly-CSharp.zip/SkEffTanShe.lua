---@class SkEffTanShe : SkEffBase
local m = {}

SkEffTanShe = m
return m
