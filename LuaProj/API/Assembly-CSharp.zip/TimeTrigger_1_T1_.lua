---@class TimeTrigger_1_T1_ : System.MulticastDelegate
local m = {}

---@virtual
---@param id number
---@param obj any
function m:Invoke(id, obj) end

---@virtual
---@param id number
---@param obj any
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(id, obj, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

TimeTrigger_1_T1_ = m
return m
