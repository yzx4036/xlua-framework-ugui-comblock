---@class AssetBundles.BaseAssetAsyncLoader : AssetBundles.ResourceAsyncOperation
---@field public asset UnityEngine.Object
local m = {}

---@virtual
function m:Dispose() end

AssetBundles.BaseAssetAsyncLoader = m
return m
