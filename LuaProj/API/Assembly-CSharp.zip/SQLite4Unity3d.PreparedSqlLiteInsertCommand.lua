---@class SQLite4Unity3d.PreparedSqlLiteInsertCommand : System.Object
---@field public Initialized boolean
---@field public CommandText string
local m = {}

---@param source any[]
---@return number
function m:ExecuteNonQuery(source) end

---@virtual
function m:Dispose() end

SQLite4Unity3d.PreparedSqlLiteInsertCommand = m
return m
