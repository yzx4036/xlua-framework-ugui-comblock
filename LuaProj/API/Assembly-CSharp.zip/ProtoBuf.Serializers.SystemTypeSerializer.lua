---@class ProtoBuf.Serializers.SystemTypeSerializer : System.Object
---@field public ExpectedType System.Type
local m = {}

ProtoBuf.Serializers.SystemTypeSerializer = m
return m
