---@class ProtoBuf.Meta.TypeFormatEventArgs : System.EventArgs
---@field public Type System.Type
---@field public FormattedName string
local m = {}

ProtoBuf.Meta.TypeFormatEventArgs = m
return m
