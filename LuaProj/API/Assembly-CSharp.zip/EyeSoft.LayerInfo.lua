---@class EyeSoft.LayerInfo : System.Object
---@field public Layer number
---@field public Item fun(gt:HedgehogTeam.EasyTouch.Gesture):boolean
local m = {}

EyeSoft.LayerInfo = m
return m
