---@class UIWindow : UnityEngine.MonoBehaviour
local m = {}

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnDrag(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerDown(eventData) end

UIWindow = m
return m
