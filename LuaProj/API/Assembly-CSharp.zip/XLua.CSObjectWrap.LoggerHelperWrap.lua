---@class XLua.CSObjectWrap.LoggerHelperWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.LoggerHelperWrap = m
return m
