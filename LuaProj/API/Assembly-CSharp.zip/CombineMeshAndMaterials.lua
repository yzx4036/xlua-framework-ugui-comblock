---@class CombineMeshAndMaterials : UnityEngine.MonoBehaviour
local m = {}

CombineMeshAndMaterials = m
return m
