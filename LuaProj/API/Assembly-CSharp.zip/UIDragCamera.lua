---@class UIDragCamera : UnityEngine.MonoBehaviour
---@field public draggableCamera UIDraggableCamera
local m = {}

UIDragCamera = m
return m
