---@class XLua.CSObjectWrap.ETCJoystickWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.ETCJoystickWrap = m
return m
