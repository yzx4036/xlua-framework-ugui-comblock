---@class BattleMapLine : UnityEngine.MonoBehaviour
local m = {}

---@static
---@return UnityEngine.GameObject
function m.BeginDraw() end

function m:OnRenderObject() end

BattleMapLine = m
return m
