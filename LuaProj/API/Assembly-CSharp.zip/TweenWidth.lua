---@class TweenWidth : UITweener
---@field public from number
---@field public to number
---@field public updateTable boolean
---@field public cachedWidget UIWidget
---@field public width number
---@field public value number
local m = {}

---@static
---@param widget UIWidget
---@param duration number
---@param width number
---@return TweenWidth
function m.Begin(widget, duration, width) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenWidth = m
return m
