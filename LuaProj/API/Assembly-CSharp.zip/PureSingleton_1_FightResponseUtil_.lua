---@class PureSingleton_1_FightResponseUtil_ : System.Object
---@field public Instance FightResponseUtil @static
local m = {}

PureSingleton_1_FightResponseUtil_ = m
return m
