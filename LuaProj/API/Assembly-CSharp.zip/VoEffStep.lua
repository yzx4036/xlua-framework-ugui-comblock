---@class VoEffStep : System.Object
---@field public type EnumSkillEffType
---@field public beginTime number
---@field public useTime number
---@field public offsetX number
---@field public offsetY number
---@field public offsetZ number
---@field public speed number
---@field public scale number
---@field public hurtPos number
local m = {}

---@param dataStr string
function m:init(dataStr) end

VoEffStep = m
return m
