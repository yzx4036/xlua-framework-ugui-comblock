---@class LoadNpc : UnityEngine.MonoBehaviour
---@field public NpcName string
---@field public DelayTime number
---@field public IsLowDontLoad boolean
local m = {}

LoadNpc = m
return m
