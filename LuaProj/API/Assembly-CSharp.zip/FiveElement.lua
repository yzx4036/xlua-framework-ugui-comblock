---@class FiveElement : System.Object
---@field public gameObject UnityEngine.GameObject
---@field public transform UnityEngine.Transform
local m = {}

---@param objType EnumFightObjType
function m:Init(objType) end

---@param _status boolean
function m:Visible(_status) end

---@param fiveid number
function m:InitAttr(fiveid) end

---@param fiveId number
function m:SetAttr(fiveId) end

---@param objType EnumFightObjType
function m:Reset(objType) end

function m:RemoveAll() end

---@param _pos UnityEngine.Vector3
function m:Update(_pos) end

function m:Dispose() end

FiveElement = m
return m
