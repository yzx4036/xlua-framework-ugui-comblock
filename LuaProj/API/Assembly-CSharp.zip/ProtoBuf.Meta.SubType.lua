---@class ProtoBuf.Meta.SubType : System.Object
---@field public FieldNumber number
---@field public DerivedType ProtoBuf.Meta.MetaType
local m = {}

ProtoBuf.Meta.SubType = m
return m
