---@class Node : System.Object
---@field public coord Coord
---@field public parent Node
---@field public G number
---@field public H number
---@field public nearCitys Node[]
---@field public nearCityIds number[]
local m = {}

---@param o Node
---@return number
function m:compareTo(o) end

Node = m
return m
