---@class FightResponseUtil.BattleRFun : System.MulticastDelegate
local m = {}

---@virtual
---@param msg ProtoBuf.IExtensible
function m:Invoke(msg) end

---@virtual
---@param msg ProtoBuf.IExtensible
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(msg, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

FightResponseUtil.BattleRFun = m
return m
