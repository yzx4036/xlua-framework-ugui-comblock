---@class EyeSoft.UtilityGameObject : System.Object
local m = {}

---@overload fun(prefab:UnityEngine.GameObject, name:string, parent:UnityEngine.Transform):UnityEngine.GameObject @static
---@static
---@param prefab UnityEngine.GameObject
---@param name string
---@return UnityEngine.GameObject
function m.Clone(prefab, name) end

---@static
---@param prefab UnityEngine.GameObject
---@param pos UnityEngine.Vector3
---@param name string
---@return UnityEngine.GameObject
function m.CloneWithInitPos(prefab, pos, name) end

---@overload fun(parent:UnityEngine.GameObject):UnityEngine.GameObject @static
---@static
---@param parent UnityEngine.GameObject
---@param childName string
---@return UnityEngine.GameObject
function m.AddNewChildTo(parent, childName) end

---@overload fun(parent:UnityEngine.GameObject, prefab:UnityEngine.GameObject, childName:string):UnityEngine.GameObject @static
---@static
---@param parent UnityEngine.GameObject
---@param prefab UnityEngine.GameObject
---@param childName string
---@return UnityEngine.Component
function m.AddPrefabChildTo(parent, prefab, childName) end

---@static
---@param go UnityEngine.GameObject
function m.ClearChildren(go) end

---@static
---@param src UnityEngine.GameObject
---@param dst UnityEngine.GameObject
function m.CopyLocalTransform(src, dst) end

---@static
---@param gameObject UnityEngine.GameObject
function m.Reset(gameObject) end

---@overload fun(root:UnityEngine.GameObject, name:string):UnityEngine.Component @static
---@overload fun(root:UnityEngine.GameObject, index:number):UnityEngine.GameObject @static
---@overload fun(root:UnityEngine.GameObject, index:number):UnityEngine.Component @static
---@static
---@param root UnityEngine.GameObject
---@param name string
---@return UnityEngine.GameObject
function m.GetChild(root, name) end

---@overload fun(root:UnityEngine.GameObject, name:string):UnityEngine.Component @static
---@static
---@param root UnityEngine.GameObject
---@param name string
---@return UnityEngine.GameObject
function m.FindChild(root, name) end

---@static
---@param parent UnityEngine.GameObject
---@param childName string
---@return UnityEngine.GameObject
function m.AddMissingChild(parent, childName) end

---@overload fun(parent:UnityEngine.GameObject, child:UnityEngine.GameObject):UnityEngine.Component @static
---@static
---@param parent UnityEngine.GameObject
---@param child UnityEngine.GameObject
---@param childName string
---@return UnityEngine.Component
function m.AddChildWithComp(parent, child, childName) end

---@static
---@param parent UnityEngine.GameObject
---@param childName string
---@return UnityEngine.Component
function m.AddComp2Child(parent, childName) end

---@static
---@param root UnityEngine.Transform
---@param layer number
function m.ChangeLayerRecursively(root, layer) end

---@static
---@param go UnityEngine.GameObject
---@param index number
---@return UnityEngine.GameObject
function m.GetChildByIndex(go, index) end

---@overload fun(go:UnityEngine.GameObject, type:System.Type) @static
---@overload fun(comp:UnityEngine.Component) @static
---@static
---@param go UnityEngine.GameObject
function m.RemoveComponent(go) end

---@static
---@param obj UnityEngine.GameObject
function m.DestroySelf(obj) end

---@static
---@param go UnityEngine.GameObject
---@param comp any
---@param isCreate boolean
---@return any
function m.CreateOrDestroy(go, comp, isCreate) end

---@static
---@param root UnityEngine.GameObject
---@return UnityEngine.GameObject[]
function m.GetChilds(root) end

---@static
---@param go UnityEngine.GameObject
function m.RemoveAllChildren(go) end

---@overload fun(parent:UnityEngine.GameObject, child:UnityEngine.GameObject, childName:string, worldPositionStays:boolean):UnityEngine.GameObject @static
---@overload fun(parent:UnityEngine.GameObject, child:UnityEngine.GameObject, childName:string):UnityEngine.GameObject @static
---@overload fun(parent:UnityEngine.GameObject, child:UnityEngine.GameObject):UnityEngine.GameObject @static
---@static
---@param parent UnityEngine.GameObject
---@param child UnityEngine.GameObject
---@param childName string
---@param worldPositionStays boolean
---@param isUpdateLayer boolean
---@return UnityEngine.GameObject
function m.AddChildToParent(parent, child, childName, worldPositionStays, isUpdateLayer) end

---@static
---@param parent UnityEngine.GameObject
---@param child UnityEngine.GameObject
---@param worldPositionStays boolean
---@param childName string
---@return UnityEngine.GameObject
function m.AddChild(parent, child, worldPositionStays, childName) end

---@static
---@param parent UnityEngine.GameObject
---@param prefab UnityEngine.GameObject
---@param worldPositionStays boolean
---@param childName string
---@return UnityEngine.GameObject
function m.AddPrefab(parent, prefab, worldPositionStays, childName) end

---@overload fun(parent:UnityEngine.GameObject):UnityEngine.GameObject @static
---@static
---@param parent UnityEngine.GameObject
---@param childName string
---@return UnityEngine.GameObject
function m.AddNewChild(parent, childName) end

---@static
---@param parent UnityEngine.Transform
---@param child UnityEngine.GameObject
---@param worldPositionStays boolean
---@return UnityEngine.RectTransform
function m.AddViewToParent(parent, child, worldPositionStays) end

---@static
---@param parent UnityEngine.Transform
---@param child UnityEngine.GameObject
---@param worldPositionStays boolean
---@param isRecusive boolean
---@return UnityEngine.RectTransform
function m.AddViewToParentRecusive(parent, child, worldPositionStays, isRecusive) end

---@static
---@param go UnityEngine.GameObject
function m.ReParent(go) end

---@static
---@param target UnityEngine.GameObject
---@param layer number
---@param recuresively boolean
function m.SetLayer(target, layer, recuresively) end

---@static
---@param src UnityEngine.GameObject
---@param dst UnityEngine.GameObject
---@param recursive boolean
function m.SyncLayer(src, dst, recursive) end

---@static
---@param path string
---@return UnityEngine.GameObject
function m.AddGameObject(path) end

---@static
---@param goCanvas UnityEngine.GameObject
---@return UnityEngine.Canvas
function m.AddCanvasComponent(goCanvas) end

---@static
---@param goCanvas UnityEngine.GameObject
---@return UnityEngine.Canvas
function m.AddPanelCanvas(goCanvas) end

---@static
---@param go UnityEngine.GameObject
---@param name string
function m.PlayAnimByName(go, name) end

---@static
---@param go UnityEngine.GameObject
---@return UnityEngine.Component
function m.AddComponet(go) end

---@static
---@param go UnityEngine.GameObject
---@return UnityEngine.Component
function m.AddComponetIfNone(go) end

---@static
---@param go UnityEngine.GameObject
---@return string
function m.GetFullPath(go) end

EyeSoft.UtilityGameObject = m
return m
