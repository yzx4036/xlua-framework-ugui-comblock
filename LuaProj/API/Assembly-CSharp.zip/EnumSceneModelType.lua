---@class EnumSceneModelType : System.Enum
---@field public D3 EnumSceneModelType @static
---@field public D2 EnumSceneModelType @static
---@field public value__ number
local m = {}

EnumSceneModelType = m
return m
