---@class LoadLevelOnClick : UnityEngine.MonoBehaviour
---@field public levelName string
local m = {}

LoadLevelOnClick = m
return m
