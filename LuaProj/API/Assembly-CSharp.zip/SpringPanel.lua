---@class SpringPanel : UnityEngine.MonoBehaviour
---@field public current SpringPanel @static
---@field public target UnityEngine.Vector3
---@field public strength number
---@field public onFinished fun()
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param pos UnityEngine.Vector3
---@param strength number
---@return SpringPanel
function m.Begin(go, pos, strength) end

SpringPanel = m
return m
