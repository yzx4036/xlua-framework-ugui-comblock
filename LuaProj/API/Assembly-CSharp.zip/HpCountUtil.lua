---@class HpCountUtil : PureSingleton_1_HpCountUtil_
local m = {}

function m:UpdataHpAndAngry() end

---@param order number
---@param direct EnumFightDirect
---@return boolean
function m:GetIsLastDie(order, direct) end

HpCountUtil = m
return m
