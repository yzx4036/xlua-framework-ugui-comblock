---@class UIKeyNavigation.Constraint : System.Enum
---@field public None UIKeyNavigation.Constraint @static
---@field public Vertical UIKeyNavigation.Constraint @static
---@field public Horizontal UIKeyNavigation.Constraint @static
---@field public Explicit UIKeyNavigation.Constraint @static
---@field public value__ number
local m = {}

UIKeyNavigation.Constraint = m
return m
