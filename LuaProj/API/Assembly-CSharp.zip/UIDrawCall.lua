---@class UIDrawCall : UnityEngine.MonoBehaviour
---@field public list BetterList_1_UIDrawCall_ @static
---@field public activeList BetterList_1_UIDrawCall_ @static
---@field public inactiveList BetterList_1_UIDrawCall_ @static
---@field public widgetCount number
---@field public depthStart number
---@field public depthEnd number
---@field public manager UIPanel
---@field public panel UIPanel
---@field public clipTexture UnityEngine.Texture2D
---@field public alwaysOnScreen boolean
---@field public verts BetterList_1_UnityEngine_Vector3_
---@field public norms BetterList_1_UnityEngine_Vector3_
---@field public tans BetterList_1_UnityEngine_Vector4_
---@field public uvs BetterList_1_UnityEngine_Vector2_
---@field public uvs1 BetterList_1_UnityEngine_Vector2_
---@field public cols BetterList_1_UnityEngine_Color32_
---@field public isDirty boolean
---@field public onRender fun(mat:UnityEngine.Material)
---@field public renderQueue number
---@field public sortingOrder number
---@field public sortingLayerName string
---@field public finalRenderQueue number
---@field public isActive boolean
---@field public cachedTransform UnityEngine.Transform
---@field public baseMaterial UnityEngine.Material
---@field public dynamicMaterial UnityEngine.Material
---@field public mainTexture UnityEngine.Texture
---@field public shader UnityEngine.Shader
---@field public triangles number
---@field public isClipped boolean
local m = {}

---@param widgetCount number
function m:UpdateGeometry(widgetCount) end

---@static
---@param panel UIPanel
---@param mat UnityEngine.Material
---@param tex UnityEngine.Texture
---@param shader UnityEngine.Shader
---@return UIDrawCall
function m.Create(panel, mat, tex, shader) end

---@static
function m.ClearAll() end

---@static
function m.ReleaseAll() end

---@static
function m.ReleaseInactive() end

---@static
---@param panel UIPanel
---@return number
function m.Count(panel) end

---@static
---@param dc UIDrawCall
function m.Destroy(dc) end

UIDrawCall = m
return m
