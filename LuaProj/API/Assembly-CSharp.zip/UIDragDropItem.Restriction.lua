---@class UIDragDropItem.Restriction : System.Enum
---@field public None UIDragDropItem.Restriction @static
---@field public Horizontal UIDragDropItem.Restriction @static
---@field public Vertical UIDragDropItem.Restriction @static
---@field public PressAndHold UIDragDropItem.Restriction @static
---@field public value__ number
local m = {}

UIDragDropItem.Restriction = m
return m
