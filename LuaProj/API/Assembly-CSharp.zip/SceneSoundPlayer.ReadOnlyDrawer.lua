---@class SceneSoundPlayer.ReadOnlyDrawer : UnityEditor.PropertyDrawer
local m = {}

---@virtual
---@param property UnityEditor.SerializedProperty
---@param label UnityEngine.GUIContent
---@return number
function m:GetPropertyHeight(property, label) end

---@virtual
---@param position UnityEngine.Rect
---@param property UnityEditor.SerializedProperty
---@param label UnityEngine.GUIContent
function m:OnGUI(position, property, label) end

SceneSoundPlayer.ReadOnlyDrawer = m
return m
