---@class AnimationOrTween.Trigger : System.Enum
---@field public OnClick AnimationOrTween.Trigger @static
---@field public OnHover AnimationOrTween.Trigger @static
---@field public OnPress AnimationOrTween.Trigger @static
---@field public OnHoverTrue AnimationOrTween.Trigger @static
---@field public OnHoverFalse AnimationOrTween.Trigger @static
---@field public OnPressTrue AnimationOrTween.Trigger @static
---@field public OnPressFalse AnimationOrTween.Trigger @static
---@field public OnActivate AnimationOrTween.Trigger @static
---@field public OnActivateTrue AnimationOrTween.Trigger @static
---@field public OnActivateFalse AnimationOrTween.Trigger @static
---@field public OnDoubleClick AnimationOrTween.Trigger @static
---@field public OnSelect AnimationOrTween.Trigger @static
---@field public OnSelectTrue AnimationOrTween.Trigger @static
---@field public OnSelectFalse AnimationOrTween.Trigger @static
---@field public value__ number
local m = {}

AnimationOrTween.Trigger = m
return m
