---@class Localization : System.Object
---@field public loadFunction fun(path:string):string @static
---@field public onLocalize fun() @static
---@field public localizationHasBeenSet boolean @static
---@field public dictionary System.Collections.Generic.Dictionary_2_System_String_System_String___ @static
---@field public knownLanguages string[] @static
---@field public language string @static
---@field public isActive boolean @static
local m = {}

---@static
---@param asset UnityEngine.TextAsset
function m.Load(asset) end

---@overload fun(languageName:string, dictionary:System.Collections.Generic.Dictionary_2_System_String_System_String_) @static
---@overload fun(key:string, value:string) @static
---@overload fun(language:string, key:string, text:string) @static
---@static
---@param languageName string
---@param bytes string
function m.Set(languageName, bytes) end

---@static
---@param key string
---@param val string
function m.ReplaceKey(key, val) end

---@static
function m.ClearReplacements() end

---@overload fun(asset:UnityEngine.TextAsset):boolean @static
---@overload fun(bytes:string, merge:boolean):boolean @static
---@overload fun(bytes:string):boolean @static
---@static
---@param asset UnityEngine.TextAsset
---@param merge boolean
---@return boolean
function m.LoadCSV(asset, merge) end

---@static
---@param key string
---@return string
function m.Get(key) end

---@overload fun(key:string):string @static
---@static
---@param key string
---@param parameters any[]|any
---@return string
function m.Format(key, parameters) end

---@static
---@param key string
---@return string
function m.Localize(key) end

---@static
---@param key string
---@return boolean
function m.Exists(key) end

Localization = m
return m
