---@class UIWrapContent2 : UnityEngine.MonoBehaviour
---@field public onInitializeItem fun(go:UnityEngine.GameObject, index:number)
---@field public prefab UnityEngine.GameObject
local m = {}

---@return number
function m:GetCount() end

---@return number
function m:GetFirstIndex() end

---@return number
function m:GetLastIndex() end

---@overload fun(count:number)
function m:ResetPosition() end

---@param count number
function m:Refresh(count) end

---@virtual
function m:WrapContent() end

UIWrapContent2 = m
return m
