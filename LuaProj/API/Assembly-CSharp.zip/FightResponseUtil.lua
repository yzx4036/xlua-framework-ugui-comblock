---@class FightResponseUtil : PureSingleton_1_FightResponseUtil_
---@field public delay number
local m = {}

function m:Reset() end

---@param cmd number
---@param time number
---@param bdata ProtoBuf.IExtensible
function m:AddData(cmd, time, bdata) end

function m:Update() end

FightResponseUtil = m
return m
