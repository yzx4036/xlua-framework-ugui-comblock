---@class TouchPadUIEvent : UnityEngine.MonoBehaviour
---@field public touchDownText UnityEngine.UI.Text
---@field public touchText UnityEngine.UI.Text
---@field public touchUpText UnityEngine.UI.Text
local m = {}

function m:TouchDown() end

---@param value UnityEngine.Vector2
function m:TouchEvt(value) end

function m:TouchUp() end

TouchPadUIEvent = m
return m
