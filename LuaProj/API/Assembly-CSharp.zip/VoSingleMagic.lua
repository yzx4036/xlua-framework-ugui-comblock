---@class VoSingleMagic : System.Object
---@field public effStepVo VoEffStep
---@field public posX number
---@field public posY number
---@field public posZ number
---@field public bindMagics MagicBindTarget[]
local m = {}

VoSingleMagic = m
return m
