---@class XLua.CSObjectWrap.UnityEngineObjectExtentionWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineObjectExtentionWrap = m
return m
