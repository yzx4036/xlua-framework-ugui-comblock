---@class UIInput.KeyboardType : System.Enum
---@field public Default UIInput.KeyboardType @static
---@field public ASCIICapable UIInput.KeyboardType @static
---@field public NumbersAndPunctuation UIInput.KeyboardType @static
---@field public URL UIInput.KeyboardType @static
---@field public NumberPad UIInput.KeyboardType @static
---@field public PhonePad UIInput.KeyboardType @static
---@field public NamePhonePad UIInput.KeyboardType @static
---@field public EmailAddress UIInput.KeyboardType @static
---@field public value__ number
local m = {}

UIInput.KeyboardType = m
return m
