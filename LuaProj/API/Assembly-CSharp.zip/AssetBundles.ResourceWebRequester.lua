---@class AssetBundles.ResourceWebRequester : AssetBundles.ResourceAsyncOperation
---@field public Sequence number
---@field public noCache boolean
---@field public assetbundleName string
---@field public url string
---@field public assetbundle UnityEngine.AssetBundle
---@field public bytes string
---@field public text string
---@field public error string
local m = {}

---@static
---@return AssetBundles.ResourceWebRequester
function m.Get() end

---@static
---@param creater AssetBundles.ResourceWebRequester
function m.Recycle(creater) end

---@overload fun(name:string, url:string, noCache:boolean)
---@overload fun(name:string, url:string)
---@param name string
---@param url string
---@param noCache boolean
---@param isLoadBundle boolean
function m:Init(name, url, noCache, isLoadBundle) end

---@virtual
---@return boolean
function m:IsDone() end

function m:Start() end

---@virtual
---@return number
function m:Progress() end

---@virtual
function m:Update() end

---@virtual
function m:Dispose() end

AssetBundles.ResourceWebRequester = m
return m
