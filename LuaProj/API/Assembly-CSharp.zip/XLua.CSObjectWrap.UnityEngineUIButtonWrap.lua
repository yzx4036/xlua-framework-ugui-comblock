---@class XLua.CSObjectWrap.UnityEngineUIButtonWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineUIButtonWrap = m
return m
