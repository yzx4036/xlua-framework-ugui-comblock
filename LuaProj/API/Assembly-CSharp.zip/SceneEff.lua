---@class SceneEff : UnityEngine.MonoBehaviour
---@field public EffName string
---@field public DelayTime number
---@field public IsLowDontLoad boolean
local m = {}

SceneEff = m
return m
