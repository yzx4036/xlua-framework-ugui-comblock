---@class SQLite4Unity3d.CreateFlags : System.Enum
---@field public None SQLite4Unity3d.CreateFlags @static
---@field public ImplicitPK SQLite4Unity3d.CreateFlags @static
---@field public ImplicitIndex SQLite4Unity3d.CreateFlags @static
---@field public AllImplicit SQLite4Unity3d.CreateFlags @static
---@field public AutoIncPK SQLite4Unity3d.CreateFlags @static
---@field public value__ number
local m = {}

SQLite4Unity3d.CreateFlags = m
return m
