---@class UICursor : UnityEngine.MonoBehaviour
---@field public instance UICursor @static
---@field public uiCamera UnityEngine.Camera
local m = {}

---@static
function m.Clear() end

---@static
---@param atlas UIAtlas
---@param sprite string
function m.Set(atlas, sprite) end

UICursor = m
return m
