---@class Singleton_1_T_ : System.Object
---@field public instance any @static
local m = {}

---@static
function m.Release() end

---@virtual
function m:Init() end

---@abstract
function m:Dispose() end

Singleton_1_T_ = m
return m
