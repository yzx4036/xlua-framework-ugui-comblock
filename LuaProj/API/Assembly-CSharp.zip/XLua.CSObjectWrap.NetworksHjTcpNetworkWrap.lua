---@class XLua.CSObjectWrap.NetworksHjTcpNetworkWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.NetworksHjTcpNetworkWrap = m
return m
