---@class Singleton_1_EyeSoft_EventManager_ : System.Object
---@field public instance EyeSoft.EventManager @static
local m = {}

---@static
function m.Release() end

---@virtual
function m:Init() end

---@abstract
function m:Dispose() end

Singleton_1_EyeSoft_EventManager_ = m
return m
