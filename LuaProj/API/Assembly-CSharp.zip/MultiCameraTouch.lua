---@class MultiCameraTouch : UnityEngine.MonoBehaviour
---@field public label UnityEngine.UI.Text
local m = {}

MultiCameraTouch = m
return m
