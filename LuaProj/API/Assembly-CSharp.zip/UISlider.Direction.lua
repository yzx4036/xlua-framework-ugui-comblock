---@class UISlider.Direction : System.Enum
---@field public Horizontal UISlider.Direction @static
---@field public Vertical UISlider.Direction @static
---@field public Upgraded UISlider.Direction @static
---@field public value__ number
local m = {}

UISlider.Direction = m
return m
