---@class ProtoBuf.Extensible : System.Object
local m = {}

---@static
---@param extensionObject ProtoBuf.IExtension
---@param createIfMissing boolean
---@return ProtoBuf.IExtension, ProtoBuf.IExtension
function m.GetExtensionObject(extensionObject, createIfMissing) end

---@overload fun(instance:ProtoBuf.IExtensible, tag:number, format:ProtoBuf.DataFormat, value:any) @static
---@overload fun(model:ProtoBuf.Meta.TypeModel, instance:ProtoBuf.IExtensible, tag:number, format:ProtoBuf.DataFormat, value:any) @static
---@static
---@param instance ProtoBuf.IExtensible
---@param tag number
---@param value any
function m.AppendValue(instance, tag, value) end

---@overload fun(instance:ProtoBuf.IExtensible, tag:number, format:ProtoBuf.DataFormat):any @static
---@static
---@param instance ProtoBuf.IExtensible
---@param tag number
---@return any
function m.GetValue(instance, tag) end

---@overload fun(instance:ProtoBuf.IExtensible, tag:number, format:ProtoBuf.DataFormat):boolean, any @static
---@overload fun(instance:ProtoBuf.IExtensible, tag:number, format:ProtoBuf.DataFormat, allowDefinedTag:boolean):boolean, any @static
---@overload fun(model:ProtoBuf.Meta.TypeModel, type:System.Type, instance:ProtoBuf.IExtensible, tag:number, format:ProtoBuf.DataFormat, allowDefinedTag:boolean):boolean, System.Object @static
---@static
---@param instance ProtoBuf.IExtensible
---@param tag number
---@return boolean, any
function m.TryGetValue(instance, tag) end

---@overload fun(instance:ProtoBuf.IExtensible, tag:number, format:ProtoBuf.DataFormat):any @static
---@overload fun(model:ProtoBuf.Meta.TypeModel, type:System.Type, instance:ProtoBuf.IExtensible, tag:number, format:ProtoBuf.DataFormat):System.Collections.IEnumerable @static
---@static
---@param instance ProtoBuf.IExtensible
---@param tag number
---@return any
function m.GetValues(instance, tag) end

ProtoBuf.Extensible = m
return m
