---@class UIDrawCall.OnRenderCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param mat UnityEngine.Material
function m:Invoke(mat) end

---@virtual
---@param mat UnityEngine.Material
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(mat, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UIDrawCall.OnRenderCallback = m
return m
