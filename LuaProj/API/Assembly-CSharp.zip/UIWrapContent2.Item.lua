---@class UIWrapContent2.Item : System.Object
---@field public pivotOffset UnityEngine.Vector2
---@field public mTrans UnityEngine.Transform
---@field public mObj UnityEngine.GameObject
---@field public mWidget UIWidget
---@field public position UnityEngine.Vector3
---@field public posX number
---@field public posY number
---@field public topPos number
---@field public bottomPos number
---@field public width number
---@field public halfWidth number
---@field public height number
local m = {}

UIWrapContent2.Item = m
return m
