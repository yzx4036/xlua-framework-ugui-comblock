---@class AssetBundles.Manifest : System.Object
---@field public assetbundleManifest UnityEngine.AssetBundleManifest
---@field public AssetbundleName string
---@field public Length number
local m = {}

---@param assetbundle UnityEngine.AssetBundle
function m:LoadFromAssetbundle(assetbundle) end

---@param bytes string
function m:SaveBytes(bytes) end

function m:SaveToDiskCahce() end

---@param name string
---@return UnityEngine.Hash128
function m:GetAssetBundleHash(name) end

---@return string[]
function m:GetAllAssetBundleNames() end

---@return string[]
function m:GetAllAssetBundlesWithVariant() end

---@param assetbundleName string
---@return string[]
function m:GetAllDependencies(assetbundleName) end

---@param assetbundleName string
---@return string[]
function m:GetDirectDependencies(assetbundleName) end

---@param otherManifest AssetBundles.Manifest
---@return string[]
function m:CompareTo(otherManifest) end

AssetBundles.Manifest = m
return m
