---@class Test2DAni : UnityEngine.MonoBehaviour
---@field public action EnumAction
---@field public way number
local m = {}

Test2DAni = m
return m
