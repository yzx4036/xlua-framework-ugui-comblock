---@class Networks.HjNetworkEvt : System.ValueType
---@field public sender any
---@field public result number
---@field public msg string
---@field public evtHandle fun(arg1:any, arg2:number, arg3:string)
local m = {}

Networks.HjNetworkEvt = m
return m
