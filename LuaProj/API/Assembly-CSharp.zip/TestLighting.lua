---@class TestLighting : UnityEngine.MonoBehaviour
local m = {}

TestLighting = m
return m
