---@class ProtoBuf.ProtoReader : System.Object
---@field public FieldNumber number
---@field public WireType ProtoBuf.WireType
---@field public InternStrings boolean
---@field public Context ProtoBuf.SerializationContext
---@field public Position number
---@field public Model ProtoBuf.Meta.TypeModel
local m = {}

---@virtual
function m:Dispose() end

---@return number
function m:ReadUInt32() end

---@return number
function m:ReadInt16() end

---@return number
function m:ReadUInt16() end

---@return number
function m:ReadByte() end

---@return number
function m:ReadSByte() end

---@return number
function m:ReadInt32() end

---@return number
function m:ReadInt64() end

---@return string
function m:ReadString() end

---@param type System.Type
---@param value number
function m:ThrowEnumException(type, value) end

---@return number
function m:ReadDouble() end

---@static
---@param value any
---@param key number
---@param reader ProtoBuf.ProtoReader
---@return any
function m.ReadObject(value, key, reader) end

---@static
---@param token ProtoBuf.SubItemToken
---@param reader ProtoBuf.ProtoReader
function m.EndSubItem(token, reader) end

---@static
---@param reader ProtoBuf.ProtoReader
---@return ProtoBuf.SubItemToken
function m.StartSubItem(reader) end

---@return number
function m:ReadFieldHeader() end

---@param field number
---@return boolean
function m:TryReadFieldHeader(field) end

---@param wireType ProtoBuf.WireType
function m:Hint(wireType) end

---@param wireType ProtoBuf.WireType
function m:Assert(wireType) end

function m:SkipField() end

---@return number
function m:ReadUInt64() end

---@return number
function m:ReadSingle() end

---@return boolean
function m:ReadBoolean() end

---@overload fun(value:string, reader:ProtoBuf.ProtoReader):string @static
---@static
---@param value string
---@param reader ProtoBuf.ProtoReader
---@param bufferPoolDelegate fun(expectedSize:number):string
---@return string
function m.AppendBytes(value, reader, bufferPoolDelegate) end

---@overload fun(source:System.IO.Stream, expectHeader:boolean, style:ProtoBuf.PrefixStyle):number, System.Int32, System.Int32 @static
---@static
---@param source System.IO.Stream
---@param expectHeader boolean
---@param style ProtoBuf.PrefixStyle
---@return number, System.Int32
function m.ReadLengthPrefix(source, expectHeader, style) end

---@static
---@param source System.IO.Stream
---@return number
function m.DirectReadLittleEndianInt32(source) end

---@static
---@param source System.IO.Stream
---@return number
function m.DirectReadBigEndianInt32(source) end

---@static
---@param source System.IO.Stream
---@return number
function m.DirectReadVarintInt32(source) end

---@overload fun(source:System.IO.Stream, count:number):string @static
---@static
---@param source System.IO.Stream
---@param buffer string
---@param offset number
---@param count number
function m.DirectReadBytes(source, buffer, offset, count) end

---@static
---@param source System.IO.Stream
---@param length number
---@return string
function m.DirectReadString(source, length) end

---@param instance ProtoBuf.IExtensible
function m:AppendExtensionData(instance) end

---@static
---@param wireType ProtoBuf.WireType
---@param source ProtoBuf.ProtoReader
---@return boolean
function m.HasSubValue(wireType, source) end

---@static
---@param value any
---@param reader ProtoBuf.ProtoReader
function m.NoteObject(value, reader) end

---@return System.Type
function m:ReadType() end

---@static
---@param parent ProtoBuf.ProtoReader
---@param from any
---@param to any
---@return any
function m.Merge(parent, from, to) end

ProtoBuf.ProtoReader = m
return m
