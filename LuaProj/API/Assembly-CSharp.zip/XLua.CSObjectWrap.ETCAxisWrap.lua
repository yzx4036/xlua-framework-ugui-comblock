---@class XLua.CSObjectWrap.ETCAxisWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.ETCAxisWrap = m
return m
