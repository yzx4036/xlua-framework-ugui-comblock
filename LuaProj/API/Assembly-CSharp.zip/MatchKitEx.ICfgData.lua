---@class MatchKitEx.ICfgData : table
local m = {}

---@abstract
function m:Initialize() end

MatchKitEx.ICfgData = m
return m
