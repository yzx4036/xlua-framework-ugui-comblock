---@class UIButtonColor.State : System.Enum
---@field public Normal UIButtonColor.State @static
---@field public Hover UIButtonColor.State @static
---@field public Pressed UIButtonColor.State @static
---@field public Disabled UIButtonColor.State @static
---@field public value__ number
local m = {}

UIButtonColor.State = m
return m
