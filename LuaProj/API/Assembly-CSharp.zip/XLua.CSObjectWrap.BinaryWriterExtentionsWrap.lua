---@class XLua.CSObjectWrap.BinaryWriterExtentionsWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.BinaryWriterExtentionsWrap = m
return m
