---@class UIEventListener.KeyCodeDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param go UnityEngine.GameObject
---@param key UnityEngine.KeyCode
function m:Invoke(go, key) end

---@virtual
---@param go UnityEngine.GameObject
---@param key UnityEngine.KeyCode
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(go, key, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UIEventListener.KeyCodeDelegate = m
return m
