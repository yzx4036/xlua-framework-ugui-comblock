---@class UIInput.Validation : System.Enum
---@field public None UIInput.Validation @static
---@field public Integer UIInput.Validation @static
---@field public Float UIInput.Validation @static
---@field public Alphanumeric UIInput.Validation @static
---@field public Username UIInput.Validation @static
---@field public Name UIInput.Validation @static
---@field public Filename UIInput.Validation @static
---@field public value__ number
local m = {}

UIInput.Validation = m
return m
