---@class EnumBindPoint : System.Enum
---@field public ROOT EnumBindPoint @static
---@field public HEAD EnumBindPoint @static
---@field public HIT EnumBindPoint @static
---@field public HAND_RIGHT EnumBindPoint @static
---@field public HAND_LEFT EnumBindPoint @static
---@field public MA_AN EnumBindPoint @static
---@field public WEAPON_RIGHT EnumBindPoint @static
---@field public WEAPON_LEFT EnumBindPoint @static
---@field public EFF1 EnumBindPoint @static
---@field public EFF2 EnumBindPoint @static
---@field public EFF3 EnumBindPoint @static
---@field public WALL_HIT EnumBindPoint @static
---@field public value__ number
local m = {}

EnumBindPoint = m
return m
