---@class ProtoFactory : System.Object
local m = {}

---@static
---@param protoType System.Type
---@param protoPool IProtoPool
function m.AddProtoPool(protoType, protoPool) end

---@static
---@param protoType System.Type
function m.RemoveProtoPool(protoType) end

---@static
function m.ClearProtoPool() end

---@overload fun():any @static
---@static
---@param protoType System.Type
---@return any
function m.Get(protoType) end

---@static
---@param protoData any
function m.Recycle(protoData) end

---@static
---@param protoData any
---@return any
function m.DeepCopy(protoData) end

---@static
function m.Dispose() end

ProtoFactory = m
return m
