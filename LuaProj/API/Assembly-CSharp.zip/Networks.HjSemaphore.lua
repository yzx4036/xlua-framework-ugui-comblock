---@class Networks.HjSemaphore : System.Object
local m = {}

---@overload fun(count:number)
function m:WaitResource() end

---@overload fun(count:number)
function m:ProduceResrouce() end

Networks.HjSemaphore = m
return m
