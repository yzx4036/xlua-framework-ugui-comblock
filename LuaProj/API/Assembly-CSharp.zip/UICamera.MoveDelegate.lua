---@class UICamera.MoveDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param delta UnityEngine.Vector2
function m:Invoke(delta) end

---@virtual
---@param delta UnityEngine.Vector2
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(delta, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UICamera.MoveDelegate = m
return m
