---@class MapEditor.CreateLineLua : System.Object
local m = {}

---@static
---@param mLineDic System.Collections.Generic.Dictionary_2_System_String_MapEditor_CityLineInfo_
---@param fileName string
function m.CreateLuaFile(mLineDic, fileName) end

---@static
---@param path string
---@return string
function m.GetFileName(path) end

MapEditor.CreateLineLua = m
return m
