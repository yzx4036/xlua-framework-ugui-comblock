---@class XLua.CSObjectWrap.MessageNameWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.MessageNameWrap = m
return m
