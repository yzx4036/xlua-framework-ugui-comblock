---@class ProtoBuf.ProtoBeforeSerializationAttribute : System.Attribute
local m = {}

ProtoBuf.ProtoBeforeSerializationAttribute = m
return m
