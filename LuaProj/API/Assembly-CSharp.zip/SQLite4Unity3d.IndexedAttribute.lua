---@class SQLite4Unity3d.IndexedAttribute : System.Attribute
---@field public Name string
---@field public Order number
---@field public Unique boolean
local m = {}

SQLite4Unity3d.IndexedAttribute = m
return m
