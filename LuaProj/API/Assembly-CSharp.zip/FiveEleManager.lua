---@class FiveEleManager : System.Object
---@field public fiveElePool FiveElement[] @static
local m = {}

---@static
---@param objType EnumFightObjType
---@return FiveElement
function m.GetFiveElemenet(objType) end

---@static
---@param fiveEle FiveElement
function m.ReleaseFiveEle(fiveEle) end

---@param id number
function m:InitFive(id) end

---@param fiveId number
function m:SetFiveData(fiveId) end

function m:ShowFive() end

function m:RemoveFive() end

function m:Release() end

FiveEleManager = m
return m
