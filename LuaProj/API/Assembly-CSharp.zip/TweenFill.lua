---@class TweenFill : UITweener
---@field public from number
---@field public to number
---@field public value number
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param fill number
---@return TweenFill
function m.Begin(go, duration, fill) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenFill = m
return m
