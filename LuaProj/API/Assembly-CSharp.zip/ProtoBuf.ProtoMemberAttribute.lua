---@class ProtoBuf.ProtoMemberAttribute : System.Attribute
---@field public Name string
---@field public DataFormat ProtoBuf.DataFormat
---@field public Tag number
---@field public IsRequired boolean
---@field public IsPacked boolean
---@field public OverwriteList boolean
---@field public AsReference boolean
---@field public DynamicType boolean
---@field public Options ProtoBuf.MemberSerializationOptions
local m = {}

---@overload fun(other:ProtoBuf.ProtoMemberAttribute):number @virtual
---@virtual
---@param other any
---@return number
function m:CompareTo(other) end

ProtoBuf.ProtoMemberAttribute = m
return m
