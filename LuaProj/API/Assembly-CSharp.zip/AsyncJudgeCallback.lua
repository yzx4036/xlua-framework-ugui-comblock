---@class AsyncJudgeCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param path string
---@return boolean
function m:Invoke(path) end

---@virtual
---@param path string
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(path, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return boolean
function m:EndInvoke(result) end

AsyncJudgeCallback = m
return m
