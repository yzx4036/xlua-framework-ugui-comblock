---@class EffectKey : System.ValueType
---@field public Path string
---@field public BindPoint EnumBindPoint
local m = {}

EffectKey = m
return m
