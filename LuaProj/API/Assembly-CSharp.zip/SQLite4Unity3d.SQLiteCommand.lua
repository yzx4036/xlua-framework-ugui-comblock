---@class SQLite4Unity3d.SQLiteCommand : System.Object
---@field public CommandText string
local m = {}

---@return number
function m:ExecuteNonQuery() end

---@overload fun(map:SQLite4Unity3d.TableMapping):any
---@return any
function m:ExecuteDeferredQuery() end

---@overload fun(map:SQLite4Unity3d.TableMapping):any[]
---@return any[]
function m:ExecuteQuery() end

---@return any
function m:ExecuteScalar() end

---@overload fun(val:any)
---@param name string
---@param val any
function m:Bind(name, val) end

---@virtual
---@return string
function m:ToString() end

SQLite4Unity3d.SQLiteCommand = m
return m
