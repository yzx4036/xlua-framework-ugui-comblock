---@class SkEffBase : System.Object
local m = {}

SkEffBase = m
return m
