---@class AnimatedWidget : UnityEngine.MonoBehaviour
---@field public width number
---@field public height number
local m = {}

AnimatedWidget = m
return m
