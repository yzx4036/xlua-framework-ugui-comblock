---@class MultiLayerTouch : UnityEngine.MonoBehaviour
---@field public label UnityEngine.UI.Text
---@field public label2 UnityEngine.UI.Text
local m = {}

MultiLayerTouch = m
return m
