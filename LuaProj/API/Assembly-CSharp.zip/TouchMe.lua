---@class TouchMe : UnityEngine.MonoBehaviour
local m = {}

TouchMe = m
return m
