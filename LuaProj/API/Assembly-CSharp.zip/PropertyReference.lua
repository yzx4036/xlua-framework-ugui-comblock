---@class PropertyReference : System.Object
---@field public target UnityEngine.Component
---@field public name string
---@field public isValid boolean
---@field public isEnabled boolean
local m = {}

---@return System.Type
function m:GetPropertyType() end

---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@overload fun(value:any):boolean
---@param target UnityEngine.Component
---@param methodName string
function m:Set(target, methodName) end

function m:Clear() end

function m:Reset() end

---@overload fun(comp:UnityEngine.Component, property:string):string @static
---@virtual
---@return string
function m:ToString() end

---@return any
function m:Get() end

---@overload fun(value:any, to:System.Type):boolean @static
---@overload fun(value:System.Object, from:System.Type, to:System.Type):boolean, System.Object @static
---@static
---@param from System.Type
---@param to System.Type
---@return boolean
function m.Convert(from, to) end

PropertyReference = m
return m
