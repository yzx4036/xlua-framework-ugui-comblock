---@class FPS : UnityEngine.MonoBehaviour
---@field public f_UpdateInterval number
local m = {}

FPS = m
return m
