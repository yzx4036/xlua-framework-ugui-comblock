---@class OneCmdPool : ProtoPoolBase_1_battle_one_cmd_
local m = {}

---@virtual
---@param data any
---@return any
function m:DeepCopy(data) end

OneCmdPool = m
return m
