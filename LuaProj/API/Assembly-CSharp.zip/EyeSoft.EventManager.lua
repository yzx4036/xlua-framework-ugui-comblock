---@class EyeSoft.EventManager : Singleton_1_EyeSoft_EventManager_
---@field public Module UnityEngine.EventSystems.StandaloneInputModule
---@field public Current UnityEngine.EventSystems.EventSystem
local m = {}

---@param enable boolean
function m:SetEnable(enable) end

---@virtual
function m:Init() end

---@virtual
function m:Dispose() end

EyeSoft.EventManager = m
return m
