---@class UIWidget.Pivot : System.Enum
---@field public TopLeft UIWidget.Pivot @static
---@field public Top UIWidget.Pivot @static
---@field public TopRight UIWidget.Pivot @static
---@field public Left UIWidget.Pivot @static
---@field public Center UIWidget.Pivot @static
---@field public Right UIWidget.Pivot @static
---@field public BottomLeft UIWidget.Pivot @static
---@field public Bottom UIWidget.Pivot @static
---@field public BottomRight UIWidget.Pivot @static
---@field public value__ number
local m = {}

UIWidget.Pivot = m
return m
