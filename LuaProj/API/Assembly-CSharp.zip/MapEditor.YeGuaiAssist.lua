---@class MapEditor.YeGuaiAssist : MapEditor.ElementBaseAssist
local m = {}

MapEditor.YeGuaiAssist = m
return m
