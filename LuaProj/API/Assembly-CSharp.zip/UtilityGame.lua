---@class UtilityGame : System.Object
---@field public AssetsFolderName string @static
local m = {}

---@static
---@param path string
---@return string
function m.FormatToUnityPath(path) end

---@static
---@param path string
---@return string
function m.FormatToSysFilePath(path) end

---@static
---@param full_path string
---@return string
function m.FullPathToAssetPath(full_path) end

---@static
---@param path string
---@return string
function m.GetFileExtension(path) end

---@overload fun(path:string, extensions:string[]):string[] @static
---@overload fun(path:string):string[] @static
---@overload fun(path:string, pattern:string):string[] @static
---@static
---@param path string
---@param extensions string[]
---@param exclude boolean
---@return string[]
function m.GetSpecifyFilesInFolder(path, extensions, exclude) end

---@static
---@param path string
---@return string[]
function m.GetAllFilesInFolder(path) end

---@static
---@param path string
---@return string[]
function m.GetAllDirsInFolder(path) end

---@static
---@param filePath string
function m.CheckFileAndCreateDirWhenNeeded(filePath) end

---@static
---@param folderPath string
function m.CheckDirAndCreateWhenNeeded(folderPath) end

---@static
---@param outFile string
---@param outBytes string
---@return boolean
function m.SafeWriteAllBytes(outFile, outBytes) end

---@static
---@param outFile string
---@param outLines string[]
---@return boolean
function m.SafeWriteAllLines(outFile, outLines) end

---@static
---@param outFile string
---@param text string
---@return boolean
function m.SafeWriteAllText(outFile, text) end

---@static
---@param inFile string
---@return string
function m.SafeReadAllBytes(inFile) end

---@static
---@param inFile string
---@return string[]
function m.SafeReadAllLines(inFile) end

---@static
---@param inFile string
---@return string
function m.SafeReadAllText(inFile) end

---@static
---@param dirPath string
function m.DeleteDirectory(dirPath) end

---@static
---@param folderPath string
---@return boolean
function m.SafeClearDir(folderPath) end

---@static
---@param folderPath string
---@return boolean
function m.SafeDeleteDir(folderPath) end

---@static
---@param filePath string
---@return boolean
function m.SafeDeleteFile(filePath) end

---@static
---@param sourceFileName string
---@param destFileName string
---@return boolean
function m.SafeRenameFile(sourceFileName, destFileName) end

---@static
---@param fromFile string
---@param toFile string
---@return boolean
function m.SafeCopyFile(fromFile, toFile) end

UtilityGame = m
return m
