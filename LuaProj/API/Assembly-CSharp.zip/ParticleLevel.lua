---@class ParticleLevel : UnityEngine.MonoBehaviour
---@field public GpuLevel number @static
---@field public machineType ParticleLevel.MachineType
---@field public midLevelUnshow UnityEngine.GameObject[]
---@field public lowLevelUnshow UnityEngine.GameObject[]
local m = {}

---@param machineType number
function m:ControlLevel(machineType) end

ParticleLevel = m
return m
