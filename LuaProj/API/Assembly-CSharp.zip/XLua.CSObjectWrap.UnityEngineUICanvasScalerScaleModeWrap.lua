---@class XLua.CSObjectWrap.UnityEngineUICanvasScalerScaleModeWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.UnityEngineUICanvasScalerScaleModeWrap = m
return m
