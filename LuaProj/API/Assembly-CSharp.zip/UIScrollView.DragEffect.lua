---@class UIScrollView.DragEffect : System.Enum
---@field public None UIScrollView.DragEffect @static
---@field public Momentum UIScrollView.DragEffect @static
---@field public MomentumAndSpring UIScrollView.DragEffect @static
---@field public value__ number
local m = {}

UIScrollView.DragEffect = m
return m
