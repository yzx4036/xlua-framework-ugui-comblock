---@class VoFightNpcGeneral : VoFightObj
local m = {}

VoFightNpcGeneral = m
return m
