---@class AssetBundles.AssetBundleManager : MonoSingleton_1_AssetBundles_AssetBundleManager_
---@field public ManifestBundleName string @static
---@field public assetbundlesCaching System.Collections.Generic.Dictionary_2_System_String_UnityEngine_AssetBundle_
---@field public IsInitialized boolean
---@field public curManifest AssetBundles.Manifest
---@field public DownloadUrl string
---@field public IsProsessRunning boolean
local m = {}

function m:TestHotfix() end

---@return System.Collections.IEnumerator
function m:Initialize() end

---@return System.Collections.IEnumerator
function m:Cleanup() end

---@param assetbundleName string
---@param resident boolean
function m:SetAssetBundleResident(assetbundleName, resident) end

---@param assebundleName string
---@return boolean
function m:IsAssetBundleResident(assebundleName) end

---@param assetbundleName string
---@return boolean
function m:IsAssetBundleLoaded(assetbundleName) end

---@param assetbundleName string
---@return UnityEngine.AssetBundle
function m:GetAssetBundleCache(assetbundleName) end

---@param assetName string
---@return boolean
function m:IsAssetLoaded(assetName) end

---@param assetName string
---@return UnityEngine.Object
function m:GetAssetCache(assetName) end

---@param assetName string
---@param asset UnityEngine.Object
function m:AddAssetCache(assetName, asset) end

---@overload fun(assetbundleName:string)
---@param assetbundleName string
---@param postfix string
function m:AddAssetbundleAssetsCache(assetbundleName, postfix) end

function m:ClearAssetsCache() end

---@param assetbundleName string
---@return AssetBundles.ResourceWebRequester
function m:GetAssetBundleAsyncCreater(assetbundleName) end

---@param assetbundleName string
---@return AssetBundles.BaseAssetBundleAsyncLoader
function m:LoadAssetBundleAsync(assetbundleName) end

---@param url string
---@return AssetBundles.ResourceWebRequester
function m:DownloadWebResourceAsync(url) end

---@overload fun(filePath:string):AssetBundles.ResourceWebRequester
---@param filePath string
---@param isLoadBundle boolean
---@return AssetBundles.ResourceWebRequester
function m:DownloadAssetFileAsync(filePath, isLoadBundle) end

---@param filePath string
---@return AssetBundles.ResourceWebRequester
function m:DownloadAssetBundleAsync(filePath) end

---@overload fun(filePath:string):AssetBundles.ResourceWebRequester
---@param filePath string
---@param streamingAssetsOnly boolean
---@return AssetBundles.ResourceWebRequester
function m:RequestAssetFileAsync(filePath, streamingAssetsOnly) end

---@param assetbundleName string
---@return AssetBundles.ResourceWebRequester
function m:RequestAssetBundleAsync(assetbundleName) end

---@overload fun(assetbundleName:string, unloadAllLoadedObjects:boolean):boolean
---@overload fun(assetbundleName:string):boolean
---@param assetbundleName string
---@param unloadAllLoadedObjects boolean
---@param unloadDependencies boolean
---@return boolean
function m:UnloadUnusedAssetBundle(assetbundleName, unloadAllLoadedObjects, unloadDependencies) end

---@overload fun(unloadAllLoadedObjects:boolean):number
---@overload fun():number
---@param unloadAllLoadedObjects boolean
---@param unloadDependencies boolean
---@return number
function m:UnloadAllUnusedResidentAssetBundles(unloadAllLoadedObjects, unloadDependencies) end

---@param assetPath string
---@return boolean, System.String, System.String
function m:MapAssetPath(assetPath) end

---@param assetPath string
---@param assetType System.Type
---@return AssetBundles.BaseAssetAsyncLoader
function m:LoadAssetAsync(assetPath, assetType) end

---@return System.Collections.Generic.HashSet_1_System_String_
function m:GetAssetbundleResident() end

---@return System.Collections.Generic.ICollection_1_System_String_
function m:GetAssetbundleCaching() end

---@return System.Collections.Generic.Dictionary_2_System_String_AssetBundles_ResourceWebRequester_
function m:GetWebRequesting() end

---@return System.Collections.Generic.Queue_1_AssetBundles_ResourceWebRequester_
function m:GetWebRequestQueue() end

---@return AssetBundles.ResourceWebRequester[]
function m:GetProsessingWebRequester() end

---@return AssetBundles.AssetBundleAsyncLoader[]
function m:GetProsessingAssetBundleAsyncLoader() end

---@return AssetBundles.AssetAsyncLoader[]
function m:GetProsessingAssetAsyncLoader() end

---@param assetName string
---@return string
function m:GetAssetBundleName(assetName) end

---@return number
function m:GetAssetCachingCount() end

---@return System.Collections.Generic.Dictionary_2_System_String_System_Collections_Generic_List_1_System_String__
function m:GetAssetCaching() end

---@param assetbundleName string
---@return number
function m:GetAssetbundleRefrenceCount(assetbundleName) end

---@param assetbundleName string
---@return number
function m:GetAssetbundleDependenciesCount(assetbundleName) end

---@param assetbundleName string
---@return string[]
function m:GetAssetBundleRefrences(assetbundleName) end

---@param assetbundleName string
---@return string[]
function m:GetWebRequesterRefrences(assetbundleName) end

---@param assetbundleName string
---@return string[]
function m:GetAssetBundleLoaderRefrences(assetbundleName) end

AssetBundles.AssetBundleManager = m
return m
