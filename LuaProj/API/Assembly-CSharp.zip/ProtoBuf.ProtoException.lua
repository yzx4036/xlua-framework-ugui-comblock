---@class ProtoBuf.ProtoException : System.Exception
local m = {}

ProtoBuf.ProtoException = m
return m
