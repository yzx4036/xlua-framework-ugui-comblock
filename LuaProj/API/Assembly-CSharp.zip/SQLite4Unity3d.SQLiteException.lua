---@class SQLite4Unity3d.SQLiteException : System.Exception
---@field public Result SQLite4Unity3d.SQLite3.Result
local m = {}

---@static
---@param r SQLite4Unity3d.SQLite3.Result
---@param message string
---@return SQLite4Unity3d.SQLiteException
function m.New(r, message) end

SQLite4Unity3d.SQLiteException = m
return m
