---@class BrightnessSaturationAndContrast : UnityEngine.MonoBehaviour
---@field public briSatConShader UnityEngine.Shader
---@field public brightness number
---@field public saturation number
---@field public contrast number
---@field public material UnityEngine.Material
local m = {}

BrightnessSaturationAndContrast = m
return m
