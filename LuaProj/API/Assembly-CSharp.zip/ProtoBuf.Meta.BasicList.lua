---@class ProtoBuf.Meta.BasicList : System.Object
---@field public Item any
---@field public Count number
local m = {}

---@param array System.Array
---@param offset number
function m:CopyTo(array, offset) end

---@param value any
---@return number
function m:Add(value) end

function m:Trim() end

---@return ProtoBuf.Meta.BasicList.NodeEnumerator
function m:GetEnumerator() end

ProtoBuf.Meta.BasicList = m
return m
