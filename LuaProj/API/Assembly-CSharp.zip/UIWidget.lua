---@class UIWidget : UIRect
---@field public showHandlesWithMoveTool boolean @static
---@field public showHandles boolean @static
---@field public onChange fun()
---@field public onPostFill fun(widget:UIWidget, bufferOffset:number, verts:BetterList_1_UnityEngine_Vector3_, uvs:BetterList_1_UnityEngine_Vector2_, cols:BetterList_1_UnityEngine_Color32_)
---@field public mOnRender fun(mat:UnityEngine.Material)
---@field public autoResizeBoxCollider boolean
---@field public hideIfOffScreen boolean
---@field public keepAspectRatio UIWidget.AspectRatioSource
---@field public aspectRatio number
---@field public hitCheck fun(worldPos:UnityEngine.Vector3):boolean
---@field public panel UIPanel
---@field public geometry UIGeometry
---@field public fillGeometry boolean
---@field public drawCall UIDrawCall
---@field public m_IsGray boolean
---@field public onRender fun(mat:UnityEngine.Material)
---@field public drawRegion UnityEngine.Vector4
---@field public pivotOffset UnityEngine.Vector2
---@field public width number
---@field public height number
---@field public color UnityEngine.Color
---@field public alpha number
---@field public isVisible boolean
---@field public hasVertices boolean
---@field public rawPivot UIWidget.Pivot
---@field public pivot UIWidget.Pivot
---@field public depth number
---@field public raycastDepth number
---@field public localCorners UnityEngine.Vector3[]
---@field public localSize UnityEngine.Vector2
---@field public localCenter UnityEngine.Vector3
---@field public worldCorners UnityEngine.Vector3[]
---@field public worldCenter UnityEngine.Vector3
---@field public drawingDimensions UnityEngine.Vector4
---@field public material UnityEngine.Material
---@field public mainTexture UnityEngine.Texture
---@field public shader UnityEngine.Shader
---@field public relativeSize UnityEngine.Vector2
---@field public hasBoxCollider boolean
---@field public minWidth number
---@field public minHeight number
---@field public border UnityEngine.Vector4
local m = {}

---@param w number
---@param h number
function m:SetDimensions(w, h) end

---@virtual
---@param relativeTo UnityEngine.Transform
---@return UnityEngine.Vector3[]
function m:GetSides(relativeTo) end

---@virtual
---@param frameID number
---@return number
function m:CalculateFinalAlpha(frameID) end

---@virtual
---@param includeChildren boolean
function m:Invalidate(includeChildren) end

---@param frameID number
---@return number
function m:CalculateCumulativeAlpha(frameID) end

---@virtual
---@param x number
---@param y number
---@param width number
---@param height number
function m:SetRect(x, y, width, height) end

function m:ResizeCollider() end

---@static
---@param left UIWidget
---@param right UIWidget
---@return number
function m.FullCompareFunc(left, right) end

---@static
---@param left UIWidget
---@param right UIWidget
---@return number
function m.PanelCompareFunc(left, right) end

---@overload fun(relativeParent:UnityEngine.Transform):UnityEngine.Bounds
---@return UnityEngine.Bounds
function m:CalculateBounds() end

function m:SetDirty() end

function m:RemoveFromPanel() end

---@virtual
function m:MarkAsChanged() end

---@return UIPanel
function m:CreatePanel() end

function m:CheckLayer() end

---@virtual
function m:ParentHasChanged() end

---@param visibleByAlpha boolean
---@param visibleByPanel boolean
---@return boolean
function m:UpdateVisibility(visibleByAlpha, visibleByPanel) end

---@param frame number
---@return boolean
function m:UpdateTransform(frame) end

---@param frame number
---@return boolean
function m:UpdateGeometry(frame) end

---@overload fun(v:BetterList_1_UnityEngine_Vector3_, u:BetterList_1_UnityEngine_Vector2_, c:BetterList_1_UnityEngine_Color32_, n:BetterList_1_UnityEngine_Vector3_, t:BetterList_1_UnityEngine_Vector4_)
---@param v BetterList_1_UnityEngine_Vector3_
---@param u BetterList_1_UnityEngine_Vector2_
---@param c BetterList_1_UnityEngine_Color32_
---@param n BetterList_1_UnityEngine_Vector3_
---@param t BetterList_1_UnityEngine_Vector4_
---@param u1 BetterList_1_UnityEngine_Vector2_
function m:WriteToBuffers(v, u, c, n, t, u1) end

---@param vIsGray boolean
function m:SetIsGray(vIsGray) end

---@virtual
function m:MakePixelPerfect() end

---@virtual
---@param verts BetterList_1_UnityEngine_Vector3_
---@param uvs BetterList_1_UnityEngine_Vector2_
---@param cols BetterList_1_UnityEngine_Color32_
function m:OnFill(verts, uvs, cols) end

UIWidget = m
return m
