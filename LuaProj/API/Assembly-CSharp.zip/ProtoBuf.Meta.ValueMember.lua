---@class ProtoBuf.Meta.ValueMember : System.Object
---@field public FieldNumber number
---@field public Member System.Reflection.MemberInfo
---@field public ItemType System.Type
---@field public MemberType System.Type
---@field public DefaultType System.Type
---@field public ParentType System.Type
---@field public DefaultValue any
---@field public DataFormat ProtoBuf.DataFormat
---@field public IsStrict boolean
---@field public IsPacked boolean
---@field public OverwriteList boolean
---@field public IsRequired boolean
---@field public AsReference boolean
---@field public DynamicType boolean
---@field public Name string
---@field public SupportNull boolean
local m = {}

---@param getSpecified System.Reflection.MethodInfo
---@param setSpecified System.Reflection.MethodInfo
function m:SetSpecified(getSpecified, setSpecified) end

ProtoBuf.Meta.ValueMember = m
return m
