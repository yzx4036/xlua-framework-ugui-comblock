---@class ShakeUtil : PureSingleton_1_ShakeUtil_
---@field public isShaking boolean
---@field public shakeDistance number
local m = {}

---@param id number
---@param loopCount number
function m:doShake(id, loopCount) end

---@param isFromZheng boolean
function m:TweenCameraBegin(isFromZheng) end

function m:TweenCameraKill() end

function m:InitAutoCamera() end

function m:ClearAutoCamera() end

ShakeUtil = m
return m
