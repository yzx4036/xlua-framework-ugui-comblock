---@class SkEffPwxFloor : SkEffBase
local m = {}

SkEffPwxFloor = m
return m
