---@class MapEditor.CityLineInfo : System.Object
---@field public cityLine string
---@field public titlingScale number
---@field public lineNode MapEditor.GridInfo[]
---@field public a number
---@field public b number
local m = {}

MapEditor.CityLineInfo = m
return m
