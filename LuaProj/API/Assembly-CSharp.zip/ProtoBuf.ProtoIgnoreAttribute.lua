---@class ProtoBuf.ProtoIgnoreAttribute : System.Attribute
local m = {}

ProtoBuf.ProtoIgnoreAttribute = m
return m
