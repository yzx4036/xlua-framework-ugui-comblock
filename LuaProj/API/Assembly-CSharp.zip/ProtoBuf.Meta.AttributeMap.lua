---@class ProtoBuf.Meta.AttributeMap : System.Object
---@field public AttributeType System.Type
---@field public Target any
local m = {}

---@return System.Type
function m:GetType() end

---@overload fun(key:string):boolean, System.Object
---@abstract
---@param key string
---@param publicOnly boolean
---@return boolean, System.Object
function m:TryGet(key, publicOnly) end

---@overload fun(model:ProtoBuf.Meta.TypeModel, member:System.Reflection.MemberInfo, inherit:boolean):ProtoBuf.Meta.AttributeMap[] @static
---@overload fun(model:ProtoBuf.Meta.TypeModel, assembly:System.Reflection.Assembly):ProtoBuf.Meta.AttributeMap[] @static
---@static
---@param model ProtoBuf.Meta.TypeModel
---@param type System.Type
---@param inherit boolean
---@return ProtoBuf.Meta.AttributeMap[]
function m.Create(model, type, inherit) end

ProtoBuf.Meta.AttributeMap = m
return m
