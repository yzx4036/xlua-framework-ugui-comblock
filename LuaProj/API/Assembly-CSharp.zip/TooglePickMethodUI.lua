---@class TooglePickMethodUI : UnityEngine.MonoBehaviour
local m = {}

---@param value boolean
function m:SetPickMethod2Finger(value) end

---@param value boolean
function m:SetPickMethod2Averager(value) end

TooglePickMethodUI = m
return m
