---@class battle.NtfBattleFrameDataDecorator : System.Object
local m = {}

---@virtual
---@param target any
---@param value any
---@param fieldNumber number
function m:SetValue(target, value, fieldNumber) end

---@virtual
---@param target any
---@param fieldNumber number
---@return any
function m:GetValue(target, fieldNumber) end

battle.NtfBattleFrameDataDecorator = m
return m
