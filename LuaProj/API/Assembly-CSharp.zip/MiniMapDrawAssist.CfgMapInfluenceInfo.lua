---@class MiniMapDrawAssist.CfgMapInfluenceInfo : System.Object
---@field public influenceId number
---@field public gridX number
---@field public gridY number
---@field public worldX number
---@field public worldY number
local m = {}

function m:InitBoundary() end

---@param dir MiniMapDrawAssist.EDirection
---@param value boolean
function m:SetBoundary(dir, value) end

---@param dir MiniMapDrawAssist.EDirection
---@return boolean
function m:GetBoundary(dir) end

---@return string
function m:GetKey() end

MiniMapDrawAssist.CfgMapInfluenceInfo = m
return m
