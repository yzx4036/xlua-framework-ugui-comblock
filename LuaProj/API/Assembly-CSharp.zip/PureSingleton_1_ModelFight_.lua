---@class PureSingleton_1_ModelFight_ : System.Object
---@field public Instance ModelFight @static
local m = {}

PureSingleton_1_ModelFight_ = m
return m
