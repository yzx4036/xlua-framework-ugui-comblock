---@class GDTimer.TimerState : System.Object
---@field public id number
---@field public data any
---@field public trigger fun(args:any[]):any
---@field public repeat number
---@field public timems number
---@field public nexttime number
---@field public infiniteLoop boolean
---@field public deleteFlag boolean
local m = {}

function m:OnTimer() end

GDTimer.TimerState = m
return m
