---@class MapEditor.MistyInfo : System.Object
---@field public name string
---@field public x number
---@field public y number
---@field public r number
local m = {}

MapEditor.MistyInfo = m
return m
