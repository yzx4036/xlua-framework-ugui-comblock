---@class DownloadTexture : UnityEngine.MonoBehaviour
---@field public url string
---@field public pixelPerfect boolean
local m = {}

DownloadTexture = m
return m
