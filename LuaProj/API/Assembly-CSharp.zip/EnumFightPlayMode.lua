---@class EnumFightPlayMode : System.Enum
---@field public PVE EnumFightPlayMode @static
---@field public PVP EnumFightPlayMode @static
---@field public value__ number
local m = {}

EnumFightPlayMode = m
return m
