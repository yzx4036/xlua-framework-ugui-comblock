---@class UIItemStorage : UnityEngine.MonoBehaviour
---@field public maxItemCount number
---@field public maxRows number
---@field public maxColumns number
---@field public template UnityEngine.GameObject
---@field public background UIWidget
---@field public spacing number
---@field public padding number
---@field public items InvGameItem[]
local m = {}

---@param slot number
---@return InvGameItem
function m:GetItem(slot) end

---@param slot number
---@param item InvGameItem
---@return InvGameItem
function m:Replace(slot, item) end

UIItemStorage = m
return m
