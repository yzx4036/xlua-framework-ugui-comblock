---@class UIScrollView : UnityEngine.MonoBehaviour
---@field public list BetterList_1_UIScrollView_ @static
---@field public movement UIScrollView.Movement
---@field public dragEffect UIScrollView.DragEffect
---@field public restrictWithinPanel boolean
---@field public disableDragIfFits boolean
---@field public smoothDragStart boolean
---@field public iOSDragEmulation boolean
---@field public scrollWheelFactor number
---@field public momentumAmount number
---@field public dampenStrength number
---@field public horizontalScrollBar UIProgressBar
---@field public verticalScrollBar UIProgressBar
---@field public showScrollBars UIScrollView.ShowCondition
---@field public customMovement UnityEngine.Vector2
---@field public contentPivot UIWidget.Pivot
---@field public onDragStarted fun()
---@field public onDragFinished fun()
---@field public onMomentumMove fun()
---@field public onStoppedMoving fun()
---@field public OnMoveLimitHandle fun(offset:UnityEngine.Vector2, relative:UnityEngine.Vector3, result:UnityEngine.Vector3[])
---@field public centerOnChild UICenterOnChild
---@field public panel UIPanel
---@field public isDragging boolean
---@field public bounds UnityEngine.Bounds
---@field public canMoveHorizontally boolean
---@field public canMoveVertically boolean
---@field public shouldMoveHorizontally boolean
---@field public shouldMoveVertically boolean
---@field public currentMomentum UnityEngine.Vector3
local m = {}

---@overload fun(instant:boolean, horizontal:boolean, vertical:boolean):boolean
---@param instant boolean
---@return boolean
function m:RestrictWithinBounds(instant) end

function m:DisableSpring() end

---@overload fun(recalculateBounds:boolean) @virtual
function m:UpdateScrollbars() end

---@virtual
---@param x number
---@param y number
---@param updateScrollbars boolean
function m:SetDragAmount(x, y, updateScrollbars) end

function m:InvalidateBounds() end

function m:ResetPosition() end

function m:UpdatePosition() end

function m:OnScrollBar() end

---@virtual
---@param relative UnityEngine.Vector3
function m:MoveRelative(relative) end

---@param absolute UnityEngine.Vector3
function m:MoveAbsolute(absolute) end

---@param pressed boolean
function m:Press(pressed) end

function m:Drag() end

---@param delta number
function m:Scroll(delta) end

---@param delta UnityEngine.Vector2
function m:OnPan(delta) end

UIScrollView = m
return m
