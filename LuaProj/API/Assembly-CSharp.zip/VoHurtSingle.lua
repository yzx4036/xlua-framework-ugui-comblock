---@class VoHurtSingle : System.Object
---@field public bu BattleUnit
---@field public hurtData VoTargetData
---@field public way number
---@field public isDealHurtEff boolean
local m = {}

VoHurtSingle = m
return m
