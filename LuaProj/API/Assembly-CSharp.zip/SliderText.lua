---@class SliderText : UnityEngine.MonoBehaviour
local m = {}

---@param value number
function m:SetText(value) end

SliderText = m
return m
