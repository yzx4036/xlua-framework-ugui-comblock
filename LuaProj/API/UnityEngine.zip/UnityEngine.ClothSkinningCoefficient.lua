---@class UnityEngine.ClothSkinningCoefficient : System.ValueType
---@field public maxDistance number
---@field public collisionSphereDistance number
local m = {}

UnityEngine.ClothSkinningCoefficient = m
return m
