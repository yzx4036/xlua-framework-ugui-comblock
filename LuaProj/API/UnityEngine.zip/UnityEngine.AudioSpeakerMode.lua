---@class UnityEngine.AudioSpeakerMode : System.Enum
---@field public Raw UnityEngine.AudioSpeakerMode @static
---@field public Mono UnityEngine.AudioSpeakerMode @static
---@field public Stereo UnityEngine.AudioSpeakerMode @static
---@field public Quad UnityEngine.AudioSpeakerMode @static
---@field public Surround UnityEngine.AudioSpeakerMode @static
---@field public Mode5point1 UnityEngine.AudioSpeakerMode @static
---@field public Mode7point1 UnityEngine.AudioSpeakerMode @static
---@field public Prologic UnityEngine.AudioSpeakerMode @static
---@field public value__ number
local m = {}

UnityEngine.AudioSpeakerMode = m
return m
