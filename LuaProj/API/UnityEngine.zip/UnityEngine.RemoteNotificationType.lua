---@class UnityEngine.RemoteNotificationType : System.Enum
---@field public value__ number
local m = {}

UnityEngine.RemoteNotificationType = m
return m
