---@class UnityEngine.XR.WSA.Input.InteractionSourceLocation : System.Object
local m = {}

UnityEngine.XR.WSA.Input.InteractionSourceLocation = m
return m
