---@class UnityEngine.AI.ObstacleAvoidanceType : System.Enum
---@field public NoObstacleAvoidance UnityEngine.AI.ObstacleAvoidanceType @static
---@field public LowQualityObstacleAvoidance UnityEngine.AI.ObstacleAvoidanceType @static
---@field public MedQualityObstacleAvoidance UnityEngine.AI.ObstacleAvoidanceType @static
---@field public GoodQualityObstacleAvoidance UnityEngine.AI.ObstacleAvoidanceType @static
---@field public HighQualityObstacleAvoidance UnityEngine.AI.ObstacleAvoidanceType @static
---@field public value__ number
local m = {}

UnityEngine.AI.ObstacleAvoidanceType = m
return m
