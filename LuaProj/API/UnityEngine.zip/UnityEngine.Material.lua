---@class UnityEngine.Material : UnityEngine.Object
---@field public shader UnityEngine.Shader
---@field public color UnityEngine.Color
---@field public mainTexture UnityEngine.Texture
---@field public mainTextureOffset UnityEngine.Vector2
---@field public mainTextureScale UnityEngine.Vector2
---@field public passCount number
---@field public renderQueue number
---@field public shaderKeywords string[]
---@field public globalIlluminationFlags UnityEngine.MaterialGlobalIlluminationFlags
local m = {}

---@overload fun(nameID:number, color:UnityEngine.Color)
---@param propertyName string
---@param color UnityEngine.Color
function m:SetColor(propertyName, color) end

---@overload fun(nameID:number):UnityEngine.Color
---@param propertyName string
---@return UnityEngine.Color
function m:GetColor(propertyName) end

---@overload fun(nameID:number, vector:UnityEngine.Vector4)
---@param propertyName string
---@param vector UnityEngine.Vector4
function m:SetVector(propertyName, vector) end

---@overload fun(nameID:number):UnityEngine.Vector4
---@param propertyName string
---@return UnityEngine.Vector4
function m:GetVector(propertyName) end

---@overload fun(nameID:number, texture:UnityEngine.Texture)
---@param propertyName string
---@param texture UnityEngine.Texture
function m:SetTexture(propertyName, texture) end

---@overload fun(nameID:number):UnityEngine.Texture
---@param propertyName string
---@return UnityEngine.Texture
function m:GetTexture(propertyName) end

---@param propertyName string
---@param offset UnityEngine.Vector2
function m:SetTextureOffset(propertyName, offset) end

---@param propertyName string
---@return UnityEngine.Vector2
function m:GetTextureOffset(propertyName) end

---@param propertyName string
---@param scale UnityEngine.Vector2
function m:SetTextureScale(propertyName, scale) end

---@param propertyName string
---@return UnityEngine.Vector2
function m:GetTextureScale(propertyName) end

---@overload fun(nameID:number, matrix:UnityEngine.Matrix4x4)
---@param propertyName string
---@param matrix UnityEngine.Matrix4x4
function m:SetMatrix(propertyName, matrix) end

---@overload fun(nameID:number):UnityEngine.Matrix4x4
---@param propertyName string
---@return UnityEngine.Matrix4x4
function m:GetMatrix(propertyName) end

---@overload fun(nameID:number, value:number)
---@param propertyName string
---@param value number
function m:SetFloat(propertyName, value) end

---@overload fun(nameID:number):number
---@param propertyName string
---@return number
function m:GetFloat(propertyName) end

---@overload fun(nameID:number, values:number[])
---@overload fun(name:string, values:number[])
---@overload fun(nameID:number, values:number[])
---@param name string
---@param values number[]
function m:SetFloatArray(name, values) end

---@overload fun(nameID:number, values:UnityEngine.Vector4[])
---@overload fun(name:string, values:UnityEngine.Vector4[])
---@overload fun(nameID:number, values:UnityEngine.Vector4[])
---@param name string
---@param values UnityEngine.Vector4[]
function m:SetVectorArray(name, values) end

---@overload fun(nameID:number, values:UnityEngine.Color[])
---@overload fun(name:string, values:UnityEngine.Color[])
---@overload fun(nameID:number, values:UnityEngine.Color[])
---@param name string
---@param values UnityEngine.Color[]
function m:SetColorArray(name, values) end

---@overload fun(nameID:number, values:UnityEngine.Matrix4x4[])
---@overload fun(name:string, values:UnityEngine.Matrix4x4[])
---@overload fun(nameID:number, values:UnityEngine.Matrix4x4[])
---@param name string
---@param values UnityEngine.Matrix4x4[]
function m:SetMatrixArray(name, values) end

---@overload fun(nameID:number, values:number[])
---@overload fun(name:string):number[]
---@overload fun(nameID:number):number[]
---@param name string
---@param values number[]
function m:GetFloatArray(name, values) end

---@overload fun(nameID:number, values:UnityEngine.Vector4[])
---@overload fun(name:string):UnityEngine.Vector4[]
---@overload fun(nameID:number):UnityEngine.Vector4[]
---@param name string
---@param values UnityEngine.Vector4[]
function m:GetVectorArray(name, values) end

---@overload fun(nameID:number, values:UnityEngine.Color[])
---@overload fun(name:string):UnityEngine.Color[]
---@overload fun(nameID:number):UnityEngine.Color[]
---@param name string
---@param values UnityEngine.Color[]
function m:GetColorArray(name, values) end

---@overload fun(nameID:number, values:UnityEngine.Matrix4x4[])
---@overload fun(name:string):UnityEngine.Matrix4x4[]
---@overload fun(nameID:number):UnityEngine.Matrix4x4[]
---@param name string
---@param values UnityEngine.Matrix4x4[]
function m:GetMatrixArray(name, values) end

---@overload fun(nameID:number, value:number)
---@param propertyName string
---@param value number
function m:SetInt(propertyName, value) end

---@overload fun(nameID:number):number
---@param propertyName string
---@return number
function m:GetInt(propertyName) end

---@overload fun(nameID:number, value:UnityEngine.ComputeBuffer)
---@param name string
---@param value UnityEngine.ComputeBuffer
function m:SetBuffer(name, value) end

---@overload fun(nameID:number):boolean
---@param propertyName string
---@return boolean
function m:HasProperty(propertyName) end

---@overload fun(tag:string, searchFallbacks:boolean):string
---@param tag string
---@param searchFallbacks boolean
---@param defaultValue string
---@return string
function m:GetTag(tag, searchFallbacks, defaultValue) end

---@param tag string
---@param val string
function m:SetOverrideTag(tag, val) end

---@param start UnityEngine.Material
---@param end UnityEngine.Material
---@param t number
function m:Lerp(start, end, t) end

---@param pass number
---@return boolean
function m:SetPass(pass) end

---@param pass number
---@return string
function m:GetPassName(pass) end

---@param passName string
---@return number
function m:FindPass(passName) end

---@static
---@param scriptContents string
---@return UnityEngine.Material
function m.Create(scriptContents) end

---@param mat UnityEngine.Material
function m:CopyPropertiesFromMaterial(mat) end

---@param keyword string
function m:EnableKeyword(keyword) end

---@param keyword string
function m:DisableKeyword(keyword) end

---@param keyword string
---@return boolean
function m:IsKeywordEnabled(keyword) end

UnityEngine.Material = m
return m
