---@class UnityEngine.BoxCollider : UnityEngine.Collider
---@field public center UnityEngine.Vector3
---@field public size UnityEngine.Vector3
---@field public extents UnityEngine.Vector3
local m = {}

UnityEngine.BoxCollider = m
return m
