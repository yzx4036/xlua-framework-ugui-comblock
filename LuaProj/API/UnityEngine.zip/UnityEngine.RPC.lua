---@class UnityEngine.RPC : System.Object
local m = {}

UnityEngine.RPC = m
return m
