---@class UnityEngine.iOS.ActivityIndicatorStyle : System.Enum
---@field public DontShow UnityEngine.iOS.ActivityIndicatorStyle @static
---@field public WhiteLarge UnityEngine.iOS.ActivityIndicatorStyle @static
---@field public White UnityEngine.iOS.ActivityIndicatorStyle @static
---@field public Gray UnityEngine.iOS.ActivityIndicatorStyle @static
---@field public value__ number
local m = {}

UnityEngine.iOS.ActivityIndicatorStyle = m
return m
