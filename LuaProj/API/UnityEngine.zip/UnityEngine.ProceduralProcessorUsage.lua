---@class UnityEngine.ProceduralProcessorUsage : System.Enum
---@field public value__ number
local m = {}

UnityEngine.ProceduralProcessorUsage = m
return m
