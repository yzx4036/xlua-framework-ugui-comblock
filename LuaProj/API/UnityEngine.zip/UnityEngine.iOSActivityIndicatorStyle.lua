---@class UnityEngine.iOSActivityIndicatorStyle : System.Enum
---@field public value__ number
local m = {}

UnityEngine.iOSActivityIndicatorStyle = m
return m
