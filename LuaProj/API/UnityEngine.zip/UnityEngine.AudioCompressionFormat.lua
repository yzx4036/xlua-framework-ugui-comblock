---@class UnityEngine.AudioCompressionFormat : System.Enum
---@field public PCM UnityEngine.AudioCompressionFormat @static
---@field public Vorbis UnityEngine.AudioCompressionFormat @static
---@field public ADPCM UnityEngine.AudioCompressionFormat @static
---@field public MP3 UnityEngine.AudioCompressionFormat @static
---@field public VAG UnityEngine.AudioCompressionFormat @static
---@field public HEVAG UnityEngine.AudioCompressionFormat @static
---@field public XMA UnityEngine.AudioCompressionFormat @static
---@field public AAC UnityEngine.AudioCompressionFormat @static
---@field public GCADPCM UnityEngine.AudioCompressionFormat @static
---@field public ATRAC9 UnityEngine.AudioCompressionFormat @static
---@field public value__ number
local m = {}

UnityEngine.AudioCompressionFormat = m
return m
