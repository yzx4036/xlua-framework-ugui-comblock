---@class UnityEngine.VR.VRDevice : System.Object
local m = {}

UnityEngine.VR.VRDevice = m
return m
