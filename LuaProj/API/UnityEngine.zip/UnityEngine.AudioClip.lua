---@class UnityEngine.AudioClip : UnityEngine.Object
---@field public length number
---@field public samples number
---@field public channels number
---@field public frequency number
---@field public isReadyToPlay boolean
---@field public loadType UnityEngine.AudioClipLoadType
---@field public preloadAudioData boolean
---@field public loadState UnityEngine.AudioDataLoadState
---@field public loadInBackground boolean
local m = {}

---@return boolean
function m:LoadAudioData() end

---@return boolean
function m:UnloadAudioData() end

---@param data number[]
---@param offsetSamples number
---@return boolean
function m:GetData(data, offsetSamples) end

---@param data number[]
---@param offsetSamples number
---@return boolean
function m:SetData(data, offsetSamples) end

---@overload fun(name:string, lengthSamples:number, channels:number, frequency:number, _3D:boolean, stream:boolean, pcmreadercallback:(fun(data:number[]))):UnityEngine.AudioClip @static
---@overload fun(name:string, lengthSamples:number, channels:number, frequency:number, _3D:boolean, stream:boolean, pcmreadercallback:(fun(data:number[])), pcmsetpositioncallback:(fun(position:number))):UnityEngine.AudioClip @static
---@overload fun(name:string, lengthSamples:number, channels:number, frequency:number, stream:boolean):UnityEngine.AudioClip @static
---@overload fun(name:string, lengthSamples:number, channels:number, frequency:number, stream:boolean, pcmreadercallback:(fun(data:number[]))):UnityEngine.AudioClip @static
---@overload fun(name:string, lengthSamples:number, channels:number, frequency:number, stream:boolean, pcmreadercallback:(fun(data:number[])), pcmsetpositioncallback:(fun(position:number))):UnityEngine.AudioClip @static
---@static
---@param name string
---@param lengthSamples number
---@param channels number
---@param frequency number
---@param _3D boolean
---@param stream boolean
---@return UnityEngine.AudioClip
function m.Create(name, lengthSamples, channels, frequency, _3D, stream) end

UnityEngine.AudioClip = m
return m
