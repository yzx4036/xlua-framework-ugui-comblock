---@class UnityEngine.VR.VRNodeState : System.Object
local m = {}

UnityEngine.VR.VRNodeState = m
return m
