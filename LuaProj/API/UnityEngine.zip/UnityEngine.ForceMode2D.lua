---@class UnityEngine.ForceMode2D : System.Enum
---@field public Force UnityEngine.ForceMode2D @static
---@field public Impulse UnityEngine.ForceMode2D @static
---@field public value__ number
local m = {}

UnityEngine.ForceMode2D = m
return m
