---@class UnityEngine.iPhoneMovieScalingMode : System.Enum
---@field public value__ number
local m = {}

UnityEngine.iPhoneMovieScalingMode = m
return m
