---@class UnityEngine.MasterServer : System.Object
local m = {}

UnityEngine.MasterServer = m
return m
