---@class UnityEngine.ProceduralCacheSize : System.Enum
---@field public value__ number
local m = {}

UnityEngine.ProceduralCacheSize = m
return m
