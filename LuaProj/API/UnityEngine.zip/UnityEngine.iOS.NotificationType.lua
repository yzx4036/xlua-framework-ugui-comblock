---@class UnityEngine.iOS.NotificationType : System.Enum
---@field public None UnityEngine.iOS.NotificationType @static
---@field public Badge UnityEngine.iOS.NotificationType @static
---@field public Sound UnityEngine.iOS.NotificationType @static
---@field public Alert UnityEngine.iOS.NotificationType @static
---@field public value__ number
local m = {}

UnityEngine.iOS.NotificationType = m
return m
