---@class UnityEngine.AudioRolloffMode : System.Enum
---@field public Logarithmic UnityEngine.AudioRolloffMode @static
---@field public Linear UnityEngine.AudioRolloffMode @static
---@field public Custom UnityEngine.AudioRolloffMode @static
---@field public value__ number
local m = {}

UnityEngine.AudioRolloffMode = m
return m
