---@class UnityEngine.AudioClip.PCMSetPositionCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param position number
function m:Invoke(position) end

---@virtual
---@param position number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(position, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UnityEngine.AudioClip.PCMSetPositionCallback = m
return m
