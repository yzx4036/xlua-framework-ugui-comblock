---@class UnityEngine.AndroidActivityIndicatorStyle : System.Enum
---@field public DontShow UnityEngine.AndroidActivityIndicatorStyle @static
---@field public Large UnityEngine.AndroidActivityIndicatorStyle @static
---@field public InversedLarge UnityEngine.AndroidActivityIndicatorStyle @static
---@field public Small UnityEngine.AndroidActivityIndicatorStyle @static
---@field public InversedSmall UnityEngine.AndroidActivityIndicatorStyle @static
---@field public value__ number
local m = {}

UnityEngine.AndroidActivityIndicatorStyle = m
return m
