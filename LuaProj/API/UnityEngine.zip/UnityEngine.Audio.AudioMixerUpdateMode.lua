---@class UnityEngine.Audio.AudioMixerUpdateMode : System.Enum
---@field public Normal UnityEngine.Audio.AudioMixerUpdateMode @static
---@field public UnscaledTime UnityEngine.Audio.AudioMixerUpdateMode @static
---@field public value__ number
local m = {}

UnityEngine.Audio.AudioMixerUpdateMode = m
return m
