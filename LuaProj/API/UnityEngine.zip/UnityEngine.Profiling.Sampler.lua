---@class UnityEngine.Profiling.Sampler : System.Object
---@field public name string
---@field public enabled boolean
local m = {}

UnityEngine.Profiling.Sampler = m
return m
