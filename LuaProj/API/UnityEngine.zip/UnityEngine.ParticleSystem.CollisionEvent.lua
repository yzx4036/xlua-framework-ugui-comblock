---@class UnityEngine.ParticleSystem.CollisionEvent : System.ValueType
---@field public intersection UnityEngine.Vector3
---@field public normal UnityEngine.Vector3
---@field public velocity UnityEngine.Vector3
---@field public collider UnityEngine.Collider
local m = {}

UnityEngine.ParticleSystem.CollisionEvent = m
return m
