---@class UnityEngine.Experimental.Director.Playables : System.Object
local m = {}

UnityEngine.Experimental.Director.Playables = m
return m
