---@class UnityEngine.AI.NavMeshObstacle : UnityEngine.Behaviour
---@field public height number
---@field public radius number
---@field public velocity UnityEngine.Vector3
---@field public carving boolean
---@field public carveOnlyStationary boolean
---@field public carvingMoveThreshold number
---@field public carvingTimeToStationary number
---@field public shape UnityEngine.AI.NavMeshObstacleShape
---@field public center UnityEngine.Vector3
---@field public size UnityEngine.Vector3
local m = {}

UnityEngine.AI.NavMeshObstacle = m
return m
