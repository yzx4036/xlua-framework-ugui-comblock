---@class UnityEngine.Security : System.Object
local m = {}

---@overload fun(ip:string, atPort:number, timeout:number):boolean @static
---@static
---@param ip string
---@param atPort number
---@return boolean
function m.PrefetchSocketPolicy(ip, atPort) end

---@overload fun(assemblyData:string):System.Reflection.Assembly @static
---@static
---@param assemblyData string
---@param authorizationKey string
---@return System.Reflection.Assembly
function m.LoadAndVerifyAssembly(assemblyData, authorizationKey) end

UnityEngine.Security = m
return m
