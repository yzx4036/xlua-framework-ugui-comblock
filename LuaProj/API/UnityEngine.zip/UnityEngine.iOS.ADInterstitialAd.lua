---@class UnityEngine.iOS.ADInterstitialAd : System.Object
local m = {}

UnityEngine.iOS.ADInterstitialAd = m
return m
