---@class UnityEngine.iOS.CalendarUnit : System.Enum
---@field public Era UnityEngine.iOS.CalendarUnit @static
---@field public Year UnityEngine.iOS.CalendarUnit @static
---@field public Month UnityEngine.iOS.CalendarUnit @static
---@field public Day UnityEngine.iOS.CalendarUnit @static
---@field public Hour UnityEngine.iOS.CalendarUnit @static
---@field public Minute UnityEngine.iOS.CalendarUnit @static
---@field public Second UnityEngine.iOS.CalendarUnit @static
---@field public Week UnityEngine.iOS.CalendarUnit @static
---@field public Weekday UnityEngine.iOS.CalendarUnit @static
---@field public WeekdayOrdinal UnityEngine.iOS.CalendarUnit @static
---@field public Quarter UnityEngine.iOS.CalendarUnit @static
---@field public value__ number
local m = {}

UnityEngine.iOS.CalendarUnit = m
return m
