---@class UnityEngine.WebCamDevice : System.ValueType
---@field public name string
---@field public isFrontFacing boolean
local m = {}

UnityEngine.WebCamDevice = m
return m
