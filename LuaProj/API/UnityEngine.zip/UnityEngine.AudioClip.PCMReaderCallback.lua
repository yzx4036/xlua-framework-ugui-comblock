---@class UnityEngine.AudioClip.PCMReaderCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param data number[]
function m:Invoke(data) end

---@virtual
---@param data number[]
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(data, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UnityEngine.AudioClip.PCMReaderCallback = m
return m
