---@class UnityEngine.Apple.TV.Remote : System.Object
local m = {}

UnityEngine.Apple.TV.Remote = m
return m
