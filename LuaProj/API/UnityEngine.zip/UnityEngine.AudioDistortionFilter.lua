---@class UnityEngine.AudioDistortionFilter : UnityEngine.Behaviour
---@field public distortionLevel number
local m = {}

UnityEngine.AudioDistortionFilter = m
return m
