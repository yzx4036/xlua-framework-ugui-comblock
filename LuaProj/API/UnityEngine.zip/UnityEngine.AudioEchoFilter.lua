---@class UnityEngine.AudioEchoFilter : UnityEngine.Behaviour
---@field public delay number
---@field public decayRatio number
---@field public dryMix number
---@field public wetMix number
local m = {}

UnityEngine.AudioEchoFilter = m
return m
