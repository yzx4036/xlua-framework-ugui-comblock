---@class UnityEngine.WebCamFlags : System.Enum
---@field public FrontFacing UnityEngine.WebCamFlags @static
---@field public value__ number
local m = {}

UnityEngine.WebCamFlags = m
return m
