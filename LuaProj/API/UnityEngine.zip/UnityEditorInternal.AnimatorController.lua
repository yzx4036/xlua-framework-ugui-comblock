---@class UnityEditorInternal.AnimatorController : System.Object
local m = {}

UnityEditorInternal.AnimatorController = m
return m
