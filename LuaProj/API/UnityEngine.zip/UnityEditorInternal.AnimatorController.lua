---@class UnityEditorInternal.AnimatorController : UnityEngine.RuntimeAnimatorController
local m = {}

UnityEditorInternal.AnimatorController = m
return m
