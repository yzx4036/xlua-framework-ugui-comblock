---@class UnityEngine.CalendarIdentifier : System.Enum
---@field public value__ number
local m = {}

UnityEngine.CalendarIdentifier = m
return m
