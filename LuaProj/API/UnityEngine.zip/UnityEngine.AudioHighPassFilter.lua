---@class UnityEngine.AudioHighPassFilter : UnityEngine.Behaviour
---@field public cutoffFrequency number
---@field public highpassResonanceQ number
---@field public highpassResonaceQ number
local m = {}

UnityEngine.AudioHighPassFilter = m
return m
