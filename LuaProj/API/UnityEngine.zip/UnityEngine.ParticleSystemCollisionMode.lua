---@class UnityEngine.ParticleSystemCollisionMode : System.Enum
---@field public Collision3D UnityEngine.ParticleSystemCollisionMode @static
---@field public Collision2D UnityEngine.ParticleSystemCollisionMode @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemCollisionMode = m
return m
