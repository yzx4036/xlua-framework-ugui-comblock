---@class UnityEngine.Experimental.Director.Playable : System.ValueType
---@field public Null UnityEngine.Experimental.Director.Playable @static
---@field public inputCount number
---@field public outputCount number
---@field public state UnityEngine.Experimental.Director.PlayState
---@field public time number
---@field public duration number
local m = {}

function m:Destroy() end

---@return boolean
function m:IsValid() end

---@return System.ValueType
function m:CastTo() end

---@static
---@param playable UnityEngine.Experimental.Director.Playable
---@return System.Type
function m.GetTypeOf(playable) end

---@overload fun(source:UnityEngine.Experimental.Director.Playable, target:UnityEngine.Experimental.Director.Playable, sourceOutputPort:number, targetInputPort:number):boolean @static
---@static
---@param source UnityEngine.Experimental.Director.Playable
---@param target UnityEngine.Experimental.Director.Playable
---@return boolean
function m.Connect(source, target) end

---@static
---@param target UnityEngine.Experimental.Director.Playable
---@param inputPort number
function m.Disconnect(target, inputPort) end

---@static
---@return UnityEngine.Experimental.Director.CustomAnimationPlayable
function m.Create() end

---@return UnityEngine.Experimental.Director.Playable[]
function m:GetInputs() end

---@param inputPort number
---@return UnityEngine.Experimental.Director.Playable
function m:GetInput(inputPort) end

---@return UnityEngine.Experimental.Director.Playable[]
function m:GetOutputs() end

---@param outputPort number
---@return UnityEngine.Experimental.Director.Playable
function m:GetOutput(outputPort) end

---@overload fun(inputIndex:number, weight:number):boolean
---@param input UnityEngine.Experimental.Director.Playable
---@param weight number
function m:SetInputWeight(input, weight) end

---@param index number
---@return number
function m:GetInputWeight(index) end

---@static
---@param x UnityEngine.Experimental.Director.Playable
---@param y UnityEngine.Experimental.Director.Playable
---@return boolean
function m.op_Equality(x, y) end

---@static
---@param x UnityEngine.Experimental.Director.Playable
---@param y UnityEngine.Experimental.Director.Playable
---@return boolean
function m.op_Inequality(x, y) end

---@virtual
---@param p any
---@return boolean
function m:Equals(p) end

---@virtual
---@return number
function m:GetHashCode() end

UnityEngine.Experimental.Director.Playable = m
return m
