---@class UnityEngine.iPhoneScreenOrientation : System.Enum
---@field public value__ number
local m = {}

UnityEngine.iPhoneScreenOrientation = m
return m
