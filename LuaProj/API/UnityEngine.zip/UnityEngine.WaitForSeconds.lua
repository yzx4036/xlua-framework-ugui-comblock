---@class UnityEngine.WaitForSeconds : UnityEngine.YieldInstruction
local m = {}

UnityEngine.WaitForSeconds = m
return m
