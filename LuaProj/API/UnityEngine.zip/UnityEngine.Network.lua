---@class UnityEngine.Network : System.Object
local m = {}

UnityEngine.Network = m
return m
