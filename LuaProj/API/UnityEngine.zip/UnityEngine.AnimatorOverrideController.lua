---@class UnityEngine.AnimatorOverrideController : UnityEngine.RuntimeAnimatorController
---@field public runtimeAnimatorController UnityEngine.RuntimeAnimatorController
---@field public Item UnityEngine.AnimationClip
---@field public Item UnityEngine.AnimationClip
---@field public clips UnityEngine.AnimationClipPair[]
local m = {}

UnityEngine.AnimatorOverrideController = m
return m
