---@class UnityEngine.iPhoneOrientation : System.Enum
---@field public value__ number
local m = {}

UnityEngine.iPhoneOrientation = m
return m
