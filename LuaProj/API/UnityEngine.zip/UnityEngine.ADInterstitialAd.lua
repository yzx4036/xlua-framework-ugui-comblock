---@class UnityEngine.ADInterstitialAd : System.Object
local m = {}

UnityEngine.ADInterstitialAd = m
return m
