---@class UnityEngine.ParticleSystem.Burst : System.ValueType
---@field public time number
---@field public minCount number
---@field public maxCount number
local m = {}

UnityEngine.ParticleSystem.Burst = m
return m
