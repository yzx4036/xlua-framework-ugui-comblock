---@class UnityEngine.AI.NavMeshHit : System.ValueType
---@field public position UnityEngine.Vector3
---@field public normal UnityEngine.Vector3
---@field public distance number
---@field public mask number
---@field public hit boolean
local m = {}

UnityEngine.AI.NavMeshHit = m
return m
