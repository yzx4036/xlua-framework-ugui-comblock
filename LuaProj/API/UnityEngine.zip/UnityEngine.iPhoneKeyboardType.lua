---@class UnityEngine.iPhoneKeyboardType : System.Enum
---@field public value__ number
local m = {}

UnityEngine.iPhoneKeyboardType = m
return m
