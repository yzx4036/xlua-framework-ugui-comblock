---@class UnityEngine.SoftJointLimit : System.ValueType
---@field public limit number
---@field public spring number
---@field public damper number
---@field public bounciness number
---@field public contactDistance number
---@field public bouncyness number
local m = {}

UnityEngine.SoftJointLimit = m
return m
