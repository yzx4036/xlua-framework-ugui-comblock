---@class UnityEngine.MeshFilter : UnityEngine.Component
---@field public mesh UnityEngine.Mesh
---@field public sharedMesh UnityEngine.Mesh
local m = {}

UnityEngine.MeshFilter = m
return m
