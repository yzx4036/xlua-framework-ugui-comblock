---@class UnityEngine.RigidbodySleepMode2D : System.Enum
---@field public NeverSleep UnityEngine.RigidbodySleepMode2D @static
---@field public StartAwake UnityEngine.RigidbodySleepMode2D @static
---@field public StartAsleep UnityEngine.RigidbodySleepMode2D @static
---@field public value__ number
local m = {}

UnityEngine.RigidbodySleepMode2D = m
return m
