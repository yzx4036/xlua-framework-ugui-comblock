---@class UnityEngine.iPhoneGeneration : System.Enum
---@field public value__ number
local m = {}

UnityEngine.iPhoneGeneration = m
return m
