---@class UnityEngine.LineRenderer : UnityEngine.Renderer
---@field public startWidth number
---@field public endWidth number
---@field public widthCurve UnityEngine.AnimationCurve
---@field public widthMultiplier number
---@field public startColor UnityEngine.Color
---@field public endColor UnityEngine.Color
---@field public colorGradient UnityEngine.Gradient
---@field public numPositions number
---@field public useWorldSpace boolean
---@field public numCornerVertices number
---@field public numCapVertices number
---@field public textureMode UnityEngine.LineTextureMode
local m = {}

---@param start number
---@param end number
function m:SetWidth(start, end) end

---@param start UnityEngine.Color
---@param end UnityEngine.Color
function m:SetColors(start, end) end

---@param count number
function m:SetVertexCount(count) end

---@param index number
---@param position UnityEngine.Vector3
function m:SetPosition(index, position) end

---@param index number
---@return UnityEngine.Vector3
function m:GetPosition(index) end

---@param positions UnityEngine.Vector3[]
function m:SetPositions(positions) end

---@param positions UnityEngine.Vector3[]
---@return number
function m:GetPositions(positions) end

UnityEngine.LineRenderer = m
return m
