---@class UnityEngine.AudioClipLoadType : System.Enum
---@field public DecompressOnLoad UnityEngine.AudioClipLoadType @static
---@field public CompressedInMemory UnityEngine.AudioClipLoadType @static
---@field public Streaming UnityEngine.AudioClipLoadType @static
---@field public value__ number
local m = {}

UnityEngine.AudioClipLoadType = m
return m
