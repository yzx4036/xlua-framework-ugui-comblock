---@class UnityEngine.PointEffector2D : UnityEngine.Effector2D
---@field public forceMagnitude number
---@field public forceVariation number
---@field public distanceScale number
---@field public drag number
---@field public angularDrag number
---@field public forceSource UnityEngine.EffectorSelection2D
---@field public forceTarget UnityEngine.EffectorSelection2D
---@field public forceMode UnityEngine.EffectorForceMode2D
local m = {}

UnityEngine.PointEffector2D = m
return m
