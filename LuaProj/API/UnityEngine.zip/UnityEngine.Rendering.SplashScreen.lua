---@class UnityEngine.Rendering.SplashScreen : System.Object
---@field public isFinished boolean @static
local m = {}

---@static
function m.Begin() end

---@static
function m.Draw() end

UnityEngine.Rendering.SplashScreen = m
return m
