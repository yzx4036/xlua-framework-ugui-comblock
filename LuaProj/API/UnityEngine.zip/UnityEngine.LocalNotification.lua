---@class UnityEngine.LocalNotification : System.Object
local m = {}

UnityEngine.LocalNotification = m
return m
