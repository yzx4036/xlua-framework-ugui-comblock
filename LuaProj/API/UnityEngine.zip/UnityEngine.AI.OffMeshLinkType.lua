---@class UnityEngine.AI.OffMeshLinkType : System.Enum
---@field public LinkTypeManual UnityEngine.AI.OffMeshLinkType @static
---@field public LinkTypeDropDown UnityEngine.AI.OffMeshLinkType @static
---@field public LinkTypeJumpAcross UnityEngine.AI.OffMeshLinkType @static
---@field public value__ number
local m = {}

UnityEngine.AI.OffMeshLinkType = m
return m
