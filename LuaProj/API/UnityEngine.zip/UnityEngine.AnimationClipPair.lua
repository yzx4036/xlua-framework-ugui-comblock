---@class UnityEngine.AnimationClipPair : System.Object
---@field public originalClip UnityEngine.AnimationClip
---@field public overrideClip UnityEngine.AnimationClip
local m = {}

UnityEngine.AnimationClipPair = m
return m
