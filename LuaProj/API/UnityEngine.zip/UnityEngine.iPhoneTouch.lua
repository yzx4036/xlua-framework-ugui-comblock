---@class UnityEngine.iPhoneTouch : System.Object
local m = {}

UnityEngine.iPhoneTouch = m
return m
