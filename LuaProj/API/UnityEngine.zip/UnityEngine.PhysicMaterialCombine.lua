---@class UnityEngine.PhysicMaterialCombine : System.Enum
---@field public Average UnityEngine.PhysicMaterialCombine @static
---@field public Minimum UnityEngine.PhysicMaterialCombine @static
---@field public Multiply UnityEngine.PhysicMaterialCombine @static
---@field public Maximum UnityEngine.PhysicMaterialCombine @static
---@field public value__ number
local m = {}

UnityEngine.PhysicMaterialCombine = m
return m
