---@class UnityEngine.ProceduralPropertyType : System.Enum
---@field public value__ number
local m = {}

UnityEngine.ProceduralPropertyType = m
return m
