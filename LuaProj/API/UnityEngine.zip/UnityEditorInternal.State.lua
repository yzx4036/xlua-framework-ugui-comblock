---@class UnityEditorInternal.State : System.Object
local m = {}

UnityEditorInternal.State = m
return m
