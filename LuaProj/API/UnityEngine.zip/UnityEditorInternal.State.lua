---@class UnityEditorInternal.State : UnityEngine.Object
---@field public uniqueName string
---@field public uniqueNameHash number
---@field public speed number
---@field public mirror boolean
---@field public iKOnFeet boolean
---@field public tag string
local m = {}

---@overload fun(layer:UnityEditorInternal.AnimatorControllerLayer):UnityEngine.Motion
---@return UnityEngine.Motion
function m:GetMotion() end

---@overload fun(layer:UnityEditorInternal.AnimatorControllerLayer):UnityEditorInternal.BlendTree
---@return UnityEditorInternal.BlendTree
function m:CreateBlendTree() end

UnityEditorInternal.State = m
return m
