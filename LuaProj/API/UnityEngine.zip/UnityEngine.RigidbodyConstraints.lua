---@class UnityEngine.RigidbodyConstraints : System.Enum
---@field public None UnityEngine.RigidbodyConstraints @static
---@field public FreezePositionX UnityEngine.RigidbodyConstraints @static
---@field public FreezePositionY UnityEngine.RigidbodyConstraints @static
---@field public FreezePositionZ UnityEngine.RigidbodyConstraints @static
---@field public FreezeRotationX UnityEngine.RigidbodyConstraints @static
---@field public FreezeRotationY UnityEngine.RigidbodyConstraints @static
---@field public FreezeRotationZ UnityEngine.RigidbodyConstraints @static
---@field public FreezePosition UnityEngine.RigidbodyConstraints @static
---@field public FreezeRotation UnityEngine.RigidbodyConstraints @static
---@field public FreezeAll UnityEngine.RigidbodyConstraints @static
---@field public value__ number
local m = {}

UnityEngine.RigidbodyConstraints = m
return m
