---@class UnityEngine.SpringJoint2D : UnityEngine.AnchoredJoint2D
---@field public autoConfigureDistance boolean
---@field public distance number
---@field public dampingRatio number
---@field public frequency number
local m = {}

UnityEngine.SpringJoint2D = m
return m
