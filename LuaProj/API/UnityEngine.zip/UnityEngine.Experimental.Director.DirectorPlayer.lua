---@class UnityEngine.Experimental.Director.DirectorPlayer : UnityEngine.Behaviour
local m = {}

---@param pStruct UnityEngine.Experimental.Director.Playable
function m:Play(pStruct) end

function m:Stop() end

---@param time number
function m:SetTime(time) end

---@return number
function m:GetTime() end

---@param mode UnityEngine.Experimental.Director.DirectorUpdateMode
function m:SetTimeUpdateMode(mode) end

---@return UnityEngine.Experimental.Director.DirectorUpdateMode
function m:GetTimeUpdateMode() end

UnityEngine.Experimental.Director.DirectorPlayer = m
return m
