---@class UnityEngine.WebCamTexture : UnityEngine.Texture
---@field public devices UnityEngine.WebCamDevice[] @static
---@field public isPlaying boolean
---@field public deviceName string
---@field public requestedFPS number
---@field public requestedWidth number
---@field public requestedHeight number
---@field public isReadable boolean
---@field public videoRotationAngle number
---@field public videoVerticallyMirrored boolean
---@field public didUpdateThisFrame boolean
local m = {}

function m:Play() end

function m:Pause() end

function m:Stop() end

function m:MarkNonReadable() end

---@param x number
---@param y number
---@return UnityEngine.Color
function m:GetPixel(x, y) end

---@overload fun(x:number, y:number, blockWidth:number, blockHeight:number):UnityEngine.Color[]
---@return UnityEngine.Color[]
function m:GetPixels() end

---@overload fun():UnityEngine.Color32[]
---@param colors UnityEngine.Color32[]
---@return UnityEngine.Color32[]
function m:GetPixels32(colors) end

UnityEngine.WebCamTexture = m
return m
