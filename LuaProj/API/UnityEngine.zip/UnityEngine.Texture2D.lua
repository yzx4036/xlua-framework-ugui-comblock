---@class UnityEngine.Texture2D : UnityEngine.Texture
---@field public whiteTexture UnityEngine.Texture2D @static
---@field public blackTexture UnityEngine.Texture2D @static
---@field public mipmapCount number
---@field public format UnityEngine.TextureFormat
---@field public alphaIsTransparency boolean
local m = {}

---@static
---@param width number
---@param height number
---@param format UnityEngine.TextureFormat
---@param mipmap boolean
---@param linear boolean
---@param nativeTex System.IntPtr
---@return UnityEngine.Texture2D
function m.CreateExternalTexture(width, height, format, mipmap, linear, nativeTex) end

---@param nativeTex System.IntPtr
function m:UpdateExternalTexture(nativeTex) end

---@param x number
---@param y number
---@param color UnityEngine.Color
function m:SetPixel(x, y, color) end

---@param x number
---@param y number
---@return UnityEngine.Color
function m:GetPixel(x, y) end

---@param u number
---@param v number
---@return UnityEngine.Color
function m:GetPixelBilinear(u, v) end

---@overload fun(colors:UnityEngine.Color[], miplevel:number)
---@overload fun(x:number, y:number, blockWidth:number, blockHeight:number, colors:UnityEngine.Color[], miplevel:number)
---@overload fun(x:number, y:number, blockWidth:number, blockHeight:number, colors:UnityEngine.Color[])
---@param colors UnityEngine.Color[]
function m:SetPixels(colors) end

---@overload fun(colors:UnityEngine.Color32[], miplevel:number)
---@overload fun(x:number, y:number, blockWidth:number, blockHeight:number, colors:UnityEngine.Color32[])
---@overload fun(x:number, y:number, blockWidth:number, blockHeight:number, colors:UnityEngine.Color32[], miplevel:number)
---@param colors UnityEngine.Color32[]
function m:SetPixels32(colors) end

---@overload fun(data:string):boolean
---@param data string
---@param markNonReadable boolean
---@return boolean
function m:LoadImage(data, markNonReadable) end

---@overload fun(data:System.IntPtr, size:number)
---@param data string
function m:LoadRawTextureData(data) end

---@return string
function m:GetRawTextureData() end

---@overload fun(miplevel:number):UnityEngine.Color[]
---@overload fun(x:number, y:number, blockWidth:number, blockHeight:number, miplevel:number):UnityEngine.Color[]
---@overload fun(x:number, y:number, blockWidth:number, blockHeight:number):UnityEngine.Color[]
---@return UnityEngine.Color[]
function m:GetPixels() end

---@overload fun():UnityEngine.Color32[]
---@param miplevel number
---@return UnityEngine.Color32[]
function m:GetPixels32(miplevel) end

---@overload fun(updateMipmaps:boolean)
---@overload fun()
---@param updateMipmaps boolean
---@param makeNoLongerReadable boolean
function m:Apply(updateMipmaps, makeNoLongerReadable) end

---@overload fun(width:number, height:number):boolean
---@param width number
---@param height number
---@param format UnityEngine.TextureFormat
---@param hasMipMap boolean
---@return boolean
function m:Resize(width, height, format, hasMipMap) end

---@param highQuality boolean
function m:Compress(highQuality) end

---@overload fun(textures:UnityEngine.Texture2D[], padding:number, maximumAtlasSize:number):UnityEngine.Rect[]
---@overload fun(textures:UnityEngine.Texture2D[], padding:number):UnityEngine.Rect[]
---@param textures UnityEngine.Texture2D[]
---@param padding number
---@param maximumAtlasSize number
---@param makeNoLongerReadable boolean
---@return UnityEngine.Rect[]
function m:PackTextures(textures, padding, maximumAtlasSize, makeNoLongerReadable) end

---@overload fun(source:UnityEngine.Rect, destX:number, destY:number)
---@param source UnityEngine.Rect
---@param destX number
---@param destY number
---@param recalculateMipMaps boolean
function m:ReadPixels(source, destX, destY, recalculateMipMaps) end

---@return string
function m:EncodeToPNG() end

---@overload fun():string
---@param quality number
---@return string
function m:EncodeToJPG(quality) end

UnityEngine.Texture2D = m
return m
