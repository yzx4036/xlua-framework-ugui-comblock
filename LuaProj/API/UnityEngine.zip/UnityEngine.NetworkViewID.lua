---@class UnityEngine.NetworkViewID : System.Object
local m = {}

UnityEngine.NetworkViewID = m
return m
