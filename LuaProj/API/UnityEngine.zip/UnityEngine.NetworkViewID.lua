---@class UnityEngine.NetworkViewID : System.ValueType
---@field public unassigned UnityEngine.NetworkViewID @static
---@field public isMine boolean
---@field public owner UnityEngine.NetworkPlayer
local m = {}

---@static
---@param lhs UnityEngine.NetworkViewID
---@param rhs UnityEngine.NetworkViewID
---@return boolean
function m.op_Equality(lhs, rhs) end

---@static
---@param lhs UnityEngine.NetworkViewID
---@param rhs UnityEngine.NetworkViewID
---@return boolean
function m.op_Inequality(lhs, rhs) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@param other any
---@return boolean
function m:Equals(other) end

---@virtual
---@return string
function m:ToString() end

UnityEngine.NetworkViewID = m
return m
