---@class UnityEngine.Experimental.Director.DirectorUpdateMode : System.Enum
---@field public DSPClock UnityEngine.Experimental.Director.DirectorUpdateMode @static
---@field public GameTime UnityEngine.Experimental.Director.DirectorUpdateMode @static
---@field public UnscaledGameTime UnityEngine.Experimental.Director.DirectorUpdateMode @static
---@field public Manual UnityEngine.Experimental.Director.DirectorUpdateMode @static
---@field public value__ number
local m = {}

UnityEngine.Experimental.Director.DirectorUpdateMode = m
return m
