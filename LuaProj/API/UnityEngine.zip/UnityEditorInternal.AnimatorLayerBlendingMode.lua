---@class UnityEditorInternal.AnimatorLayerBlendingMode : System.Enum
---@field public Override UnityEditorInternal.AnimatorLayerBlendingMode @static
---@field public Additive UnityEditorInternal.AnimatorLayerBlendingMode @static
---@field public value__ number
local m = {}

UnityEditorInternal.AnimatorLayerBlendingMode = m
return m
