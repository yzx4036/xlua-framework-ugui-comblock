---@class UnityEditorInternal.AnimatorLayerBlendingMode : System.Enum
---@field public value__ number
local m = {}

UnityEditorInternal.AnimatorLayerBlendingMode = m
return m
