---@class UnityEngine.VR.VRDeviceType : System.Enum
---@field public value__ number
local m = {}

UnityEngine.VR.VRDeviceType = m
return m
