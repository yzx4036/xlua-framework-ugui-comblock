---@class UnityEngine.iPhoneTouchPhase : System.Enum
---@field public value__ number
local m = {}

UnityEngine.iPhoneTouchPhase = m
return m
