---@class UnityEngine.ADBannerView : System.Object
local m = {}

UnityEngine.ADBannerView = m
return m
