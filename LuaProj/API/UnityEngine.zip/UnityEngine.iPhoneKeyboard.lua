---@class UnityEngine.iPhoneKeyboard : System.Object
local m = {}

UnityEngine.iPhoneKeyboard = m
return m
