---@class UnityEngine.AnimationInfo : System.Object
local m = {}

UnityEngine.AnimationInfo = m
return m
