---@class UnityEngine.VR.VRNode : System.Enum
---@field public value__ number
local m = {}

UnityEngine.VR.VRNode = m
return m
