---@class UnityEditorInternal.AnimatorControllerParameter : System.Object
local m = {}

UnityEditorInternal.AnimatorControllerParameter = m
return m
