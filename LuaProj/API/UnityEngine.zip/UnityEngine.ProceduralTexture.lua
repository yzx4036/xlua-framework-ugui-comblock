---@class UnityEngine.ProceduralTexture : System.Object
local m = {}

UnityEngine.ProceduralTexture = m
return m
