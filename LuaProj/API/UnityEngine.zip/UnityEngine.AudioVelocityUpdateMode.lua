---@class UnityEngine.AudioVelocityUpdateMode : System.Enum
---@field public Auto UnityEngine.AudioVelocityUpdateMode @static
---@field public Fixed UnityEngine.AudioVelocityUpdateMode @static
---@field public Dynamic UnityEngine.AudioVelocityUpdateMode @static
---@field public value__ number
local m = {}

UnityEngine.AudioVelocityUpdateMode = m
return m
