---@class UnityEngine.ParticleSystemVertexStreams : System.Enum
---@field public Position UnityEngine.ParticleSystemVertexStreams @static
---@field public Normal UnityEngine.ParticleSystemVertexStreams @static
---@field public Tangent UnityEngine.ParticleSystemVertexStreams @static
---@field public Color UnityEngine.ParticleSystemVertexStreams @static
---@field public UV UnityEngine.ParticleSystemVertexStreams @static
---@field public UV2BlendAndFrame UnityEngine.ParticleSystemVertexStreams @static
---@field public CenterAndVertexID UnityEngine.ParticleSystemVertexStreams @static
---@field public Size UnityEngine.ParticleSystemVertexStreams @static
---@field public Rotation UnityEngine.ParticleSystemVertexStreams @static
---@field public Velocity UnityEngine.ParticleSystemVertexStreams @static
---@field public Lifetime UnityEngine.ParticleSystemVertexStreams @static
---@field public Custom1 UnityEngine.ParticleSystemVertexStreams @static
---@field public Custom2 UnityEngine.ParticleSystemVertexStreams @static
---@field public Random UnityEngine.ParticleSystemVertexStreams @static
---@field public None UnityEngine.ParticleSystemVertexStreams @static
---@field public All UnityEngine.ParticleSystemVertexStreams @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemVertexStreams = m
return m
