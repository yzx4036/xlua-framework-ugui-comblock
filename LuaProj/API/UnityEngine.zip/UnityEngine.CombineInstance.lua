---@class UnityEngine.CombineInstance : System.ValueType
---@field public mesh UnityEngine.Mesh
---@field public subMeshIndex number
---@field public transform UnityEngine.Matrix4x4
local m = {}

UnityEngine.CombineInstance = m
return m
