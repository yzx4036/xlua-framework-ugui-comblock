---@class UnityEngine.SpriteMeshType : System.Enum
---@field public FullRect UnityEngine.SpriteMeshType @static
---@field public Tight UnityEngine.SpriteMeshType @static
---@field public value__ number
local m = {}

UnityEngine.SpriteMeshType = m
return m
