---@class UnityEngine.NetworkPlayer : System.Object
local m = {}

UnityEngine.NetworkPlayer = m
return m
