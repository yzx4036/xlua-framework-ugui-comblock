---@class UnityEngine.DrivenRectTransformTracker : System.ValueType
local m = {}

---@param driver UnityEngine.Object
---@param rectTransform UnityEngine.RectTransform
---@param drivenProperties UnityEngine.DrivenTransformProperties
function m:Add(driver, rectTransform, drivenProperties) end

function m:Clear() end

UnityEngine.DrivenRectTransformTracker = m
return m
