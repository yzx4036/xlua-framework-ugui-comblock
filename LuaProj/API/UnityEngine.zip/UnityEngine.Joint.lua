---@class UnityEngine.Joint : UnityEngine.Component
---@field public connectedBody UnityEngine.Rigidbody
---@field public axis UnityEngine.Vector3
---@field public anchor UnityEngine.Vector3
---@field public connectedAnchor UnityEngine.Vector3
---@field public autoConfigureConnectedAnchor boolean
---@field public breakForce number
---@field public breakTorque number
---@field public enableCollision boolean
---@field public enablePreprocessing boolean
---@field public currentForce UnityEngine.Vector3
---@field public currentTorque UnityEngine.Vector3
local m = {}

UnityEngine.Joint = m
return m
