---@class UnityEngine.VR.InputTracking : System.Object
local m = {}

UnityEngine.VR.InputTracking = m
return m
