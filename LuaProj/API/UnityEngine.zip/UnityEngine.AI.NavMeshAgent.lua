---@class UnityEngine.AI.NavMeshAgent : UnityEngine.Behaviour
---@field public destination UnityEngine.Vector3
---@field public stoppingDistance number
---@field public velocity UnityEngine.Vector3
---@field public nextPosition UnityEngine.Vector3
---@field public steeringTarget UnityEngine.Vector3
---@field public desiredVelocity UnityEngine.Vector3
---@field public remainingDistance number
---@field public baseOffset number
---@field public isOnOffMeshLink boolean
---@field public currentOffMeshLinkData UnityEngine.AI.OffMeshLinkData
---@field public nextOffMeshLinkData UnityEngine.AI.OffMeshLinkData
---@field public autoTraverseOffMeshLink boolean
---@field public autoBraking boolean
---@field public autoRepath boolean
---@field public hasPath boolean
---@field public pathPending boolean
---@field public isPathStale boolean
---@field public pathStatus UnityEngine.AI.NavMeshPathStatus
---@field public pathEndPosition UnityEngine.Vector3
---@field public path UnityEngine.AI.NavMeshPath
---@field public walkableMask number
---@field public areaMask number
---@field public speed number
---@field public angularSpeed number
---@field public acceleration number
---@field public updatePosition boolean
---@field public updateRotation boolean
---@field public radius number
---@field public height number
---@field public obstacleAvoidanceType UnityEngine.AI.ObstacleAvoidanceType
---@field public avoidancePriority number
---@field public isOnNavMesh boolean
local m = {}

---@param target UnityEngine.Vector3
---@return boolean
function m:SetDestination(target) end

---@param activated boolean
function m:ActivateCurrentOffMeshLink(activated) end

function m:CompleteOffMeshLink() end

---@param newPosition UnityEngine.Vector3
---@return boolean
function m:Warp(newPosition) end

---@param offset UnityEngine.Vector3
function m:Move(offset) end

---@overload fun(stopUpdates:boolean)
function m:Stop() end

function m:Resume() end

function m:ResetPath() end

---@param path UnityEngine.AI.NavMeshPath
---@return boolean
function m:SetPath(path) end

---@return boolean, UnityEngine.AI.NavMeshHit
function m:FindClosestEdge() end

---@param targetPosition UnityEngine.Vector3
---@return boolean, UnityEngine.AI.NavMeshHit
function m:Raycast(targetPosition) end

---@param targetPosition UnityEngine.Vector3
---@param path UnityEngine.AI.NavMeshPath
---@return boolean
function m:CalculatePath(targetPosition, path) end

---@param areaMask number
---@param maxDistance number
---@return boolean, UnityEngine.AI.NavMeshHit
function m:SamplePathPosition(areaMask, maxDistance) end

---@param layer number
---@param cost number
function m:SetLayerCost(layer, cost) end

---@param layer number
---@return number
function m:GetLayerCost(layer) end

---@param areaIndex number
---@param areaCost number
function m:SetAreaCost(areaIndex, areaCost) end

---@param areaIndex number
---@return number
function m:GetAreaCost(areaIndex) end

UnityEngine.AI.NavMeshAgent = m
return m
