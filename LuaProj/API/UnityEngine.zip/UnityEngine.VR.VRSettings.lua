---@class UnityEngine.VR.VRSettings : System.Object
local m = {}

UnityEngine.VR.VRSettings = m
return m
