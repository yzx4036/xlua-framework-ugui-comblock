---@class UnityEngine.ParticleSystem.InheritVelocityModule : System.ValueType
---@field public enabled boolean
---@field public mode UnityEngine.ParticleSystemInheritVelocityMode
---@field public curve UnityEngine.ParticleSystem.MinMaxCurve
---@field public curveMultiplier number
local m = {}

UnityEngine.ParticleSystem.InheritVelocityModule = m
return m
