---@class UnityEngine.NetworkConnectionError : System.Enum
---@field public NoError UnityEngine.NetworkConnectionError @static
---@field public RSAPublicKeyMismatch UnityEngine.NetworkConnectionError @static
---@field public InvalidPassword UnityEngine.NetworkConnectionError @static
---@field public ConnectionFailed UnityEngine.NetworkConnectionError @static
---@field public TooManyConnectedPlayers UnityEngine.NetworkConnectionError @static
---@field public ConnectionBanned UnityEngine.NetworkConnectionError @static
---@field public AlreadyConnectedToServer UnityEngine.NetworkConnectionError @static
---@field public AlreadyConnectedToAnotherServer UnityEngine.NetworkConnectionError @static
---@field public CreateSocketOrThreadFailure UnityEngine.NetworkConnectionError @static
---@field public IncorrectParameters UnityEngine.NetworkConnectionError @static
---@field public EmptyConnectTarget UnityEngine.NetworkConnectionError @static
---@field public InternalDirectConnectFailed UnityEngine.NetworkConnectionError @static
---@field public NATTargetNotConnected UnityEngine.NetworkConnectionError @static
---@field public NATTargetConnectionLost UnityEngine.NetworkConnectionError @static
---@field public NATPunchthroughFailed UnityEngine.NetworkConnectionError @static
---@field public value__ number
local m = {}

UnityEngine.NetworkConnectionError = m
return m
