---@class UnityEngine.NetworkConnectionError : System.Enum
---@field public value__ number
local m = {}

UnityEngine.NetworkConnectionError = m
return m
