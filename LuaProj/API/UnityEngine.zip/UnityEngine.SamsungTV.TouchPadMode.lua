---@class UnityEngine.SamsungTV.TouchPadMode : System.Enum
---@field public Dpad UnityEngine.SamsungTV.TouchPadMode @static
---@field public Joystick UnityEngine.SamsungTV.TouchPadMode @static
---@field public Mouse UnityEngine.SamsungTV.TouchPadMode @static
---@field public value__ number
local m = {}

UnityEngine.SamsungTV.TouchPadMode = m
return m
