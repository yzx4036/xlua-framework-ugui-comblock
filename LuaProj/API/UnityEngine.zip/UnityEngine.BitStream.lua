---@class UnityEngine.BitStream : System.Object
local m = {}

UnityEngine.BitStream = m
return m
