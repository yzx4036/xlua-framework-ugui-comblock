---@class UnityEngine.AudioConfiguration : System.ValueType
---@field public speakerMode UnityEngine.AudioSpeakerMode
---@field public dspBufferSize number
---@field public sampleRate number
---@field public numRealVoices number
---@field public numVirtualVoices number
local m = {}

UnityEngine.AudioConfiguration = m
return m
