---@class UnityEngine.Experimental.Director.ScriptPlayable : System.Object
local m = {}

UnityEngine.Experimental.Director.ScriptPlayable = m
return m
