---@class UnityEngine.QueryTriggerInteraction : System.Enum
---@field public UseGlobal UnityEngine.QueryTriggerInteraction @static
---@field public Ignore UnityEngine.QueryTriggerInteraction @static
---@field public Collide UnityEngine.QueryTriggerInteraction @static
---@field public value__ number
local m = {}

UnityEngine.QueryTriggerInteraction = m
return m
