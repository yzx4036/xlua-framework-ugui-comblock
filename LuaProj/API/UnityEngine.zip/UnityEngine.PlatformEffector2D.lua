---@class UnityEngine.PlatformEffector2D : UnityEngine.Effector2D
---@field public oneWay boolean
---@field public sideFriction boolean
---@field public sideBounce boolean
---@field public sideAngleVariance number
---@field public useOneWay boolean
---@field public useOneWayGrouping boolean
---@field public useSideFriction boolean
---@field public useSideBounce boolean
---@field public surfaceArc number
---@field public sideArc number
---@field public rotationalOffset number
local m = {}

UnityEngine.PlatformEffector2D = m
return m
