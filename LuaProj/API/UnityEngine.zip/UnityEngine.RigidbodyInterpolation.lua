---@class UnityEngine.RigidbodyInterpolation : System.Enum
---@field public None UnityEngine.RigidbodyInterpolation @static
---@field public Interpolate UnityEngine.RigidbodyInterpolation @static
---@field public Extrapolate UnityEngine.RigidbodyInterpolation @static
---@field public value__ number
local m = {}

UnityEngine.RigidbodyInterpolation = m
return m
