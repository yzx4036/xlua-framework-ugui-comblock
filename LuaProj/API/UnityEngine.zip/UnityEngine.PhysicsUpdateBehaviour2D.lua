---@class UnityEngine.PhysicsUpdateBehaviour2D : UnityEngine.Behaviour
local m = {}

UnityEngine.PhysicsUpdateBehaviour2D = m
return m
