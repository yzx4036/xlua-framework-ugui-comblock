---@class UnityEngine.NetworkStateSynchronization : System.Enum
---@field public Off UnityEngine.NetworkStateSynchronization @static
---@field public ReliableDeltaCompressed UnityEngine.NetworkStateSynchronization @static
---@field public Unreliable UnityEngine.NetworkStateSynchronization @static
---@field public value__ number
local m = {}

UnityEngine.NetworkStateSynchronization = m
return m
