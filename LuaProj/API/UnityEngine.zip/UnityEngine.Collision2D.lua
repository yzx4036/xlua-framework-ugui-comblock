---@class UnityEngine.Collision2D : System.Object
---@field public enabled boolean
---@field public rigidbody UnityEngine.Rigidbody2D
---@field public collider UnityEngine.Collider2D
---@field public transform UnityEngine.Transform
---@field public gameObject UnityEngine.GameObject
---@field public contacts UnityEngine.ContactPoint2D[]
---@field public relativeVelocity UnityEngine.Vector2
local m = {}

UnityEngine.Collision2D = m
return m
