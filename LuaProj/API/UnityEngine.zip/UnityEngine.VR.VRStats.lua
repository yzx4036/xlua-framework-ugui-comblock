---@class UnityEngine.VR.VRStats : System.Object
local m = {}

UnityEngine.VR.VRStats = m
return m
