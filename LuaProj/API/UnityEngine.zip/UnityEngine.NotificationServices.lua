---@class UnityEngine.NotificationServices : System.Object
local m = {}

UnityEngine.NotificationServices = m
return m
