---@class UnityEngine.LightmappingMode : System.Enum
---@field public value__ number
local m = {}

UnityEngine.LightmappingMode = m
return m
