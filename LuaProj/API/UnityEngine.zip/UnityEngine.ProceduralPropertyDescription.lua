---@class UnityEngine.ProceduralPropertyDescription : System.Object
local m = {}

UnityEngine.ProceduralPropertyDescription = m
return m
