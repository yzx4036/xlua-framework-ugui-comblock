---@class UnityEngine.ProceduralPropertyDescription : System.Object
---@field public name string
---@field public label string
---@field public group string
---@field public type UnityEngine.ProceduralPropertyType
---@field public hasRange boolean
---@field public minimum number
---@field public maximum number
---@field public step number
---@field public enumOptions string[]
---@field public componentLabels string[]
local m = {}

UnityEngine.ProceduralPropertyDescription = m
return m
