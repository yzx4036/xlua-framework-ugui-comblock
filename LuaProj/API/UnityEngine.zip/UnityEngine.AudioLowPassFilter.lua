---@class UnityEngine.AudioLowPassFilter : UnityEngine.Behaviour
---@field public cutoffFrequency number
---@field public customCutoffCurve UnityEngine.AnimationCurve
---@field public lowpassResonanceQ number
---@field public lowpassResonaceQ number
local m = {}

UnityEngine.AudioLowPassFilter = m
return m
