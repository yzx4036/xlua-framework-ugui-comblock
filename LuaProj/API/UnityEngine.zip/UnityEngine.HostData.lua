---@class UnityEngine.HostData : System.Object
---@field public useNat boolean
---@field public gameType string
---@field public gameName string
---@field public connectedPlayers number
---@field public playerLimit number
---@field public ip string[]
---@field public port number
---@field public passwordProtected boolean
---@field public comment string
---@field public guid string
local m = {}

UnityEngine.HostData = m
return m
