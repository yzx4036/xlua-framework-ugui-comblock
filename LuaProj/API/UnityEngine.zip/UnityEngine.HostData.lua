---@class UnityEngine.HostData : System.Object
local m = {}

UnityEngine.HostData = m
return m
