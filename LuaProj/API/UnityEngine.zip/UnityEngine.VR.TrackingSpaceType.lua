---@class UnityEngine.VR.TrackingSpaceType : System.Enum
---@field public value__ number
local m = {}

UnityEngine.VR.TrackingSpaceType = m
return m
