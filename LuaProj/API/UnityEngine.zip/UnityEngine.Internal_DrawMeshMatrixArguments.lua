---@class UnityEngine.Internal_DrawMeshMatrixArguments : System.ValueType
---@field public layer number
---@field public submeshIndex number
---@field public matrix UnityEngine.Matrix4x4
---@field public castShadows number
---@field public receiveShadows number
---@field public reflectionProbeAnchorInstanceID number
---@field public useLightProbes boolean
local m = {}

UnityEngine.Internal_DrawMeshMatrixArguments = m
return m
