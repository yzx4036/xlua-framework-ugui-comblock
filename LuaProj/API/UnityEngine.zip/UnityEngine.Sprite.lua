---@class UnityEngine.Sprite : UnityEngine.Object
---@field public bounds UnityEngine.Bounds
---@field public rect UnityEngine.Rect
---@field public pixelsPerUnit number
---@field public texture UnityEngine.Texture2D
---@field public associatedAlphaSplitTexture UnityEngine.Texture2D
---@field public textureRect UnityEngine.Rect
---@field public textureRectOffset UnityEngine.Vector2
---@field public packed boolean
---@field public packingMode UnityEngine.SpritePackingMode
---@field public packingRotation UnityEngine.SpritePackingRotation
---@field public pivot UnityEngine.Vector2
---@field public border UnityEngine.Vector4
---@field public vertices UnityEngine.Vector2[]
---@field public triangles number[]
---@field public uv UnityEngine.Vector2[]
local m = {}

---@overload fun(texture:UnityEngine.Texture2D, rect:UnityEngine.Rect, pivot:UnityEngine.Vector2, pixelsPerUnit:number, extrude:number, meshType:UnityEngine.SpriteMeshType):UnityEngine.Sprite @static
---@overload fun(texture:UnityEngine.Texture2D, rect:UnityEngine.Rect, pivot:UnityEngine.Vector2, pixelsPerUnit:number, extrude:number):UnityEngine.Sprite @static
---@overload fun(texture:UnityEngine.Texture2D, rect:UnityEngine.Rect, pivot:UnityEngine.Vector2, pixelsPerUnit:number):UnityEngine.Sprite @static
---@overload fun(texture:UnityEngine.Texture2D, rect:UnityEngine.Rect, pivot:UnityEngine.Vector2):UnityEngine.Sprite @static
---@static
---@param texture UnityEngine.Texture2D
---@param rect UnityEngine.Rect
---@param pivot UnityEngine.Vector2
---@param pixelsPerUnit number
---@param extrude number
---@param meshType UnityEngine.SpriteMeshType
---@param border UnityEngine.Vector4
---@return UnityEngine.Sprite
function m.Create(texture, rect, pivot, pixelsPerUnit, extrude, meshType, border) end

---@param vertices UnityEngine.Vector2[]
---@param triangles number[]
function m:OverrideGeometry(vertices, triangles) end

UnityEngine.Sprite = m
return m
