---@class UnityEngine.MovieTexture : UnityEngine.Texture
---@field public audioClip UnityEngine.AudioClip
---@field public loop boolean
---@field public isPlaying boolean
---@field public isReadyToPlay boolean
---@field public duration number
local m = {}

function m:Play() end

function m:Stop() end

function m:Pause() end

UnityEngine.MovieTexture = m
return m
