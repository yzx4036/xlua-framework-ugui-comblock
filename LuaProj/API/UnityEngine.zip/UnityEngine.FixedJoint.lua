---@class UnityEngine.FixedJoint : UnityEngine.Joint
local m = {}

UnityEngine.FixedJoint = m
return m
