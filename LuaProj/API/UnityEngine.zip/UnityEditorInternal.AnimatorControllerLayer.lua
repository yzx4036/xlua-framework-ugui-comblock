---@class UnityEditorInternal.AnimatorControllerLayer : System.Object
local m = {}

UnityEditorInternal.AnimatorControllerLayer = m
return m
