---@class UnityEngine.CalendarUnit : System.Enum
---@field public value__ number
local m = {}

UnityEngine.CalendarUnit = m
return m
