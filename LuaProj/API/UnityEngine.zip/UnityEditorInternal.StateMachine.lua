---@class UnityEditorInternal.StateMachine : System.Object
local m = {}

UnityEditorInternal.StateMachine = m
return m
