---@class UnityEditorInternal.StateMachine : UnityEngine.Object
---@field public defaultState UnityEditorInternal.State
---@field public anyStatePosition UnityEngine.Vector3
---@field public parentStateMachinePosition UnityEngine.Vector3
local m = {}

---@param index number
---@return UnityEditorInternal.State
function m:GetState(index) end

---@param stateName string
---@return UnityEditorInternal.State
function m:AddState(stateName) end

---@param index number
---@return UnityEditorInternal.StateMachine
function m:GetStateMachine(index) end

---@param stateMachineName string
---@return UnityEditorInternal.StateMachine
function m:AddStateMachine(stateMachineName) end

---@param src UnityEditorInternal.State
---@param dst UnityEditorInternal.State
---@return UnityEditorInternal.Transition
function m:AddTransition(src, dst) end

---@param dst UnityEditorInternal.State
---@return UnityEditorInternal.Transition
function m:AddAnyStateTransition(dst) end

---@param i number
---@return UnityEngine.Vector3
function m:GetStateMachinePosition(i) end

---@param srcState UnityEditorInternal.State
---@return UnityEditorInternal.Transition[]
function m:GetTransitionsFromState(srcState) end

UnityEditorInternal.StateMachine = m
return m
