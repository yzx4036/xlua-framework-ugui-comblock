---@class UnityEngine.iOS.ADBannerView : System.Object
local m = {}

UnityEngine.iOS.ADBannerView = m
return m
