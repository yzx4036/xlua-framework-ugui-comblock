---@class UnityEngine.NetworkMessageInfo : System.Object
local m = {}

UnityEngine.NetworkMessageInfo = m
return m
