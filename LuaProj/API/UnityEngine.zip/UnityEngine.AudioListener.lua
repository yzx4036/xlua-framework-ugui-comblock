---@class UnityEngine.AudioListener : UnityEngine.Behaviour
---@field public volume number @static
---@field public pause boolean @static
---@field public velocityUpdateMode UnityEngine.AudioVelocityUpdateMode
local m = {}

---@overload fun(samples:number[], channel:number) @static
---@static
---@param numSamples number
---@param channel number
---@return number[]
function m.GetOutputData(numSamples, channel) end

---@overload fun(samples:number[], channel:number, window:UnityEngine.FFTWindow) @static
---@static
---@param numSamples number
---@param channel number
---@param window UnityEngine.FFTWindow
---@return number[]
function m.GetSpectrumData(numSamples, channel, window) end

UnityEngine.AudioListener = m
return m
