---@class UnityEngine.FixedJoint2D : UnityEngine.AnchoredJoint2D
---@field public dampingRatio number
---@field public frequency number
---@field public referenceAngle number
local m = {}

UnityEngine.FixedJoint2D = m
return m
