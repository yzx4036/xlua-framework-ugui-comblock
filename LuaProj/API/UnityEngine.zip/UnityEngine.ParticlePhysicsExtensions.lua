---@class UnityEngine.ParticlePhysicsExtensions : System.Object
local m = {}

---@static
---@param ps UnityEngine.ParticleSystem
---@return number
function m.GetSafeCollisionEventSize(ps) end

---@overload fun(ps:UnityEngine.ParticleSystem, go:UnityEngine.GameObject, collisionEvents:UnityEngine.ParticleCollisionEvent[]):number @static
---@static
---@param ps UnityEngine.ParticleSystem
---@param go UnityEngine.GameObject
---@param collisionEvents UnityEngine.ParticleCollisionEvent[]
---@return number
function m.GetCollisionEvents(ps, go, collisionEvents) end

---@static
---@param ps UnityEngine.ParticleSystem
---@param type UnityEngine.ParticleSystemTriggerEventType
---@return number
function m.GetSafeTriggerParticlesSize(ps, type) end

---@static
---@param ps UnityEngine.ParticleSystem
---@param type UnityEngine.ParticleSystemTriggerEventType
---@param particles UnityEngine.ParticleSystem.Particle[]
---@return number
function m.GetTriggerParticles(ps, type, particles) end

---@overload fun(ps:UnityEngine.ParticleSystem, type:UnityEngine.ParticleSystemTriggerEventType, particles:UnityEngine.ParticleSystem.Particle[]) @static
---@static
---@param ps UnityEngine.ParticleSystem
---@param type UnityEngine.ParticleSystemTriggerEventType
---@param particles UnityEngine.ParticleSystem.Particle[]
---@param offset number
---@param count number
function m.SetTriggerParticles(ps, type, particles, offset, count) end

UnityEngine.ParticlePhysicsExtensions = m
return m
