---@class UnityEngine.FFTWindow : System.Enum
---@field public Rectangular UnityEngine.FFTWindow @static
---@field public Triangle UnityEngine.FFTWindow @static
---@field public Hamming UnityEngine.FFTWindow @static
---@field public Hanning UnityEngine.FFTWindow @static
---@field public Blackman UnityEngine.FFTWindow @static
---@field public BlackmanHarris UnityEngine.FFTWindow @static
---@field public value__ number
local m = {}

UnityEngine.FFTWindow = m
return m
