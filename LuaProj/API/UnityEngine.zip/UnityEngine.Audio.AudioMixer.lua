---@class UnityEngine.Audio.AudioMixer : UnityEngine.Object
---@field public outputAudioMixerGroup UnityEngine.Audio.AudioMixerGroup
---@field public updateMode UnityEngine.Audio.AudioMixerUpdateMode
local m = {}

---@param subPath string
---@return UnityEngine.Audio.AudioMixerGroup[]
function m:FindMatchingGroups(subPath) end

---@param name string
---@return UnityEngine.Audio.AudioMixerSnapshot
function m:FindSnapshot(name) end

---@param snapshots UnityEngine.Audio.AudioMixerSnapshot[]
---@param weights number[]
---@param timeToReach number
function m:TransitionToSnapshots(snapshots, weights, timeToReach) end

---@param name string
---@param value number
---@return boolean
function m:SetFloat(name, value) end

---@param name string
---@return boolean
function m:ClearFloat(name) end

---@param name string
---@return boolean, System.Single
function m:GetFloat(name) end

UnityEngine.Audio.AudioMixer = m
return m
