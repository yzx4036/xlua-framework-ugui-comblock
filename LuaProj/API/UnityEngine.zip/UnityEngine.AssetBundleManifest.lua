---@class UnityEngine.AssetBundleManifest : UnityEngine.Object
local m = {}

---@return string[]
function m:GetAllAssetBundles() end

---@return string[]
function m:GetAllAssetBundlesWithVariant() end

---@param assetBundleName string
---@return UnityEngine.Hash128
function m:GetAssetBundleHash(assetBundleName) end

---@param assetBundleName string
---@return string[]
function m:GetDirectDependencies(assetBundleName) end

---@param assetBundleName string
---@return string[]
function m:GetAllDependencies(assetBundleName) end

UnityEngine.AssetBundleManifest = m
return m
