---@class UnityEngine.TouchScreenKeyboard_InternalConstructorHelperArguments : System.ValueType
---@field public keyboardType number
---@field public autocorrection number
---@field public multiline number
---@field public secure number
---@field public alert number
local m = {}

UnityEngine.TouchScreenKeyboard_InternalConstructorHelperArguments = m
return m
