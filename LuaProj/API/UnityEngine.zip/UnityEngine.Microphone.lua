---@class UnityEngine.Microphone : System.Object
---@field public devices string[] @static
local m = {}

---@static
---@param deviceName string
---@param loop boolean
---@param lengthSec number
---@param frequency number
---@return UnityEngine.AudioClip
function m.Start(deviceName, loop, lengthSec, frequency) end

---@static
---@param deviceName string
function m.End(deviceName) end

---@static
---@param deviceName string
---@return boolean
function m.IsRecording(deviceName) end

---@static
---@param deviceName string
---@return number
function m.GetPosition(deviceName) end

---@static
---@param deviceName string
---@return System.Int32, System.Int32
function m.GetDeviceCaps(deviceName) end

UnityEngine.Microphone = m
return m
