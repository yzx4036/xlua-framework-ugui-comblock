---@class UnityEngine.AudioReverbPreset : System.Enum
---@field public Off UnityEngine.AudioReverbPreset @static
---@field public Generic UnityEngine.AudioReverbPreset @static
---@field public PaddedCell UnityEngine.AudioReverbPreset @static
---@field public Room UnityEngine.AudioReverbPreset @static
---@field public Bathroom UnityEngine.AudioReverbPreset @static
---@field public Livingroom UnityEngine.AudioReverbPreset @static
---@field public Stoneroom UnityEngine.AudioReverbPreset @static
---@field public Auditorium UnityEngine.AudioReverbPreset @static
---@field public Concerthall UnityEngine.AudioReverbPreset @static
---@field public Cave UnityEngine.AudioReverbPreset @static
---@field public Arena UnityEngine.AudioReverbPreset @static
---@field public Hangar UnityEngine.AudioReverbPreset @static
---@field public CarpetedHallway UnityEngine.AudioReverbPreset @static
---@field public Hallway UnityEngine.AudioReverbPreset @static
---@field public StoneCorridor UnityEngine.AudioReverbPreset @static
---@field public Alley UnityEngine.AudioReverbPreset @static
---@field public Forest UnityEngine.AudioReverbPreset @static
---@field public City UnityEngine.AudioReverbPreset @static
---@field public Mountains UnityEngine.AudioReverbPreset @static
---@field public Quarry UnityEngine.AudioReverbPreset @static
---@field public Plain UnityEngine.AudioReverbPreset @static
---@field public ParkingLot UnityEngine.AudioReverbPreset @static
---@field public SewerPipe UnityEngine.AudioReverbPreset @static
---@field public Underwater UnityEngine.AudioReverbPreset @static
---@field public Drugged UnityEngine.AudioReverbPreset @static
---@field public Dizzy UnityEngine.AudioReverbPreset @static
---@field public Psychotic UnityEngine.AudioReverbPreset @static
---@field public User UnityEngine.AudioReverbPreset @static
---@field public value__ number
local m = {}

UnityEngine.AudioReverbPreset = m
return m
