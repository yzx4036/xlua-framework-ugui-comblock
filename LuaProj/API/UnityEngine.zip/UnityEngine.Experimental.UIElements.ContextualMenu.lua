---@class UnityEngine.Experimental.UIElements.ContextualMenu : System.Object
local m = {}

UnityEngine.Experimental.UIElements.ContextualMenu = m
return m
