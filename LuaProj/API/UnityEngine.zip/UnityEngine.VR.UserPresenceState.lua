---@class UnityEngine.VR.UserPresenceState : System.Enum
---@field public value__ number
local m = {}

UnityEngine.VR.UserPresenceState = m
return m
