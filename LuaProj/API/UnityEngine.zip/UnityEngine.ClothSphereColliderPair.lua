---@class UnityEngine.ClothSphereColliderPair : System.ValueType
---@field public first UnityEngine.SphereCollider
---@field public second UnityEngine.SphereCollider
local m = {}

UnityEngine.ClothSphereColliderPair = m
return m
