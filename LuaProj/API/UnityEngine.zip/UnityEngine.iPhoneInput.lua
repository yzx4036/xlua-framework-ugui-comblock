---@class UnityEngine.iPhoneInput : System.Object
local m = {}

UnityEngine.iPhoneInput = m
return m
