---@class UnityEngine.AI.OffMeshLink : UnityEngine.Component
---@field public activated boolean
---@field public occupied boolean
---@field public costOverride number
---@field public biDirectional boolean
---@field public navMeshLayer number
---@field public area number
---@field public autoUpdatePositions boolean
---@field public startTransform UnityEngine.Transform
---@field public endTransform UnityEngine.Transform
local m = {}

function m:UpdatePositions() end

UnityEngine.AI.OffMeshLink = m
return m
