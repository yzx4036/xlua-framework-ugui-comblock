---@class UnityEngine.SamsungTV : System.Object
---@field public touchPadMode UnityEngine.SamsungTV.TouchPadMode @static
---@field public gestureMode UnityEngine.SamsungTV.GestureMode @static
---@field public airMouseConnected boolean @static
---@field public gestureWorking boolean @static
---@field public gamePadMode UnityEngine.SamsungTV.GamePadMode @static
local m = {}

---@static
---@param language UnityEngine.SystemLanguage
function m.SetSystemLanguage(language) end

UnityEngine.SamsungTV = m
return m
