---@class UnityEngine.ProceduralMaterial : System.Object
local m = {}

UnityEngine.ProceduralMaterial = m
return m
