---@class UnityEngine.iPhone : System.Object
local m = {}

UnityEngine.iPhone = m
return m
