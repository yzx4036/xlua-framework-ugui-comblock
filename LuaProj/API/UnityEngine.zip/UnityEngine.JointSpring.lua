---@class UnityEngine.JointSpring : System.ValueType
---@field public spring number
---@field public damper number
---@field public targetPosition number
local m = {}

UnityEngine.JointSpring = m
return m
