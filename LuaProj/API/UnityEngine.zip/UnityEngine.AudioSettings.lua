---@class UnityEngine.AudioSettings : System.Object
---@field public driverCapabilities UnityEngine.AudioSpeakerMode @static
---@field public speakerMode UnityEngine.AudioSpeakerMode @static
---@field public dspTime number @static
---@field public outputSampleRate number @static
---@field public driverCaps UnityEngine.AudioSpeakerMode @static
local m = {}

---@static
---@return System.Int32, System.Int32
function m.GetDSPBufferSize() end

---@static
---@param bufferLength number
---@param numBuffers number
function m.SetDSPBufferSize(bufferLength, numBuffers) end

---@static
---@return UnityEngine.AudioConfiguration
function m.GetConfiguration() end

---@static
---@param config UnityEngine.AudioConfiguration
---@return boolean
function m.Reset(config) end

---@static
---@param value fun(deviceWasChanged:boolean)
function m.add_OnAudioConfigurationChanged(value) end

---@static
---@param value fun(deviceWasChanged:boolean)
function m.remove_OnAudioConfigurationChanged(value) end

UnityEngine.AudioSettings = m
return m
