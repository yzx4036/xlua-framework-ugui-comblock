---@class UnityEngine.Audio.AudioMixerGroup : UnityEngine.Object
---@field public audioMixer UnityEngine.Audio.AudioMixer
local m = {}

UnityEngine.Audio.AudioMixerGroup = m
return m
