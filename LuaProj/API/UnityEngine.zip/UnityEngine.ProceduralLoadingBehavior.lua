---@class UnityEngine.ProceduralLoadingBehavior : System.Enum
---@field public value__ number
local m = {}

UnityEngine.ProceduralLoadingBehavior = m
return m
