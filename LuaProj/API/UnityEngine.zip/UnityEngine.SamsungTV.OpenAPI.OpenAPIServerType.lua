---@class UnityEngine.SamsungTV.OpenAPI.OpenAPIServerType : System.Enum
---@field public Operating UnityEngine.SamsungTV.OpenAPI.OpenAPIServerType @static
---@field public Development UnityEngine.SamsungTV.OpenAPI.OpenAPIServerType @static
---@field public Developing UnityEngine.SamsungTV.OpenAPI.OpenAPIServerType @static
---@field public Invalid UnityEngine.SamsungTV.OpenAPI.OpenAPIServerType @static
---@field public value__ number
local m = {}

UnityEngine.SamsungTV.OpenAPI.OpenAPIServerType = m
return m
