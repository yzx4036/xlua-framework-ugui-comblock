---@class UnityEngine.NetworkView : System.Object
local m = {}

UnityEngine.NetworkView = m
return m
