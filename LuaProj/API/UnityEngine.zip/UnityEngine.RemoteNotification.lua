---@class UnityEngine.RemoteNotification : System.Object
local m = {}

UnityEngine.RemoteNotification = m
return m
