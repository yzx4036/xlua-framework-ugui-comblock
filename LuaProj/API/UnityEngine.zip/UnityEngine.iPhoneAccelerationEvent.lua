---@class UnityEngine.iPhoneAccelerationEvent : System.Object
local m = {}

UnityEngine.iPhoneAccelerationEvent = m
return m
