---@class UnityEngine.Cloth : UnityEngine.Component
---@field public sleepThreshold number
---@field public bendingStiffness number
---@field public stretchingStiffness number
---@field public damping number
---@field public externalAcceleration UnityEngine.Vector3
---@field public randomAcceleration UnityEngine.Vector3
---@field public useGravity boolean
---@field public selfCollision boolean
---@field public enabled boolean
---@field public vertices UnityEngine.Vector3[]
---@field public normals UnityEngine.Vector3[]
---@field public friction number
---@field public collisionMassScale number
---@field public useContinuousCollision number
---@field public useVirtualParticles number
---@field public coefficients UnityEngine.ClothSkinningCoefficient[]
---@field public worldVelocityScale number
---@field public worldAccelerationScale number
---@field public solverFrequency boolean
---@field public capsuleColliders UnityEngine.CapsuleCollider[]
---@field public sphereColliders UnityEngine.ClothSphereColliderPair[]
local m = {}

function m:ClearTransformMotion() end

---@overload fun(enabled:boolean)
---@param enabled boolean
---@param interpolationTime number
function m:SetEnabledFading(enabled, interpolationTime) end

UnityEngine.Cloth = m
return m
