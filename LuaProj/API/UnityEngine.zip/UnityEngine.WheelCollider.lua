---@class UnityEngine.WheelCollider : UnityEngine.Collider
---@field public center UnityEngine.Vector3
---@field public radius number
---@field public suspensionDistance number
---@field public suspensionSpring UnityEngine.JointSpring
---@field public forceAppPointDistance number
---@field public mass number
---@field public wheelDampingRate number
---@field public forwardFriction UnityEngine.WheelFrictionCurve
---@field public sidewaysFriction UnityEngine.WheelFrictionCurve
---@field public motorTorque number
---@field public brakeTorque number
---@field public steerAngle number
---@field public isGrounded boolean
---@field public sprungMass number
---@field public rpm number
local m = {}

---@param speedThreshold number
---@param stepsBelowThreshold number
---@param stepsAboveThreshold number
function m:ConfigureVehicleSubsteps(speedThreshold, stepsBelowThreshold, stepsAboveThreshold) end

---@return boolean, UnityEngine.WheelHit
function m:GetGroundHit() end

---@return UnityEngine.Vector3, UnityEngine.Quaternion
function m:GetWorldPose() end

UnityEngine.WheelCollider = m
return m
