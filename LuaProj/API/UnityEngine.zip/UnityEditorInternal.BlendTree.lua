---@class UnityEditorInternal.BlendTree : System.Object
local m = {}

UnityEditorInternal.BlendTree = m
return m
