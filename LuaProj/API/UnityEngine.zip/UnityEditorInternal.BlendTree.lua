---@class UnityEditorInternal.BlendTree : UnityEngine.Motion
local m = {}

UnityEditorInternal.BlendTree = m
return m
