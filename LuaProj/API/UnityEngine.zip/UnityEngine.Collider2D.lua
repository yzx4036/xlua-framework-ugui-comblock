---@class UnityEngine.Collider2D : UnityEngine.Behaviour
---@field public density number
---@field public isTrigger boolean
---@field public usedByEffector boolean
---@field public offset UnityEngine.Vector2
---@field public attachedRigidbody UnityEngine.Rigidbody2D
---@field public shapeCount number
---@field public bounds UnityEngine.Bounds
---@field public sharedMaterial UnityEngine.PhysicsMaterial2D
---@field public friction number
---@field public bounciness number
local m = {}

---@param collider UnityEngine.Collider2D
---@return boolean
function m:IsTouching(collider) end

---@overload fun():boolean
---@param layerMask number
---@return boolean
function m:IsTouchingLayers(layerMask) end

---@param point UnityEngine.Vector2
---@return boolean
function m:OverlapPoint(point) end

---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number, minDepth:number):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[]):number
---@param direction UnityEngine.Vector2
---@param results UnityEngine.RaycastHit2D[]
---@param distance number
---@param layerMask number
---@param minDepth number
---@param maxDepth number
---@return number
function m:Raycast(direction, results, distance, layerMask, minDepth, maxDepth) end

---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[]):number
---@param direction UnityEngine.Vector2
---@param results UnityEngine.RaycastHit2D[]
---@param distance number
---@param ignoreSiblingColliders boolean
---@return number
function m:Cast(direction, results, distance, ignoreSiblingColliders) end

UnityEngine.Collider2D = m
return m
