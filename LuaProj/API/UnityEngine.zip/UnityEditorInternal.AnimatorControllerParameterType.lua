---@class UnityEditorInternal.AnimatorControllerParameterType : System.Enum
---@field public Float UnityEditorInternal.AnimatorControllerParameterType @static
---@field public Int UnityEditorInternal.AnimatorControllerParameterType @static
---@field public Bool UnityEditorInternal.AnimatorControllerParameterType @static
---@field public Trigger UnityEditorInternal.AnimatorControllerParameterType @static
---@field public value__ number
local m = {}

UnityEditorInternal.AnimatorControllerParameterType = m
return m
