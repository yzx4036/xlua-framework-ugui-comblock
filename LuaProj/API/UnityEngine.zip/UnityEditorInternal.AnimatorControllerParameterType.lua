---@class UnityEditorInternal.AnimatorControllerParameterType : System.Enum
---@field public value__ number
local m = {}

UnityEditorInternal.AnimatorControllerParameterType = m
return m
