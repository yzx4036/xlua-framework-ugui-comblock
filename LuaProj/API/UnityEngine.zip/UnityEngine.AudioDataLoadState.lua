---@class UnityEngine.AudioDataLoadState : System.Enum
---@field public Unloaded UnityEngine.AudioDataLoadState @static
---@field public Loading UnityEngine.AudioDataLoadState @static
---@field public Loaded UnityEngine.AudioDataLoadState @static
---@field public Failed UnityEngine.AudioDataLoadState @static
---@field public value__ number
local m = {}

UnityEngine.AudioDataLoadState = m
return m
