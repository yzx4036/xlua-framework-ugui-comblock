---@class UnityEngine.Experimental.Director.GenericMixerPlayable : System.ValueType
local m = {}

---@static
---@return UnityEngine.Experimental.Director.GenericMixerPlayable
function m.Create() end

function m:Destroy() end

---@return System.ValueType
function m:CastTo() end

---@static
---@param s UnityEngine.Experimental.Director.GenericMixerPlayable
---@return UnityEngine.Experimental.Director.Playable
function m.op_Implicit(s) end

UnityEngine.Experimental.Director.GenericMixerPlayable = m
return m
