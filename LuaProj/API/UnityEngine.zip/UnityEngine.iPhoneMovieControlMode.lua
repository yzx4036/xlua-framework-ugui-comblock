---@class UnityEngine.iPhoneMovieControlMode : System.Enum
---@field public value__ number
local m = {}

UnityEngine.iPhoneMovieControlMode = m
return m
