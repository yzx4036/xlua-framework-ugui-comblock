---@class UnityEditorInternal.Transition : UnityEngine.Object
local m = {}

---@param rect UnityEngine.Rect
---@return UnityEngine.GUIContent
function m:GetTransitionContentForRect(rect) end

UnityEditorInternal.Transition = m
return m
