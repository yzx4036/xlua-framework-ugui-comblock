---@class UnityEditorInternal.Transition : System.Object
local m = {}

UnityEditorInternal.Transition = m
return m
