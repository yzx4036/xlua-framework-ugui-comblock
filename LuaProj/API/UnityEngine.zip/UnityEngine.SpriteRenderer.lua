---@class UnityEngine.SpriteRenderer : UnityEngine.Renderer
---@field public sprite UnityEngine.Sprite
---@field public color UnityEngine.Color
---@field public flipX boolean
---@field public flipY boolean
local m = {}

UnityEngine.SpriteRenderer = m
return m
