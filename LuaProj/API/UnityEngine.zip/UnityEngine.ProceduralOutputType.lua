---@class UnityEngine.ProceduralOutputType : System.Enum
---@field public value__ number
local m = {}

UnityEngine.ProceduralOutputType = m
return m
