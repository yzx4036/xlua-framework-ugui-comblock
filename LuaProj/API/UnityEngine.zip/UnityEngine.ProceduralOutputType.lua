---@class UnityEngine.ProceduralOutputType : System.Enum
---@field public Unknown UnityEngine.ProceduralOutputType @static
---@field public Diffuse UnityEngine.ProceduralOutputType @static
---@field public Normal UnityEngine.ProceduralOutputType @static
---@field public Height UnityEngine.ProceduralOutputType @static
---@field public Emissive UnityEngine.ProceduralOutputType @static
---@field public Specular UnityEngine.ProceduralOutputType @static
---@field public Opacity UnityEngine.ProceduralOutputType @static
---@field public Smoothness UnityEngine.ProceduralOutputType @static
---@field public AmbientOcclusion UnityEngine.ProceduralOutputType @static
---@field public DetailMask UnityEngine.ProceduralOutputType @static
---@field public Metallic UnityEngine.ProceduralOutputType @static
---@field public Roughness UnityEngine.ProceduralOutputType @static
---@field public value__ number
local m = {}

UnityEngine.ProceduralOutputType = m
return m
