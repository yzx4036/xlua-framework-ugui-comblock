---@class UnityEngine.Audio.AudioMixerSnapshot : UnityEngine.Object
---@field public audioMixer UnityEngine.Audio.AudioMixer
local m = {}

---@param timeToReach number
function m:TransitionTo(timeToReach) end

UnityEngine.Audio.AudioMixerSnapshot = m
return m
