---@class UnityEngine.AudioSourceCurveType : System.Enum
---@field public CustomRolloff UnityEngine.AudioSourceCurveType @static
---@field public SpatialBlend UnityEngine.AudioSourceCurveType @static
---@field public ReverbZoneMix UnityEngine.AudioSourceCurveType @static
---@field public Spread UnityEngine.AudioSourceCurveType @static
---@field public value__ number
local m = {}

UnityEngine.AudioSourceCurveType = m
return m
