---@class UnityEngine.iPhoneNetworkReachability : System.Enum
---@field public value__ number
local m = {}

UnityEngine.iPhoneNetworkReachability = m
return m
