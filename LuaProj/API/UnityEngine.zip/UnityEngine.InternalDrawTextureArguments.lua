---@class UnityEngine.InternalDrawTextureArguments : System.ValueType
---@field public screenRect UnityEngine.Rect
---@field public texture UnityEngine.Texture
---@field public sourceRect UnityEngine.Rect
---@field public leftBorder number
---@field public rightBorder number
---@field public topBorder number
---@field public bottomBorder number
---@field public color UnityEngine.Color32
---@field public mat UnityEngine.Material
---@field public pass number
local m = {}

UnityEngine.InternalDrawTextureArguments = m
return m
